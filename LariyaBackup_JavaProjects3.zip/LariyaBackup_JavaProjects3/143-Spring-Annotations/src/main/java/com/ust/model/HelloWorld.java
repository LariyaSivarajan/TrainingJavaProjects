package com.ust.model;

public class HelloWorld {
 String message="Hello.....";

public String getMessage() {
	return message;
}

public void setMessage(String message) {
	this.message = message;
}

@Override
public String toString() {
	return "HelloWorld [message=" + message + "]";
}
 
 
}
