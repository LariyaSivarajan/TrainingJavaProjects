package com.ust.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.ust.model.Employee;
import com.ust.model.HelloWorld;

@Configuration
public class MyConfiguration1 {
	
	@Bean//(name="helloWorldBean")
	@Scope("prototype")
	public HelloWorld f1() {
		HelloWorld helloWorld=new HelloWorld();
		return helloWorld;
	}
	@Bean
	public Employee f2() {
		Employee employee=new Employee();
		employee.setId(101);
		employee.setName("Nirmal");
		employee.setBasic(5000.00);
		return employee;
	}

}
