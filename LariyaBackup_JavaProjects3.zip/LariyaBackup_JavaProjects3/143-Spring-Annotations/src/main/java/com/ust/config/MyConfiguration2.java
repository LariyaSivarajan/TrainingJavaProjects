package com.ust.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ust.model.Address;
import com.ust.model.Customer;

@Configuration
public class MyConfiguration2 {
	@Bean(name="ChennaiAddress")
	public Address f3() {
		Address address=new Address("D-1", "Chennai", "68960");
		return address;
	}
	@Bean
	public Customer f4() {
		Customer customer=new Customer();
		customer.setId(102);
		customer.setName("Abhi");
		//customer.setAddress(f3());
		return customer;
	}
	@Bean(name="CochinAddress")
	public Address f5() {
		Address address=new Address("T3", "Cochin", "00001");
		return address;
	}

}
