package com.ust;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ust.db.CustomerDAO;
import com.ust.model.Customer;
import com.ust.service.CustomerService;
import com.ust.ui.CustomerManagementController;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	 ApplicationContext context;
         context=new ClassPathXmlApplicationContext("applicationContext.xml");
         CustomerDAO dao=(CustomerDAO)context.getBean("customerDAO");
         System.out.println(dao);
         
         CustomerService service=(CustomerService)context.getBean("customerService");
         System.out.println(service);
         CustomerManagementController controller;
         controller=(CustomerManagementController) context.getBean("customerManagementController");
         System.out.println(controller);
    }
}
