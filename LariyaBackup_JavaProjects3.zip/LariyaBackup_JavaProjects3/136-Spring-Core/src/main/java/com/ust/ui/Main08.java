package com.ust.ui;


import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


import com.ust.model.EmployeeManagement;

public class Main08 {

	public static void main(String[] args) {
		ConfigurableApplicationContext context=
        		new ClassPathXmlApplicationContext("beans.xml");
	 EmployeeManagement employeeMgmt=(EmployeeManagement)context.getBean("employeeManagementBean");
	 System.out.println(employeeMgmt);
	 context.close();

	}

}
