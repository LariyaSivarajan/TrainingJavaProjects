package com.ust.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ust.model.HelloWorld;
import com.ust.model.Shape;

public class Main02 {

	public static void main(String[] args) {
		// get the bean 
		//and print the bean object
		
		HelloWorld helloWorld;
        ApplicationContext context=
        		new ClassPathXmlApplicationContext("beans.xml");
        
        helloWorld=(HelloWorld)context.getBean("helloBean");
       // helloWorld.setMessage("Welcome to Ust");
        System.out.println(helloWorld.getMessage());
        System.out.println(helloWorld.toString());

	}

}
