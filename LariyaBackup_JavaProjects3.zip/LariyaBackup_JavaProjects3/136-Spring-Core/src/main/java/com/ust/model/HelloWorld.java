package com.ust.model;

public class HelloWorld {
 String message="Welcome to Spring";

@Override
public String toString() {
	return "HelloWorld [message=" + message + "]";
}

public String getMessage() {
	return message;
}

public void setMessage(String message) {
	this.message = message;
}
 
 
}
