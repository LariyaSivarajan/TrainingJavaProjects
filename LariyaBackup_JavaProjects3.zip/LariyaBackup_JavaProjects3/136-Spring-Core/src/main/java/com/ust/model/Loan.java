package com.ust.model;

public interface Loan {
  void setLoanAmount(double amount);
  double getInterestAmount();
  
}
