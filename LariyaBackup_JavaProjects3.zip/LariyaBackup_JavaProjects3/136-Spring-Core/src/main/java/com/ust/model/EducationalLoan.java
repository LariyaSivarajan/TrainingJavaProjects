package com.ust.model;

public class EducationalLoan implements Loan{
	double educationalLoanAmount;
	@Override
	public void setLoanAmount(double amount) {
		this.educationalLoanAmount=amount;
		
	}

	@Override
	public double getInterestAmount() {
		
		return  this.educationalLoanAmount*12*8.0/100.0;
	}

	@Override
	public String toString() {
		return "EducationalLoan [educationalLoanAmount=" + educationalLoanAmount + "]";
	}
	

}
