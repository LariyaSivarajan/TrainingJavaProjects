package com.ust.ui;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;



import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ust.model.Employee;

import jakarta.validation.Valid;

@Controller
public class EmployeeController {
	@RequestMapping("/emp")
 public ModelAndView f1() {
	 ModelAndView mav=new ModelAndView("empOutput");
	 Employee employee=
			 new Employee(1001, "Kiran", "Male", "Mumbai", 40000.00);
	 mav.addObject("empl", employee);
	 return mav;
 }
	@RequestMapping("/input")
	public ModelAndView f2() {
		ModelAndView mav=new ModelAndView("empInput");
		Employee employee=new Employee();
		mav.addObject("emp", employee);
		return mav;
	}
	@RequestMapping("/output")
	public String f3(@ModelAttribute(value="emp")@Valid Employee employee,BindingResult result,Map<String,Object> modelmap) {
		System.out.println(result.getAllErrors());
		
		if(result.hasErrors()) {
			
			return "empInput";
		}else {
			modelmap.put("empl", employee);
			return "empOutput";
		}
		
	}
	
	@RequestMapping("/allemployees")
	public ModelAndView f4(@ModelAttribute(name="emp")Employee employee) {
		ModelAndView mav=new ModelAndView("empList");
		Employee employee1=new Employee(1002, "Sundar", "Male", "Chennai", 12000.00);
		Employee employee2=new Employee(1003, "Aditya", "Male", "Cochin", 22000.00);
		Employee employee3=new Employee(1004, "Suman", "Male", "Bengluru", 38000.00);
		Employee employee4=new Employee(1005, "Syed", "Male", "Hydrabad", 11000.00);
		Employee employee5=new Employee(1006, "Joshep", "Male", "Chennai", 24000.00);
		
		List<Employee> employees=new LinkedList<>();
		employees.add(employee1);
		employees.add(employee2);
		employees.add(employee3);
		employees.add(employee4);
		employees.add(employee5);
		mav.addObject("emps", employees);
		return mav;
	}
}

