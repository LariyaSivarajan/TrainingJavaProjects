package com.ust.ui;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ust.model.Student;

@Controller
public class StudentController {

	@RequestMapping("/input")
	public ModelAndView f1() {
		ModelAndView mav=new ModelAndView("studInput");
		Student student=new Student();
		mav.addObject("stud", student);
		return mav;
	}
	@RequestMapping("/output")
	public ModelAndView f2(@ModelAttribute(name="stud")Student student) {
		ModelAndView mav=new ModelAndView("studOutput1");
		mav.addObject("studl", student);
		return mav;
	}
}
