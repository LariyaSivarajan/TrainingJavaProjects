package com.ust.db;

import org.springframework.stereotype.Repository;

@Repository
public class StudentDAO {

	@Override
	public String toString() {
		return "StudentDAO []";
	}

	

}
