package com.ust;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ust.db.StudentDAO;
import com.ust.service.StudentService;
import com.ust.ui.StudentManagementController;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {
       ApplicationContext context;
       context=new ClassPathXmlApplicationContext("applicationContext.xml");
       StudentDAO dao=(StudentDAO)context.getBean("studentDAO");
       System.out.println(dao);
       
       StudentService service=(StudentService)context.getBean("studentService");
       System.out.println(service);
       StudentManagementController controller;
       controller=(StudentManagementController) context.getBean("studentManagementController");
       System.out.println(controller);
    }
}
