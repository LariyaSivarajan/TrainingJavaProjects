package com.ust.ui;

import java.util.Collection;
import java.util.LinkedList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ust.model.Employee;




@Controller
@RequestMapping(value="/employees")
public class EmployeeController {
	@GetMapping(value="/display")
	public String f1(Model model) {
		Employee employee=new Employee(110, "Ram", 50000.00, "Male");
		model.addAttribute("emp",employee);
		return "EmployeeDisplay";
	}
	@GetMapping(value="/listing")
	public String f2(Model model) {
		Employee e1=new Employee(110, "Ram", 50000.00, "Male");
		Employee e2=new Employee(111, "Lekshman", 40000.00, "Male");
		Employee e3=new Employee(112, "Krishnan", 60000.00, "Male");
		Employee e4=new Employee(113, "Seetha", 35000.00, "Female");
		Employee e5=new Employee(114, "Lekshmi", 38000.00, "Female");
		Collection<Employee> employees=new LinkedList<>();
		employees.add(e1);
		employees.add(e2);
		employees.add(e3);
		employees.add(e4);
		employees.add(e5);
		model.addAttribute("emps",employees);
		return "EmployeeListing";
	}

}
