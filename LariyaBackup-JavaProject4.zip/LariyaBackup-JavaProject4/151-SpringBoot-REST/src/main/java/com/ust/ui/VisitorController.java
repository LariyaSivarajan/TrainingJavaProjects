package com.ust.ui;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.LinkedBlockingDeque;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ust.model.Visitor;

@RestController
@RequestMapping("/api")
public class VisitorController {
	@GetMapping("/showVisitor")
	
	public Visitor f1() {
		Visitor visitor=new Visitor(1055, "Kiran", "male", 27);
		return visitor;
	}
  @GetMapping("/visitors")
  public List<Visitor> f2(){
	  List<Visitor> allVisitors;
	  allVisitors=new LinkedList<>();
	  allVisitors.add(new Visitor(1055, "Kiran", "male", 27));
	  allVisitors.add(new Visitor(1056, "Kripa", "Female", 20));
	  allVisitors.add(new Visitor(1057, "Kishnan", "male", 29));
	  return allVisitors;
  }
}
