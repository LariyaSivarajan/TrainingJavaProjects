package com.ust.ui;

import java.util.LinkedList;
import java.util.Queue;

public class Main1 {

	public static void main(String[] args) {
		Queue<Integer> queue=new LinkedList<>();
		
		queue.add(20);
		queue.add(15);
		queue.add(17);
		queue.add(12);
		queue.add(16);
		
		Integer temp=queue.peek();
		System.out.println(temp);
		Integer result1=queue.poll();
		System.out.println(result1);
		
		Integer result2=queue.poll();
		System.out.println(result2);
		Integer result3=queue.poll();
		System.out.println(result3);
		Integer result4=queue.poll();
		System.out.println(result4);
		System.out.println(queue);
		
		
	}

}
