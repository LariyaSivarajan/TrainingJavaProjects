package com.ust.model;

import java.util.Comparator;

public class Person implements Comparable<Person> {
  int age;
  int height;
  int weight;
public Person(int age, int height, int weight) {
	super();
	this.age = age;
	this.height = height;
	this.weight = weight;
}
public Person() {
	super();
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public int getHeight() {
	return height;
}
public void setHeight(int height) {
	this.height = height;
}
public int getWeight() {
	return weight;
}
public void setWeight(int weight) {
	this.weight = weight;
}
@Override
public String toString() {
	return "Person [age=" + age + ", height=" + height + ", weight=" + weight + "]";
}

@Override
public int compareTo(Person o) {
	// TODO Auto-generated method stub
	return this.age-o.age;
}
  
  
}
