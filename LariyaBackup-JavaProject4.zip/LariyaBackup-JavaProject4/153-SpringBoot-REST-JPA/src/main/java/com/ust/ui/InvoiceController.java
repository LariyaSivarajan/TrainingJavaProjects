package com.ust.ui;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ust.model.Invoice;

import com.ust.service.InvoiceService;


@RestController
@RequestMapping(value="/api")
public class InvoiceController {
	@Autowired
	InvoiceService service;
	@PostMapping(value="/add", produces = { MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE})
	public Invoice f1(@RequestBody Invoice invoice) {
		return this.service.addNewInvoice(invoice);
		
	}
	@PutMapping(value="/modify",produces = { MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE})
	public Invoice f2(@RequestBody Invoice invoice) {
		return this.service.updateInvoice(invoice);
	}
    @GetMapping(value="/find/{invid}",produces = { MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE})
	public Invoice f3(@PathVariable (name="invid") int invid) {
		return this.service.searchInvoice(invid);
	}
    @GetMapping(value="/showAll",produces = { MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE})
	public List<Invoice> f4() {
		return this.service.getAllInvoices();
	}
    @DeleteMapping(value="/delete")
    public boolean f5(@RequestBody Invoice invoice) {
    	return this.service.deleteInvoice(invoice);
    }
}
