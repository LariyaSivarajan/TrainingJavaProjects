package com.ust.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.db.CustomerRepository;
import com.ust.db.InvoiceRepository;
import com.ust.model.Invoice;


@Service
public class InvoiceService {
	@Autowired
	InvoiceRepository repo;
	public Invoice addNewInvoice(Invoice invoice) {
		return repo.save(invoice);
	}
	
	public Invoice updateInvoice(Invoice invoice) {
		return repo.save(invoice);
		
	}
  public Invoice searchInvoice(Invoice invoice) {
	  Optional<Invoice> optional=repo.findById(invoice.getId());
	  if(optional.isPresent())
		  return optional.get();
	  else
		  return null;
  }
  
  public Invoice searchInvoice(int id) {
	  Optional<Invoice> optional=repo.findById(id);
	  if(optional.isPresent())
		  return optional.get();
	  else
		  return null;
  }
  public List<Invoice> getAllInvoices(){
	  return repo.findAll();
  }
  public boolean deleteInvoice(Invoice invoice) {
	  repo.delete(invoice);
	  return true;
  }
}
