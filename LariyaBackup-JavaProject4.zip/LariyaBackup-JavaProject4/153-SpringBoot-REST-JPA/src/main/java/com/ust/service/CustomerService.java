package com.ust.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.ust.db.CustomerRepository;

public class CustomerService {
 @Autowired
 CustomerRepository repo;
 
}
