package com.ust.ui;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController {

}
