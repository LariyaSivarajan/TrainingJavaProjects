package com.ust.ui;

import java.util.Arrays;
import java.util.List;
import java.util.Stack;

import com.ust.ds.Edge;
import com.ust.ds.Graph;
public class Main {
public static void iterativeDFS(Graph graph,int v,boolean[] discovered)
{
	Stack<Integer> stack=new Stack<>();
	stack.push(v);
	while(!stack.empty())
	{
		v=stack.pop();
		if(discovered[v]) {
			continue;
		}
		discovered[v]=true;
		System.out.println(v+" ");
		List<Integer> adjList=graph.adjList.get(v);
		for(int i=adjList.size()-1;i>=0;i--) {
			int u=adjList.get(i);
			if(!discovered[u]) {
				stack.push(u);
			}
		}
	}
}

public static void main(String[] args) {
	
	List<Edge> edges=Arrays.asList(
		new Edge(1, 2),new Edge(1, 7),new Edge(1, 8),new Edge(2, 3),
		new Edge(2, 6),new Edge(3, 4),new Edge(3, 5),new Edge(8, 9),
		new Edge(8, 12),new Edge(9, 10),new Edge(9, 11)
		);
	int n=13;
	Graph graph=new Graph(edges,n);
	boolean[] discovered=new boolean[n];
	for(int i=0;i<n;i++) {
		if(!discovered[i]) {
			iterativeDFS(graph, i, discovered);
		}
	}
	

}
}
