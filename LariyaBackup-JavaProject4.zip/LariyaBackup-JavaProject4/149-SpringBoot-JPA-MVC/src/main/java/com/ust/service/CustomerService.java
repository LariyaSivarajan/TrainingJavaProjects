package com.ust.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.db.CustomerRepository;

import com.ust.model.Customer;


@Service
public class CustomerService {
	@Autowired
	CustomerRepository repo;
	public Customer addCustomer(Customer customer) {
		Customer c=repo.save(customer);
		return c;
	}
public Customer updateCustomer(Customer customer) {
	Customer s=repo.save(customer);
	return s;
}
public boolean deleteCustomer(Customer customer) {
	repo.delete(customer);;
	return true;
}
public Customer searchCustomer(int id) {
	Optional<Customer> optional=repo.findById(id);
	if(optional.isPresent())
		return optional.get();
	else
		return null;
}
public List<Customer> getAllCustomers(){
	return repo.findAll();
}
}
