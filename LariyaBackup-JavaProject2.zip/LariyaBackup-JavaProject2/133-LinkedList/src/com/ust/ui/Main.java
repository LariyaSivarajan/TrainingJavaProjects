package com.ust.ui;

import com.ust.linkedlist.LinkedList;
import com.ust.model.Customer;

public class Main {

	public static void main(String[] args) {
     LinkedList<Customer> customersList=new LinkedList<Customer>();
			Customer customers1=new Customer(1,"Ram");
			Customer customers2=new Customer(2,"Lekshman");
			Customer customers3=new Customer(3,"Krishna");
			Customer customers4=new Customer(4,"Lekshmi");
			Customer customers5=new Customer(5,"Seetha");
		    customersList.addToList(customers1);
			customersList.addToList(customers2);
			customersList.addToList(customers3);
			customersList.addToList(customers4);
			customersList.addToList(customers5);
			 System.out.println("sdghgjfgjhgj");
			 System.out.println("Count="+customersList.count());

	}}


