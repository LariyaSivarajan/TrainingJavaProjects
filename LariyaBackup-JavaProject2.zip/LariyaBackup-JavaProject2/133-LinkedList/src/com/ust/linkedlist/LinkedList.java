package com.ust.linkedlist;

public class LinkedList<T> {
	
	public static Node start=null;
	
	public void addToList(T data) {
		Node new_node=new Node(data);
		new_node.nextNode=null;
		if(start==null) {
			start=new_node;
		}
		else
		{
			Node currentNode=start;
			while(currentNode.nextNode!=null) {
				currentNode.nextNode=new_node;
			}
			currentNode.nextNode=new_node;
		}
	}


	public int count() {
		Node currentNode=start;
		int count=0;
		while(currentNode!=null) {
			count++;
			currentNode=currentNode.nextNode;
		}
		return count;
	}
}