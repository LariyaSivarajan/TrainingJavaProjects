package com.ust.service;

import java.util.List;

import com.ust.model.Customer;


public interface CustomerService {

	boolean addCustomer(Customer customer);

	Customer searchCustomer(int id);

	List<Customer> getAllCustomers();

	boolean updateCustomer(Customer customer);

	boolean deleteCustomer(int id);

}
