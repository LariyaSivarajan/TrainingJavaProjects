package com.ust.actions;

import java.util.List;

import com.ust.model.Customer;
import com.ust.service.*;
import com.ust.service.CustomerServiceImpl;

public class ListAction extends Action {

	@Override
	public void init() {
		System.out.println("\n\n");
		System.out.println("\t\t Listing Customer");
		System.out.println("\t\t--------------------");

	}

	@Override
	public void execute() {

		System.out.println("\t\t Listing  Customer");
		CustomerService service = new CustomerServiceImpl();
		List<Customer> customerList = service.getAllCustomers();
		if (customerList == null || customerList.isEmpty()) {
			System.out.println("\n\n\t\t No Customer Found !!!");
		} else {
			System.out.println("\t\tCustomer Id   \t\tName    \t\tBalance  \tEmail  \t\t\tPhoneNumber \n");
			System.out.println(
					"\t\t---------------------------------------------------------------------------------------------------------------");
			customerList.stream().forEach((s) -> {
				System.out.printf("\t\t%d     \t\t%-20s    %10.2f\t  %-20s\t  %-15s  \n", s.getId(), s.getName(),
						s.getBalance(), s.getEmail(), s.getPhone());
			});

		}

	}

	@Override
	public void complete() {
		System.out.println("\n\n");
		System.out.println("\t\tListing  completed");
		System.out.println("\n\n");
	}
}
