package com.ust.actions;

import com.ust.model.Customer;

import com.ust.service.*;
import com.ust.service.CustomerServiceImpl;
import com.ust.ui.util.ConsoleIO;

public class SearchAction extends Action {

	@Override
	public void init() {
		System.out.println("\n\n");
		System.out.println("\t\t Search Customer");
		System.out.println("\t\t--------------------");

	}

	@Override
	public void execute() {
		// System.out.println("\t\t Searching Student");

		int searchIdNumber;
		ConsoleIO.prompt("Enter Id Number to search");
		searchIdNumber = ConsoleIO.intInput();
		try {
			if (searchIdNumber < 0) {
				throw new Exception();
			}

		} catch (Exception e) {
			System.err.println("\t\t Invalid Id Number");
			ConsoleIO.prompt("Enter Id Number to Search :");
			searchIdNumber = ConsoleIO.intInput();
		}
		CustomerService service = new CustomerServiceImpl();
		Customer customer = service.searchCustomer(searchIdNumber);
		if (customer != null) {
			System.out.println("\t\t Roll Number   :" + customer.getId());
			System.out.println("\t\t Name          :" + customer.getName());
			System.out.println("\t\t Balance       :" + customer.getBalance());
			System.out.println("\t\t Email        :" + customer.getEmail());
			System.out.println("\t\t Phone         :" + customer.getPhone());

		} else {
			System.out.println("\n\n\t\t Customer Not Found !!!");
		}
	}

	@Override
	public void complete() {
		System.out.println("\n\n");
		System.out.println("\t\tSearching  completed");
		System.out.println("\n\n");

	}
}
