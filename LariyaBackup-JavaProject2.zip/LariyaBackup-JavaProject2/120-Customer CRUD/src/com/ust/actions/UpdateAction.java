package com.ust.actions;

import com.ust.model.Customer;

import com.ust.service.*;
import com.ust.service.CustomerServiceImpl;
import com.ust.ui.util.ConsoleIO;

public class UpdateAction extends Action {

	boolean status;

	@Override
	public void init() {
		System.out.println("\n\n");
		System.out.println("\t\t Update Customer");
		System.out.println("\t\t--------------------");

	}

	@Override
	public void execute() {
		int id;
		String name;
		double balance;
		String email;
		String phone;
		ConsoleIO.prompt("Enter Customer Id");
		id = ConsoleIO.intInput();
		try {
			if (id < 0) {
				throw new Exception();
			}

		} catch (Exception e) {
			System.err.println("\t\t Customer Id cannot be negative");
			ConsoleIO.prompt("Enter Customer Id :");
			id = ConsoleIO.intInput();
		}
		ConsoleIO.prompt("Enter Name");
		name = ConsoleIO.stringInput();
		try {
			if (name.isEmpty() || name.equals(null)) {
				throw new Exception();
			}

		} catch (Exception e) {
			System.err.println("\t\t Name cannot be empty");
			ConsoleIO.prompt("Enter Name :");
			name = ConsoleIO.stringInput();
		}

		ConsoleIO.prompt("Enter Balance");
		balance = ConsoleIO.doubleInput();
		try {
			if (balance < 0) {
				throw new Exception();
			}

		} catch (Exception e) {
			System.err.println("\t\t balance should be Greater than 0");
			ConsoleIO.prompt("Enter balance :");
			balance = ConsoleIO.doubleInput();
		}
		ConsoleIO.prompt("Enter Email");
		email = ConsoleIO.stringInput();
		try {
			if (email.isEmpty() || email.equals(null)) {
				throw new Exception();
			}

		} catch (Exception e) {
			System.err.println("\t\t Email cannot be empty");
			ConsoleIO.prompt("Enter Email :");
			email = ConsoleIO.stringInput();
		}
		ConsoleIO.prompt("Enter Phone number");
		phone = ConsoleIO.stringInput();
		try {
			if (phone.isEmpty() || phone.equals(null)) {
				throw new Exception();
			}

		} catch (Exception e) {
			System.err.println("\t\t Phone number canot be null");
			ConsoleIO.prompt("Enter Phone number :");
			phone = ConsoleIO.stringInput();
		}
		Customer customer = new Customer(id, name, balance, email, phone);
		CustomerService service = new CustomerServiceImpl();
		status = service.updateCustomer(customer);
	}

	@Override
	public void complete() {
		System.out.println("\n\n");
		if (status == true)
			System.out.println("\t\tUpdating  completed successfully");
		else
			System.out.println("\t\tUpdating  Failed");
		System.out.println("\n\n");
	}
}
