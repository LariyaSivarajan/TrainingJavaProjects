package com.ust.actions;

import com.ust.service.*;
import com.ust.service.CustomerServiceImpl;
import com.ust.ui.util.ConsoleIO;

public class DeleteAction extends Action {

	boolean status;

	@Override
	public void init() {
		System.out.println("\n\n");
		System.out.println("\t\t Delete Customer");
		System.out.println("\t\t--------------------");

	}

	@Override
	public void execute() {
		System.out.println("\t\t Deleting a Customer");
		int idToDelete;
		ConsoleIO.prompt("Enter Id Number to Delete");
		idToDelete = ConsoleIO.intInput();
		try {
			if (idToDelete < 0) {
				throw new Exception();
			}

		} catch (Exception e) {
			System.err.println("\t\t Invalid Id Number");
			ConsoleIO.prompt("Enter Id Number to Delete :");
			idToDelete = ConsoleIO.intInput();
		}
		// db
		CustomerService service = new CustomerServiceImpl();
		status = service.deleteCustomer(idToDelete);
	}

	@Override
	public void complete() {
		System.out.println("\n\n");
		if (status == true)
			System.out.println("\t\tDeleting  completed successfully");
		else
			System.out.println("\t\tDeleting  Failed");
		System.out.println("\n\n");
	}
}
