package com.ust.db;

import java.sql.Connection;
import java.util.List;

import com.ust.model.Customer;

public interface CustomerMySQLDAO {
	String INSERT_QRY = "insert into Customer values(?,?,?,?,?)";
	String UDATE_QRY = "update Customer set name=?,balance=?,email=?,phone=? where id=?";
	String DELETE_QRY = "delete from customer where id=?";
	String SEARCH_QRY = "select * from Customer where id=?";
	String FINDALL_QRY = "select * from Customer";

	boolean insertCustomer(Connection connection, Customer customer);

	boolean updateCustomer(Connection connection, Customer customer);

	boolean deleteCustomer(Connection connection, Customer customer);

	Customer findCustomerById(Connection connection, int id);

	List<Customer> findAllCustomers(Connection connection);

}
