package com.ust.ui;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Main1 {

	public static void main(String[] args) {
		// step 1
		// Load a Driver

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver loaded successfully");
		} catch (ClassNotFoundException e) {
			System.err.println(e);
		}

		// step2
		// Establish a connection to a database
		Connection connection = null;
		String dburl = "jdbc:mysql://localhost:3306/trainingdb25?useSSL=false";
		String username = "root";
		String password = "root";

		try {
			connection = DriverManager.getConnection(dburl, username, password);
			System.out.println("Connected to Database");
		} catch (SQLException e) {
			System.err.println(e);
		}
		//Step3
		//calling stored procedure
		
		try {
			CallableStatement statement=connection.prepareCall("{call countrycount(?,?)}"); 
			statement.setString(1,"USA");
			statement.registerOutParameter(2,java.sql.Types.INTEGER);
			statement.execute();
			System.out.println(statement.getInt(2));
		} catch (SQLException e1) {
			System.err.println(e1);
		}
		
		
		//step4
		//close connection
		
		try {
			connection.close();
			System.out.println("Connection closed successfully");
		} catch (SQLException e) {
			System.err.println(e);
		}
	}

}
