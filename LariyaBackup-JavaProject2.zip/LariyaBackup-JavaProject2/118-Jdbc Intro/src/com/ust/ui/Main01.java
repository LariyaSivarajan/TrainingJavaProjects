package com.ust.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Main01 {

	public static void main(String[] args) {
		// step 1
		//Load a Driver
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver loaded successfully");
		} catch (ClassNotFoundException e) {
			System.err.println(e);
		}
		
		
		//step2
		//Establish a connection to a database
		Connection connection=null;
		String dburl="jdbc:mysql://localhost:3306/trainingdb25?useSSL=false";
		String username="root";
		String password="root";
		
		try {
			connection=DriverManager.getConnection(dburl, username, password);
			System.out.println("Connected to Database");
		} catch (SQLException e) {
			System.err.println(e);
		}
		
		//step3
		//Execute Queries
		
		String query="insert into products values(1005,'IBM',72000.00,'Desktop')";
		
		
		
		try {
			Statement statement=connection.createStatement();
			System.out.println("Statement created successfully");
			int r=statement.executeUpdate(query);
			System.out.println(r+"row(s) inserted");
		} catch (SQLException e) {
			System.err.println(e);
		}
		//step4
		//close the connection
		try {
			connection.close();
			System.out.println("Connection closed successfully");
		} catch (SQLException e) {
			System.err.println(e);
		}

	}
	

}
