package com.ust.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Main06 {

	public static void main(String[] args) {
		// step 1
		// Load a Driver

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver loaded successfully");
		} catch (ClassNotFoundException e) {
			System.err.println(e);
		}

		// step2
		// Establish a connection to a database
		Connection connection = null;
		String dburl = "jdbc:mysql://localhost:3306/trainingdb25?useSSL=false";
		String username = "root";
		String password = "root";

		try {
			connection = DriverManager.getConnection(dburl, username, password);
			System.out.println("Connected to Database");
		} catch (SQLException e) {
			System.err.println(e);
		}

		// step3
		// Execute Queries

		String query = "insert into products values(?,?,?,?)";  //parameterized query

		try {
			PreparedStatement statement=connection.prepareStatement(query);
			System.out.println("Statement created successfully");
			Scanner  scanner=new Scanner(System.in);
			
			int pid;
			String pname;
			double pprice;
			String pcategory;
			System.out.println("Enter ID :");
			pid=Integer.parseInt(scanner.nextLine());
			System.out.println("Enter Name :");
			pname=scanner.nextLine();
			
			System.out.println("Enter Price :");
			pprice=Double.parseDouble(scanner.nextLine());
			
			System.out.println("Enter Category :");
			pcategory=scanner.nextLine();
			
			statement.setInt(1, pid);
			statement.setString(2, pname);
			statement.setDouble(3, pprice);
			statement.setString(4, pcategory);
			int r = statement.executeUpdate();
			System.out.println(r + "row(s) inserted");
		} catch (SQLException e) {
			System.err.println(e);
		}
		// step4
		// close the connection
		try {
			connection.close();
			System.out.println("Connection closed successfully");
		} catch (SQLException e) {
			System.err.println(e);
		}

	}

}
