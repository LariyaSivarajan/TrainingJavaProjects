package com.ust.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Main09 {

	public static void main(String[] args) {
		//step 1
				// Load a Driver

				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					System.out.println("Driver loaded successfully");
				} catch (ClassNotFoundException e) {
					System.err.println(e);
				}

				// step2
				// Establish a connection to a database
				Connection connection = null;
				String dburl = "jdbc:mysql://localhost:3306/trainingdb25?useSSL=false";
				String username = "root";
				String password = "root";

				try {
					connection = DriverManager.getConnection(dburl, username, password);
					System.out.println("Connected to Database");
				} catch (SQLException e) {
					System.err.println(e);
				}

				// step3
				// Execute Queries

				String query = "select * from   products  where pid=?";//parameterized query

				try {
					PreparedStatement statement=connection.prepareStatement(query);
					System.out.println("Statement created successfully");
					Scanner  scanner=new Scanner(System.in);
					
					int id;
					
					System.out.println("Enter ID to Search:");
					id=Integer.parseInt(scanner.nextLine());
					
						
					
					statement.setInt(1, id);
					ResultSet rs = statement.executeQuery();
					if(rs.next()) {
						int pid=rs.getInt(1);
						String pname=rs.getString(2);
						double pprice=rs.getDouble(3);
						String pcategory=rs.getString(4);
						System.out.printf("%d %-20s %10.2f ,%-20s\n",pid,pname,pprice,pcategory);
						
						
					}else
					{
						System.out.println("ID Not found!!!");
					}
					
				} catch (SQLException e) {
					System.err.println(e);
				}
				// step4
				// close the connection
				try {
					connection.close();
					System.out.println("Connection closed successfully");
				} catch (SQLException e) {
					System.err.println(e);
				}

			}

	}


