package com.ust.ui;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import com.ust.model.Student;
import com.ust.service.StudentServiceImpl;


public class ListStudentsControllerServlet extends HttpServlet {


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		StudentServiceImpl service=new StudentServiceImpl();
		
		List<Student> allStudents=service.getAllStudents();
		
		
		request.setAttribute("studs", allStudents);
		
		
		RequestDispatcher dispatcher=request.getRequestDispatcher("DisplayAllStudents.jsp");
		dispatcher.forward(request, response);
	}

}
