package com.ust.ui;

import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

import com.ust.model.Employee;
import com.ust.model.LeaveApplication;
import com.ust.model.Manager;

public class Main {

	/*public static void main(String[] args) {
		// TODO Auto-generated method stub
      //String role;
      //String loginName;
      Scanner scanner=new Scanner(System.in);
     // System.out.println("Are you manager or employee");
     // role=scanner.nextLine();
     // System.out.println("Enter your name :");
      //loginName=scanner.nextLine();
      //if role is employee take input for leave application
      //if the role is manager we should display all the leave application submitted to this manager
      //manager will see the list he will either approve or reject the leave
      //when an employee is alreade have a history of leave it should be displayed before the new leave apply
      
      
      Manager manager=new Manager(1,"Nila","HR Department");
      
      Employee employee=new Employee(101,"John");
      List<LeaveApplication> leaveApplicationToManager=new LinkedList<>();
      while(true) {
    	  System.out.println("\n Leave Management Application");
    	  System.out.println("1 Employee -Submit Leave Application");
    	  System.out.println("2 Manager -Review Leave Applications");
    	  System.out.println("3 Exit");
    	  System.out.println("Enter your Role");
    	  int role=scanner.nextInt();
    	  scanner.nextLine();
    	  if(role==1) {
    		  employee.displayLeaveHistory();
    		  System.out.println("Enter From date(YYYY-MM-DD)");
    		  String fromDate=scanner.nextLine();
    		  System.out.println("Enter to date(YYYY-MM-DD)");
    		  String toDate=scanner.nextLine();
    		  System.out.println("Enter reason for leave");
    		  String reason=scanner.nextLine();
    		  LeaveApplication leaveApplication=new LeaveApplication(employee.getId(),fromDate,toDate,reason);
    		  employee.submitLeaveApplication(leaveApplication);
    		  LeaveApplication.add(leaveApplication);
    	  }
    	  else if(role==2) {
    		  manager.reviewLeaveApplication(leaveApplicationToManager);
    	  }
    	  else if(role==3) {
    		  System.out.println("Exiting the system.Goodbye!");
    		  break;
    	  }
    	  else
    	  {
    		  System.out.println("Invalid input.Please try again.");
    	  }
    	  
      }
      scanner.close();
	}

}*/
	static List<Employee> employees=new LinkedList<>();
	static List<Manager> managers=new LinkedList<>();
	static List<LeaveApplication> allLeaveRequest=new LinkedList<>();
	static Scanner scanner=new Scanner(System.in);
	
	public static void init() {
		Employee emp1=new Employee(101,"Nimisha");
		Employee emp2=new Employee(102,"Krish");
		Employee emp3=new Employee(103,"Krishna");
		Employee emp4=new Employee(104,"Yadhu");
		Employee emp5=new Employee(105,"Nandu");
		Employee emp6=new Employee(106,"Nandana");
		employees.add(emp1);
		employees.add(emp2);
		employees.add(emp3);
		employees.add(emp4);
		employees.add(emp5);
		employees.add(emp6);
		
		Manager manager1=new Manager(1, "Neenu", "HR");
		Manager manager2=new Manager(2, "Neetha", "IT");
		managers.add(manager1);
		managers.add(manager2);
		
	}
	public static void applyLeave(String loginName) {
		Employee emp=null;
		for(Employee employee:employees) {
			if(employee.getName().equalsIgnoreCase(loginName)) {
				emp=employee;
			}
			}
		if(emp!=null) {
			System.out.println("Leave History for"+emp.getName()+":");
			displayLeaveHistory(emp.getId());
			System.out.println("Enter your Manager Id:");
			int mgrId=scanner.nextInt();
			System.out.println("Enter your FROM date of leave:");
			LocalDate fromDate=LocalDate.parse(scanner.next());
			
			System.out.println("Enter your TO date of leave:");
			LocalDate toDate=LocalDate.parse(scanner.next());
			System.out.println("Enter your leave reason:");
			String reason=scanner.next();
			
			LeaveApplication leaveApp=new LeaveApplication();
			leaveApp.setEmpId(mgrId);
			leaveApp.setManagerId(mgrId);
			leaveApp.setFromDate(fromDate);
			leaveApp.setToDate(toDate);
			leaveApp.setReason(reason);
			System.out.println("Leave applied successfully");
			allLeaveRequest.add(leaveApp);
			
		}
		else
		{
			System.out.println("employee not present");
		}
	}
	public static void displayLeaveHistory(int employeeId)
	{
		boolean hasLeaveHistory=false;
		for(LeaveApplication leave:allLeaveRequest) {
			if(leave.getEmpId()==employeeId)
			{
				System.out.println(leave);
				hasLeaveHistory=true;
			}
		}
		if(!hasLeaveHistory) {
			System.out.println("No previous leave history found!");
		}
	}
	public static void getAllLeaveApplication(String loginName) {
		Manager mgr=null;
		for(Manager manager:managers) {
			if(manager.getName().equalsIgnoreCase(loginName)) {
				mgr=manager;
				break;
			}
		}
		if(mgr!=null) {
		
			System.out.println("Leave Application for Manager"+mgr.getName()+":");
			
			for(LeaveApplication leave:allLeaveRequest) {
				System.out.println("hlo");
				if(leave.getManagerId()==mgr.getId()) {
					System.out.println("kk");
					System.out.println(leave);
					System.out.println("Do you want to approve or reject this leave request(approve/reject));");
					String decission=scanner.next();
					if(decission.equalsIgnoreCase("approve")) {
						leave.setApprovedorRejected("Approved");
						System.out.println("Leave approved");
					}else if(decission.equalsIgnoreCase("reject")) {
						leave.setApprovedorRejected("Rejected");
						System.out.println("Leave rejected");
					}
					else
						System.out.println("Invalid decission");
				}
			}
		}
		else
		{
			System.out.println("Manager not found!");
		}
	}
	public static void main(String[] args) {
		String role;
		String loginName;
		init();
		System.out.println("Are you manager or employee?");
		role=scanner.nextLine();
		System.out.println("Enter your name");
		loginName=scanner.nextLine();
		if(role.equalsIgnoreCase("Employee")) {
			applyLeave(loginName);
			
		}else if(role.equalsIgnoreCase("Manager")) {
			getAllLeaveApplication(loginName);
		}
	}
}