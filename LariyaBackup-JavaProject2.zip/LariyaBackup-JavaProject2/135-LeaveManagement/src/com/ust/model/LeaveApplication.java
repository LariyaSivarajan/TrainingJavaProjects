package com.ust.model;

import java.time.LocalDate;

public class LeaveApplication {
  int empId;
  int managerId;
 LocalDate fromDate;
 
 LocalDate toDate;
 String reason;
 String approvedorRejected;
public LeaveApplication(int empId, int managerId, LocalDate fromDate, LocalDate toDate, String reason
		) {
	super();
	this.empId = empId;
	this.managerId = managerId;
	this.fromDate = fromDate;
	this.toDate = toDate;
	this.reason = reason;
	this.approvedorRejected = "Pending";
}
@Override
public String toString() {
	return "LeaveApplication [empId=" + empId + ", managerId=" + managerId + ", fromDate=" + fromDate + ", toDate="
			+ toDate + ", reason=" + reason + ", approvedorRejected=" + approvedorRejected + "]";
}
public LeaveApplication() {
	super();
}
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public int getManagerId() {
	return managerId;
}
public void setManagerId(int managerId) {
	this.managerId = managerId;
}
public LocalDate getFromDate() {
	return fromDate;
}
public void setFromDate(LocalDate fromDate) {
	this.fromDate = fromDate;
}
public LocalDate getToDate() {
	return toDate;
}
public void setToDate(LocalDate toDate) {
	this.toDate = toDate;
}
public String getReason() {
	return reason;
}
public void setReason(String reason) {
	this.reason = reason;
}
public String getApprovedorRejected() {
	return approvedorRejected;
}
public void setApprovedorRejected(String approvedorRejected) {
	this.approvedorRejected = approvedorRejected;
}
  
 
 
}
