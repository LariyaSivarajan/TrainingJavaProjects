package com.ust.service;

import java.util.List;

import com.ust.model.Student;

public interface StudentService {

	boolean addStudent(Student student);

	Student searchStudent(int rollNumber);

	List<Student> getAllStudents();

	boolean updateStudent(Student student);

	boolean deleteStudent(int rollNumber);

}
