package com.ust.ui;

import com.ust.actions.Action;
import com.ust.actions.AddAction;
import com.ust.actions.DeleteAction;
import com.ust.actions.ExitAction;
import com.ust.actions.ListAction;
import com.ust.actions.SearchAction;
import com.ust.actions.UpdateAction;

public class ChoiceHandler {
	public static void handleChoice(int choice) {
		Action action = null;
		switch (choice) {
		case 1:
			action = new AddAction();
			break;
		case 2:
			action = new SearchAction();
			break;
		case 3:
			action = new UpdateAction();
			break;
		case 4:
			action = new ListAction();
			break;
		case 5:
			action = new DeleteAction();
			break;
		case 6:
			action = new ExitAction();
			break;
		default:
			action = new ExitAction();
			break;
		}
		action.go();
	}
}
