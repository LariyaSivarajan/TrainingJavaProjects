package com.ust.model;

public class Employee {

	String name;
	public String getName() {
		return name;
	}

	public void setName(String name) throws Exception {
		if(name==null ||name.isEmpty()) {
			Exception e=new Exception("Invalid Name for value");
			throw e;
		}
		this.name = name;
	}

	double basicSalary;

	public double getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(double basicSalary) throws Exception {
		if(basicSalary<0) {
			Exception e=new Exception("Negative Salary  Not Acceptable");
			throw e;
		}
		this.basicSalary = basicSalary;
	}
	
}
