package com.ust.actions;

import com.ust.model.Student;
import com.ust.service.StudentService;
import com.ust.service.StudentServiceImpl;
import com.ust.ui.util.ConsoleIO;

public class SearchAction extends Action {

	@Override
	public void init() {
		System.out.println("\n\n");
		System.out.println("\t\t Search Student");
		System.out.println("\t\t--------------------");

	}

	@Override
	public void execute() {
		// System.out.println("\t\t Searching Student");

		int searchRollNumber;
		ConsoleIO.prompt("Enter Roll Number to search");
		searchRollNumber = ConsoleIO.intInput();
		try {
	       	 if(searchRollNumber<0) {
	       		 throw new Exception();
	       	 }
	       	 
	        }catch(Exception e) {
	       	 System.err.println("\t\t Invalid Roll Number");
	       	 ConsoleIO.prompt("Enter Roll Number to Search :");
	       	searchRollNumber=ConsoleIO.intInput();
	        }
		StudentService service=new StudentServiceImpl();
		Student student = service.searchStudent(searchRollNumber);
		if (student != null) {
			System.out.println("\t\t Roll Number   :" + student.getRollNumber());
			System.out.println("\t\t Name          :" + student.getName());
			System.out.println("\t\t Gender        :" + student.getGender());
			System.out.println("\t\t Mark1         :" + student.getMark1());
			System.out.println("\t\t Mark2         :" + student.getMark2());
			System.out.println("\t\t Total         :" + student.getTotal());
			System.out.println("\t\t Average       :" + student.getAverage());

		} else {
			System.out.println("\n\n\t\t Student Not Found !!!");
		}
	}

	@Override
	public void complete() {
		System.out.println("\n\n");
		System.out.println("\t\tSearching  completed");
		System.out.println("\n\n");

	}
}
