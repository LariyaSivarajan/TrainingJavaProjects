package com.ust.actions;

import com.ust.service.StudentService;
import com.ust.service.StudentServiceImpl;
import com.ust.ui.util.ConsoleIO;

public class DeleteAction extends Action {

	boolean status;
	@Override
	public void init() {
		System.out.println("\n\n");
		System.out.println("\t\t Delete Student");
		System.out.println("\t\t--------------------");

	}

	@Override
	public void execute() {
		System.out.println("\t\t Deleting a Student");
		int rollNumberToDelete;
		ConsoleIO.prompt("Enter Roll Number to Delete");
		rollNumberToDelete = ConsoleIO.intInput();
		try {
	       	 if(rollNumberToDelete<0) {
	       		 throw new Exception();
	       	 }
	       	 
	        }catch(Exception e) {
	       	 System.err.println("\t\t Invalid Roll Number");
	       	 ConsoleIO.prompt("Enter Roll Number to Delete :");
	       	rollNumberToDelete=ConsoleIO.intInput();
	        }
		//db
        StudentService service=new StudentServiceImpl();
        status=service.deleteStudent(rollNumberToDelete);
	}

	@Override
	public void complete() {
		System.out.println("\n\n");
		if(status==true)
		System.out.println("\t\tDeleting  completed successfully");
		else
			System.out.println("\t\tDeleting  Failed");
		System.out.println("\n\n");
	}
}
