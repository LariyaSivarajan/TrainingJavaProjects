package com.ust.ui;

import com.ust.model.Book;
import com.ust.model.LibraryManagement;

public class Main {

	public static void main(String[] args) {
		LibraryManagement libraryManagement=new LibraryManagement();
		libraryManagement.issueBook("Poor Dady");
		libraryManagement.issueBook("The Hobbit");
		libraryManagement.printAvailableBook();
		System.out.println("The no of available books:"+libraryManagement.getAvailableBooksCount());
		
		System.out.println("The no of issued books:"+libraryManagement.getIssueBooksCount());
		libraryManagement.issueBook("The Oddessy");
		libraryManagement.issueBook("War and Peace");
		libraryManagement.printAvailableBook();
		
		libraryManagement.printAvailableBook();
		System.out.println("The no of available books:"+libraryManagement.getAvailableBooksCount());
		
		System.out.println("The no of issued books:"+libraryManagement.getIssueBooksCount());
	}

}
