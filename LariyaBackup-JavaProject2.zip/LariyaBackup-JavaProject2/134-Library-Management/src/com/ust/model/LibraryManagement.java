package com.ust.model;

import java.util.LinkedList;
import java.util.List;

public class LibraryManagement {
   List<Book> allBooks;
   List<Book> availableBooks;
public LibraryManagement() {
	super();
	this.allBooks=new LinkedList<>();
	availableBooks=new LinkedList<>();
	Book book=new Book("HarryPotter","JK Rowling",500,false);
	Book book1=new Book("HarryPotter","JK Rowling",500,true);
	
	 Book book2=new Book("HarryPotter","JK Rowling",500,true);
	 Book book3=new Book("HarryPotter1","JK Rowling1",600,true);
	 Book book4=new Book("HarryPotter2","JK Rowling2",700,false);
	 Book book5=new Book("HarryPotter3","JK Rowling3",800,false);
	 Book book6=new Book("HarryPotter4","JK Rowling4",900,false);
	 Book book7=new Book("HarryPotter5","JK Rowling5",1000,false);
	 Book book8=new Book("HarryPotter6","JK Rowling6",2000,true);
	 Book book9=new Book("HarryPotter7","JK Rowling7",3000,false);
	 Book book10=new Book("HarryPotter8","JK Rowling8",4000,false);
	
	//10 objs will be created
	//add allbooks to linkedlist
	 allBooks.add(book1);
	 allBooks.add(book2);
	 allBooks.add(book3);
	 allBooks.add(book4);
	 allBooks.add(book5);
	 allBooks.add(book6);
	 allBooks.add(book7);
	 allBooks.add(book8);
	 allBooks.add(book9);
	 allBooks.add(book10);
	 availableBooks.addAll(allBooks);
}

  public void issueBook(String bookName) {
	  //find the book which is issue and change the status as true;
	  
	  for(Book book:this.allBooks) {
		  if(book.getBookName().equalsIgnoreCase(bookName)) {
			  book.setIssueStatus(true);
		  }
	  }
  }
  
  public void printAvailableBook() {
	  //print all the books false
	  System.out.println("The Avauilable Books Listed Below!!!");
	  for(Book book:this.allBooks) {
		  if(!book.isIssueStatus())
			  System.out.println(book);
			  
	  }
	  
  }
  public int getAvailableBooksCount() {
	 long count=this.allBooks.stream().filter(c->!c.isIssueStatus()).count();
	 return (int) count;
  }
   public int getIssueBooksCount() {
	   long count=this.allBooks.stream().filter(c->c.isIssueStatus()).count();
	   return (int)count;
   }
}
