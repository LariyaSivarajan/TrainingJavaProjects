package com.ust.ui;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.ust.service.CustomerServiceImpl;



public class CustomerDeleteControllerServlet extends HttpServlet {

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String str_custId=request.getParameter("txt_id");
		int custId=Integer.parseInt(str_custId);
		
		CustomerServiceImpl service=new CustomerServiceImpl();
		
		boolean status=service.deleteCustomer(custId);
	
		if(status==true)
			request.setAttribute("delete_status", "Customer Deleted Successfully");
		
		else
			request.setAttribute("delete_status", "Customer Not Deleted ");
		
		
		RequestDispatcher dispatcher=request.getRequestDispatcher("CustomerDeleteResult.jsp");
		dispatcher.forward(request, response);
	}

}
