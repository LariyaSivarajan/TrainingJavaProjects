package com.ust.ui;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.ust.model.Customer;

import com.ust.service.CustomerServiceImpl;



public class CustomerAddingControllerServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String str_custId=request.getParameter("txt_id");
		String str_name=request.getParameter("txt_name");
		String str_balance=request.getParameter("txt_balance");
		String str_email=request.getParameter("txt_email");
		String str_phone=request.getParameter("txt_phone");
		
		
		
		int custId=Integer.parseInt(str_custId);
		String name=str_name;
		double balance=Double.parseDouble(str_balance);
		String email=str_email;
		String phone=str_phone;
		
		
		Customer customer=new Customer(custId, name, balance, email, phone);
		
		CustomerServiceImpl service=new CustomerServiceImpl();
		boolean status=service.addCustomer(customer);
		System.out.println(status);
		if(status==true)
		
			request.setAttribute("add_status", "New Customer Added Successfully");
		else
			request.setAttribute("add_status", "Customer Not Added");
		
		RequestDispatcher dispatcher=
				 request.getRequestDispatcher("CustomerAddResult.jsp");
		 dispatcher.forward(request, response);
	}

}
