package com.ust.ui;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.ust.model.Customer;

import com.ust.service.CustomerServiceImpl;



public class FetchCustomerForDeleteControllerServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String str_custIdr=request.getParameter("txt_id");
		int custId=Integer.parseInt(str_custIdr);
		
		CustomerServiceImpl service=new CustomerServiceImpl();
	    Customer customer=service.searchCustomer(custId);
	request.setAttribute("cust", customer);
	
	RequestDispatcher dispatcher=request.getRequestDispatcher("DeleteCustomer.jsp");
	dispatcher.forward(request, response);
	}

}
