package com.ust.ui;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.ust.model.Customer;

import com.ust.service.CustomerServiceImpl;

public class CustomerUpdateControllerServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String str_custId = request.getParameter("txt_id");
		String str_name = request.getParameter("txt_name");
		String str_balance = request.getParameter("txt_balance");
		String str_email = request.getParameter("txt_email");
		String str_phone = request.getParameter("txt_phone");

		int custId = Integer.parseInt(str_custId);
		String name = str_name;
		double balance = Double.parseDouble(str_balance);
		String email = str_email;
		String phone = str_phone;

		Customer customer=new Customer();
		customer.setId(custId);
		customer.setName(name);
		customer.setBalance(balance);
		customer.setEmail(email);
		customer.setPhone(phone);
		

		CustomerServiceImpl service = new CustomerServiceImpl();

		boolean status = service.updateCustomer(customer);
		if (status == true)
			request.setAttribute("update_status", "Customer Updated Successfully");

		else
			request.setAttribute("update_status", "Customer Not Updated ");

		RequestDispatcher dispatcher = request.getRequestDispatcher("CustomerUpdateResult.jsp");

		dispatcher.forward(request, response);
	}

}
