package com.ust.linkedlist;

public class LinkedList<T> {
	
	public static Node start=null;
	
	public void addToList(T data) {
		Node new_node=new Node(data);
		new_node.nextNode=null;
		if(start==null) {
			start=new_node;
		}
		else
		{
			Node currentNode=start;
			while(currentNode.nextNode!=null) {
				currentNode=currentNode.nextNode;
			}
			currentNode.nextNode=new_node;
		}
	}


	public int count() {
		Node currentNode=start;
		int count=0;
		while(currentNode!=null) {
			count++;
			currentNode=currentNode.nextNode;
		}
		return count;
	}
	public void insertAfter(T after,T data) {
		Node<T> current=start;
		Node<T> previous=null;
		while(current!=null) {
			previous=current;
			if(current.data==after)
				break;
			
			current=current.nextNode;
		}
		Node<T> new_node=new Node<T>(data);
		new_node.nextNode=current.nextNode;
		previous.nextNode=new_node;
	}
}