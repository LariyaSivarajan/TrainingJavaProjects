package com.ust.linkedlist;

public class Node<T> {
	
	public T data;
	public Node<T> nextNode;
	
	public Node(T d) {
		super();
		this.data = d;
		this.nextNode = null;
	}

}
