package com.ust.model;

import java.util.LinkedList;
import java.util.List;

public class CommonData {
	public static List<Movie> movies=new LinkedList<>();
	
	public static List<Person> persons=new LinkedList<>();
	public static List<Booking> bookings=new LinkedList<>();
	
	public static void init() {
		Movie movie1=new Movie(101,"Marco");
		Movie movie2=new Movie(102,"Harry Potter");
		Movie movie3=new Movie(103,"Lucifer");
		Movie movie4=new Movie(104,"Empuran");
		Movie movie5=new Movie(105,"Gilli");
		
		Person persons1=new Person(1,"Riya","Female",33);
		Person persons2=new Person(2,"Ram","Male",55);
		Person persons3=new Person(3,"Krishna","Female",30);
		Person persons4=new Person(4,"Krish","Male",35);
		Person persons5=new Person(5,"Priya","Female",28);
		movies.add(movie1);
		movies.add(movie2);
		movies.add(movie3);
		movies.add(movie4);
		movies.add(movie5);
		
		persons.add(persons1);
		persons.add(persons2);
		persons.add(persons3);
		persons.add(persons4);
		persons.add(persons5);
	}

}
