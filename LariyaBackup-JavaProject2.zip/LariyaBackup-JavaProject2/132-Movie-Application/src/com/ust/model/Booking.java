package com.ust.model;

import java.time.LocalDate;

public class Booking {
	
	int bookingId;
	Movie movie;
	
	Person person;
	
	LocalDate showDate;
	
	boolean cancelStatus;

	@Override
	public String toString() {
		return "Booking [movie=" + movie + ", person=" + person + ", showDate=" + showDate + ", cancelStatus="
				+ cancelStatus + "]";
	}

	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	public LocalDate getShowDate() {
		return showDate;
	}

	public void setShowDate(LocalDate showDate) {
		this.showDate = showDate;
	}

	public boolean isCancelStatus() {
		return cancelStatus;
	}

	public void setCancelStatus(boolean cancelStatus) {
		this.cancelStatus = cancelStatus;
	}

	public Booking(int bookingId,Movie movie, Person person, LocalDate showDate,boolean cancelStatus) {
		super();
		this.bookingId=bookingId;
		this.movie = movie;
		this.person = person;
		this.showDate = showDate;
		this.cancelStatus=cancelStatus;
	}

	public Booking() {
		super();
	}
	
	

}
