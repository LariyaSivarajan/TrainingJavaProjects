package com.ust.ui;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.ust.model.Employee;
import com.ust.model.Student;

/**
 * Servlet implementation class EmployeeControllerServlet
 */

public class EmployeeControllerServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String emp_id=request.getParameter("txt_id");
		
		String emp_name=request.getParameter("txt_name");
		String emp_gender=request.getParameter("rad_gender");
		
		String emp_basicSalary=request.getParameter("txt_basicSalary");
		
		
		int id=Integer.parseInt(emp_id);
		String name=emp_name;
		String gender=emp_gender;
		double basicSalary=Double.parseDouble(emp_basicSalary);
		
		
		Employee employee=new Employee(id, name, gender, basicSalary);
		
		request.setAttribute("emp", employee);
		RequestDispatcher dispatcher=request.getRequestDispatcher("EmployeeOutput.jsp");
		dispatcher.forward(request, response);
	}

}
