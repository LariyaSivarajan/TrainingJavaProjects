package com.ust.ui;

public class Servlet {

}
