package com.ust.ui;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.ust.model.Account;

/**
 * Servlet implementation class AccountControllerServlet
 */

public class AccountControllerServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	Account account=new Account(1010,"Keerthana",8000.00,"Savings");
	request.setAttribute("acc", account);
	
	
	RequestDispatcher dispatcher=request.getRequestDispatcher("AccountOutput.jsp");
	dispatcher.forward(request, response);
	}

}
