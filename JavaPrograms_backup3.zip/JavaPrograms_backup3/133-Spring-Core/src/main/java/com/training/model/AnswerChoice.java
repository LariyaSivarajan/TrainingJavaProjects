package com.training.model;

public class AnswerChoice {
		String answerText;
		boolean RightChoice;
		public String getAnswerText() {
			return answerText;
		}
		public void setAnswerText(String answerText) {
			this.answerText = answerText;
		}
		public boolean isRightChoice() {
			return RightChoice;
		}
		public void setRightChoice(boolean rightChoice) {
			RightChoice = rightChoice;
		}
		@Override
		public String toString() {
			return "AnswerChoice [answerText=" + answerText + ", RightChoice=" + RightChoice + "]";
		}
		
		
}
