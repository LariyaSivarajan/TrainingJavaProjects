package com.training.model;

public class Account {
		int accId;
		String type;
		double balance;
		public int getAccId() {
			return accId;
		}
		public void setAccId(int accId) {
			this.accId = accId;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		public double getBalance() {
			return balance;
		}
		public void setBalance(double balance) {
			this.balance = balance;
		}
		@Override
		public String toString() {
			return "Account [accId=" + accId + ", type=" + type + ", balance=" + balance + "]";
		}
		
}
