package com.training.model;

public class ContactInfo {
		String ownerName;
		String phone;
		String email;
		public String getOwnerName() {
			return ownerName;
		}
		public void setOwnerName(String ownerName) {
			this.ownerName = ownerName;
		}
		public String getPhone() {
			return phone;
		}
		public void setPhone(String phone) {
			this.phone = phone;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		@Override
		public String toString() {
			return "Contact [ownerName=" + ownerName + ", phone=" + phone + ", email=" + email + "]";
		}
		
		
}
