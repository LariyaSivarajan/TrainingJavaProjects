package com.training.model;

public class ThreeWheeler implements VehicleTax{
	double threeTax;

	@Override
	public void setTaxAmount(double amount) {
		this.threeTax=amount;
		
	}

	@Override
	public double calculateroadTax() {
		
		return this.threeTax*20;
	}

	@Override
	public String toString() {
		return "ThreeWheeler [threeTax=" + threeTax + "]";
	}

	
}
