package com.training.model;

public interface Shape {
		void setSize(int size);
		double getArea();

}
