package com.training.model;

public class TwoWheeler implements VehicleTax{
	double twoTax;

	@Override
	public double calculateroadTax() {
		
		return this.twoTax*10;
	}

	@Override
	public void setTaxAmount(double amount) {
		this.twoTax=amount;
		
	}

	@Override
	public String toString() {
		return "TwoWheeler [twoTax=" + twoTax + "]";
	}
	
}
