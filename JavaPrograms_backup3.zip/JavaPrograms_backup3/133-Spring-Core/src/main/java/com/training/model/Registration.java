package com.training.model;

public class Registration {
		String regNumber;
		String model;
		public String getRegNumber() {
			return regNumber;
		}
		public void setRegNumber(String regNumber) {
			this.regNumber = regNumber;
		}
		public String getModel() {
			return model;
		}
		public void setModel(String model) {
			this.model = model;
		}
		@Override
		public String toString() {
			return "Registration [regNumber=" + regNumber + ", model=" + model + "]";
		}
		
		
}
