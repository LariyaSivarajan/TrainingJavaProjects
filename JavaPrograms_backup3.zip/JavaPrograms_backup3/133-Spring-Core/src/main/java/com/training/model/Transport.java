package com.training.model;

public class Transport {
	Registration registraion;
	ContactInfo contact;
	VehicleTax vehicleTax;
	String typeOfVehicle;
	String vehicleNo;
	public Registration getRegistraion() {
		return registraion;
	}
	public void setRegistraion(Registration registraion) {
		this.registraion = registraion;
	}
	public ContactInfo getContact() {
		return contact;
	}
	public void setContact(ContactInfo contact) {
		this.contact = contact;
	}
	public String getTypeOfVehicle() {
		return typeOfVehicle;
	}
	public void setTypeOfVehicle(String typeOfVehicle) {
		this.typeOfVehicle = typeOfVehicle;
	}
	public String getVehicleNo() {
		return vehicleNo;
	}
	public void setVehicleNo(String vehicleNo) {
		this.vehicleNo = vehicleNo;
	}
	public VehicleTax getVehicleTax() {
		return vehicleTax;
	}
	public void setVehicleTax(VehicleTax vehicleTax) {
		this.vehicleTax = vehicleTax;
	}
	@Override
	public String toString() {
		return "Transport [registraion=" + registraion + ", contact=" + contact + ", vehicleTax=" + vehicleTax
				+ ", typeOfVehicle=" + typeOfVehicle + ", vehicleNo=" + vehicleNo + "]";
	}

	
	
	

}
