package com.training.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.model.HelloWorld;

public class Main2 {

	public static void main(String[] args) {
		// get the bean
		// print the bean object
		
		HelloWorld hw;

		ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		
		hw=(HelloWorld) context.getBean("helloWorldBean");
		System.out.println(hw.getMessage());
		System.out.println(hw.toString());
	}

}
