package com.training.model;

public class FourWheeler implements VehicleTax{
		double fourTax;

		@Override
		public void setTaxAmount(double amount) {
			this.fourTax=amount;
			
		}

		@Override
		public double calculateroadTax() {
			
			return this.fourTax*30;
		}

		@Override
		public String toString() {
			return "FourWheeler [fourTax=" + fourTax + "]";
		}

		
		
}
