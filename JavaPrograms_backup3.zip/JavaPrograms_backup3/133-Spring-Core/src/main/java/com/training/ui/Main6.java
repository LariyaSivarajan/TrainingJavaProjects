package com.training.ui;

import java.awt.HeadlessException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.model.HelloWorld;

public class Main6 {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		
		HelloWorld helloWorld=(HelloWorld) context.getBean("helloWorldBean");
		System.out.println(helloWorld);

	}

}
