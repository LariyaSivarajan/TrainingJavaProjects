package com.training.model;

public class Contact {
		String email;
		String phone;
		public Contact(String email, String phone) {
			super();
			this.email = email;
			this.phone = phone;
		}
		@Override
		public String toString() {
			return "Contact [email=" + email + ", phone=" + phone + "]";
		}
		
		
}
