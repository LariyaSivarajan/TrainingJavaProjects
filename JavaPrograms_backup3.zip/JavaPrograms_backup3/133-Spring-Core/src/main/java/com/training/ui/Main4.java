package com.training.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.model.HelloWorld;
import com.training.model.Student;

public class Main4 {

	public static void main(String[] args) {
		// 3 references of student
		//initialize
		//set rollNumber
		//print
		
		Student student1;
		Student student2;
		Student student3;
		
		ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		
		student1=(Student) context.getBean("studentBean");
		student1.setRollNumber(100);
		System.out.println(student1);

		student2=(Student) context.getBean("studentBean");
		student2.setRollNumber(200);
		System.out.println(student2);
		
		student3=(Student) context.getBean("studentBean");
		student3.setRollNumber(300);
		System.out.println(student3);
	}

}
