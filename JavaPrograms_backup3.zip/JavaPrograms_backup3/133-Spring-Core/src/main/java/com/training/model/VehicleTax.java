package com.training.model;

public interface VehicleTax {
		void setTaxAmount(double amount);
		double calculateroadTax();
}
