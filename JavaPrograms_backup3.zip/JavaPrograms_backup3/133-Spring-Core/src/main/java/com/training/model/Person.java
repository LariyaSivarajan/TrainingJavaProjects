package com.training.model;

import java.util.Arrays;

public class Person {
		String name;
		int age;
		String[] emailids;
		String[] contactNumbers;
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public int getAge() {
			return age;
		}
		public void setAge(int age) {
			this.age = age;
		}
		public String[] getEmailids() {
			return emailids;
		}
		public void setEmailids(String[] emailids) {
			this.emailids = emailids;
		}
		public String[] getContactNumbers() {
			return contactNumbers;
		}
		public void setContactNumbers(String[] contactNumbers) {
			this.contactNumbers = contactNumbers;
		}
		@Override
		public String toString() {
			return "Person [name=" + name + ", age=" + age + ", emailids=" + Arrays.toString(emailids)
					+ ", contactNumbers=" + Arrays.toString(contactNumbers) + "]";
		}
		
		
}
