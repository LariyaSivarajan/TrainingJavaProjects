package com.training.dto.response;

import java.util.List;

import com.training.model.Invoice;


public class InvoiceShowAllResponse {
	int statuscode;
	String description;
	List<Invoice> invoices;
	public int getStatuscode() {
		return statuscode;
	}
	public void setStatuscode(int statuscode) {
		this.statuscode = statuscode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<Invoice> getInvoices() {
		return invoices;
	}
	public void setInvoices(List<Invoice> invoices) {
		this.invoices = invoices;
	}
	@Override
	public String toString() {
		return "InvoiceShowAllResponse [statuscode=" + statuscode + ", description=" + description + ", invoices="
				+ invoices + "]";
	}
	
	
}
