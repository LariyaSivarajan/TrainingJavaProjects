package com.training.dto.response;

import com.training.model.Invoice;

public class InvoiceSearchResponse {
	int statusCode;
	String description;
	Invoice invoice;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Invoice getInvoice() {
		return invoice;
	}
	public void setInvoice(Invoice invoice) {
		this.invoice = invoice;
	}
	@Override
	public String toString() {
		return "InvoiceSearchResponse [statusCode=" + statusCode + ", description=" + description + ", invoice="
				+ invoice + "]";
	}
	
	
}
