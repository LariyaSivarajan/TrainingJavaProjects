package com.training.dto.request;

import com.training.model.Invoice;

public class InvoiceAddRequest {
		Invoice invoice;

		public Invoice getInvoice() {
			return invoice;
		}

		public void setInvoice(Invoice invoice) {
			this.invoice = invoice;
		}

		@Override
		public String toString() {
			return "InvoiceAddRequest [invoice=" + invoice + "]";
		}
		
		
}
