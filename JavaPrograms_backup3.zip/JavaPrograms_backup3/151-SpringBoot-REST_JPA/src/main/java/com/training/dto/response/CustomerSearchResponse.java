package com.training.dto.response;

import java.util.List;

import com.training.model.Customer;


public class CustomerSearchResponse {
	int statuscode;
	String description;
	Customer customers;
	public int getStatuscode() {
		return statuscode;
	}
	public void setStatuscode(int statuscode) {
		this.statuscode = statuscode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Customer getCustomers() {
		return customers;
	}
	public void setCustomers(Customer customers) {
		this.customers = customers;
	}
	@Override
	public String toString() {
		return "CustomerSearchResponse [statuscode=" + statuscode + ", description=" + description + ", customers="
				+ customers + "]";
	}
	
	
}
