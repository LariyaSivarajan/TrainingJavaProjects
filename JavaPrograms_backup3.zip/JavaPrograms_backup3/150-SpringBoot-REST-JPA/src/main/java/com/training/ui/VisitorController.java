package com.training.ui;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.dto.request.VisitorAddRequest;
import com.training.dto.request.VisitorDeleteRequest;
import com.training.dto.request.VisitorUpdateRequest;
import com.training.dto.response.VisitorAddResponse;
import com.training.dto.response.VisitorDeleteResponse;
import com.training.dto.response.VisitorModifyResponse;
import com.training.dto.response.VisitorSearchResponse;
import com.training.dto.response.VisitorShowAllByCityResponse;
import com.training.dto.response.VisitorShowAllByNameResponse;
import com.training.dto.response.VisitorShowAllResponse;
import com.training.exception.VisitorNotFoundException;
import com.training.model.Visitor;
import com.training.service.VisitorService;

@RestController
@RequestMapping(value = "/api")
public class VisitorController {

	@Autowired
	VisitorService service;

	@PostMapping(value = "/add")
	public ResponseEntity<VisitorAddResponse> f1(@RequestBody VisitorAddRequest request) {

		Visitor visitor1 = this.service.addNewVisitor(request.getVisitor());
		VisitorAddResponse response = new VisitorAddResponse();
		response.setStatusCode(200);
		response.setDescription("Visitors added successfully");
		response.setVisitor(visitor1);

		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}

	@PutMapping(value = "/modify")
	public ResponseEntity<VisitorModifyResponse> f2(@RequestBody VisitorUpdateRequest request) {
		VisitorModifyResponse response = new VisitorModifyResponse();
		Visitor visitor1 = this.service.searchVisitor(request.getVisitor());
		if (visitor1 != null) {
			Visitor visitor2 = this.service.updateVisitor(request.getVisitor());
			response.setStatusCode(200);
			response.setDescription("Visitors modify successfully");
			response.setVisitor(visitor2);
			return ResponseEntity.ok(response);
		} else {
			response.setStatusCode(404);
			response.setDescription("Visitors not modify successfully");
			response.setVisitor(null);
			return new ResponseEntity<VisitorModifyResponse>(response, HttpStatus.OK);
		}

	}

	@GetMapping(value = "/find/{vid}")
	public ResponseEntity<VisitorSearchResponse> f3(@PathVariable(name = "vid") int vid) throws Exception {
		VisitorSearchResponse response = new VisitorSearchResponse();
		Visitor visitor = this.service.searchVisitor(vid);
		if (visitor != null) {
			response.setStatusCode(200);
			response.setDescription("Visitors fetched successfully");
			response.setVisitor(visitor);
			return new ResponseEntity<VisitorSearchResponse>(response, HttpStatus.OK);
		} else {
			
			Exception exception=new VisitorNotFoundException("Visitor not found");
			throw exception;
		}
		//else {
			//response.setStatusCode(404);
			//response.setDescription("Visitors not found");
			//response.setVisitor(null);
			//return new ResponseEntity<VisitorSearchResponse>(response, HttpStatus.NOT_FOUND);
		//}
	}

	@GetMapping(value = "/showAll", produces = { MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<VisitorShowAllResponse> f4() {
		List<Visitor> visitors = this.service.getAllVisitors();
		VisitorShowAllResponse response = new VisitorShowAllResponse();
		response.setStatuscode(200);
		response.setDescription("All Visitors fetched");
		response.setVisitors(visitors);
		return ResponseEntity.ok(response);
	}

	@DeleteMapping(value = "/delete")
	public ResponseEntity<VisitorDeleteResponse> f5(@RequestBody VisitorDeleteRequest request) {
		VisitorDeleteResponse response = new VisitorDeleteResponse();
		Visitor visitor1 = this.service.searchVisitor(request.getVisitor());
		if (visitor1 != null) {
			try {

				this.service.deleteVisitor(request.getVisitor());
				response.setStatusCode(200);
				response.setDescription("Visitor Deleted Successfully");
				response.setDeleteStatus(true);
				return ResponseEntity.ok().body(response);

			} catch (Exception e) {
				response.setStatusCode(500);
				response.setDescription("Visitor not Deleted");
				response.setDeleteStatus(false);
				return ResponseEntity.ok().body(response);
			}
		} else {
			response.setStatusCode(404);
			response.setDescription("Visitor not Deleted");
			response.setDeleteStatus(false);
			return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
		}

	}
	@GetMapping("/showAllByName/{name}")
	public ResponseEntity<VisitorShowAllByNameResponse> f6(@PathVariable(name="name") String name){
		VisitorShowAllByNameResponse response=new VisitorShowAllByNameResponse();
		
		List<Visitor> visitorsBySameName=this.service.getVisitorsByName(name);
		if(visitorsBySameName.isEmpty()) {
			response.setStatuscode(200);
			response.setDescription("There are no visitors by same name "+name);
			response.setVisitors(visitorsBySameName);
		}
		else
		{
			response.setStatuscode(200);
			response.setDescription("There are "+visitorsBySameName.size()+" with same name ");
			response.setVisitors(visitorsBySameName);
		}
		return ResponseEntity.ok(response);
	}
	
	@GetMapping("/showAllByCity")
	public ResponseEntity<VisitorShowAllByCityResponse> f7(@RequestParam(name="txt_city") String city){
		VisitorShowAllByCityResponse response=new VisitorShowAllByCityResponse();
		List<Visitor> visitorsByCity=this.service.getVisitorsByCity(city);
		if(visitorsByCity.isEmpty()) {
			response.setStatuscode(200);
			response.setDescription("There are no visitors by same name "+city);
			response.setVisitors(visitorsByCity);
		}
		else
		{
			response.setStatuscode(200);
			response.setDescription("There are "+visitorsByCity.size()+" with same city ");
			response.setVisitors(visitorsByCity);
		}
		return ResponseEntity.ok(response);
	}
}
