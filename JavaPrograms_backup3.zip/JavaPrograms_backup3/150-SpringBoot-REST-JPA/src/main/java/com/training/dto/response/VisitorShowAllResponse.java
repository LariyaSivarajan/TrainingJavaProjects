package com.training.dto.response;

import java.util.List;

import com.training.model.Visitor;

public class VisitorShowAllResponse {
	int statuscode;
	String description;
	List<Visitor> visitors;
	public int getStatuscode() {
		return statuscode;
	}
	public void setStatuscode(int statuscode) {
		this.statuscode = statuscode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<Visitor> getVisitors() {
		return visitors;
	}
	public void setVisitors(List<Visitor> visitors) {
		this.visitors = visitors;
	}
	@Override
	public String toString() {
		return "VisitorShowAllResponse [statuscode=" + statuscode + ", description=" + description + ", visitors="
				+ visitors + "]";
	}
	
	

}
