package com.training.exception;

public class VisitorNotFoundException extends Exception{

	public VisitorNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public VisitorNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public VisitorNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public VisitorNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public VisitorNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}
