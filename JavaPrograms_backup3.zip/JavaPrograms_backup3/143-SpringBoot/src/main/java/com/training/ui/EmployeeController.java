package com.training.ui;

import java.util.Collection;
import java.util.LinkedList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.training.model.Employee;

@Controller
@RequestMapping(value="/employee")
public class EmployeeController {
	@GetMapping(value="/display")
	public String f1(Model model) {
		Employee employee=new Employee(100, "Manu", 50000.00, "Male");
		model.addAttribute("emp", employee);
		return "EmployeeDisplay";
	}
	
	@GetMapping(value="/listing")
	public String f2(Model model) {
		Employee e1=new Employee(100, "Manu", 50000.00, "Male");
		Employee e2=new Employee(101, "Meenu", 33000.00, "Female");
		Employee e3=new Employee(102, "Keerthi", 31000.00, "Female");
		Employee e4=new Employee(103, "Ram", 55000.00, "Male");
		Employee e5=new Employee(104, "Surya", 20000.00, "Male");
		
		Collection<Employee> employees=new LinkedList<Employee>();
		employees.add(e1);
		employees.add(e2);
		employees.add(e3);
		employees.add(e4);
		employees.add(e5);
		model.addAttribute("empl", employees);
		return "EmployeeListing";
	}
	
}
