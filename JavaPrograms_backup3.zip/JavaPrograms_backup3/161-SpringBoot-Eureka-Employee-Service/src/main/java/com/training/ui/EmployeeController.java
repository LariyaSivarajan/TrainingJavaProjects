package com.training.ui;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.model.Employee;

@RestController
public class EmployeeController {
		//annotation
		@GetMapping("/employees")
		public ResponseEntity<List> f1(){
			//create 3 emp
			//put the in list
			//return list
			
			Employee emp1=new Employee(101, "Manu", 30000.00);
			Employee emp2=new Employee(102, "Meenu", 45000.00);
			Employee emp3=new Employee(103, "Seetha", 5000.00);
			
			List<Employee> empList=new ArrayList<>();
			empList.add(emp1);
			empList.add(emp2);
			empList.add(emp3);
			
			return  ResponseEntity.ok(empList);
			
			
		}
}
