package com.training.model;

public class Address {
		String doorName;
		String cityName;
		String pincode;
		
		
		public Address() {
			super();
		}
		public Address(String doorName, String cityName, String pincode) {
			super();
			this.doorName = doorName;
			this.cityName = cityName;
			this.pincode = pincode;
		}
		public String getDoorName() {
			return doorName;
		}
		public void setDoorName(String doorName) {
			this.doorName = doorName;
		}
		public String getCityName() {
			return cityName;
		}
		public void setCityName(String cityName) {
			this.cityName = cityName;
		}
		public String getPincode() {
			return pincode;
		}
		public void setPincode(String pincode) {
			this.pincode = pincode;
		}
		@Override
		public String toString() {
			return "Address [doorName=" + doorName + ", cityName=" + cityName + ", pincode=" + pincode + "]";
		}
		
		
}
