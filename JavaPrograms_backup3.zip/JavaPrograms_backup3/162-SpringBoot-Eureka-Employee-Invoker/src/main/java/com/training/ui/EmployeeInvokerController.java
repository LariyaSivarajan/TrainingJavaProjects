package com.training.ui;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;

@RestController
public class EmployeeInvokerController {
		//connect to the rest controller url to get the employee
		//return the list
	
	@Autowired
	@Lazy
	private EurekaClient eurekaClient;
	
	@Value("${spring.application.name}")
	private String appName;
	
	@Autowired
	private RestTemplateBuilder builder;
	
	@GetMapping("/invokeEmployee")
	public ResponseEntity<List> f1() {
		RestTemplate template=builder.build();
		InstanceInfo instanceInfo=eurekaClient.getNextServerFromEureka("161-SPRINGBOOT-EUREKA-EMPLOYEE-SERVICE", false);
		String baseUrl=instanceInfo.getHomePageUrl();
		
		ResponseEntity<List> result=template.getForEntity(baseUrl+"/employees",List.class);
		return result;
		
	}
}
