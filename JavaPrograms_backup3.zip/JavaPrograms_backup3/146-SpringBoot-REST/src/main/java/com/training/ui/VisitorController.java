package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.training.model.Visitor;

@RestController
@RequestMapping("/api")
public class VisitorController {
		
		@GetMapping("/showVisitor")
		public Visitor f1() {
			Visitor visitor=new Visitor(1055, "Kiran", "Male", 23);
			return visitor;
		}
		
		@GetMapping("/visitors")
		public List<Visitor> f2(){
			List<Visitor> allVisitors;
			allVisitors=new LinkedList<>();
			
			allVisitors.add(new Visitor(1055, "Kiran", "Male", 23));
			allVisitors.add(new Visitor(1056, "Meena", "Female", 25));
			allVisitors.add(new Visitor(1057, "Sita", "Female", 23));
			
			return allVisitors;
		}
}
