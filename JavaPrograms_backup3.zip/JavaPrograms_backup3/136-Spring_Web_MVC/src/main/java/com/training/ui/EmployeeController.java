package com.training.ui;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.training.model.Employee;

@Controller
public class EmployeeController {
		
	@RequestMapping("/emp")	
	public ModelAndView f1() {
		ModelAndView mav=new ModelAndView("empOutput");
		Employee employee=new Employee(1001, "Manu", "Male", "Mumbai", 40000.00);
		mav.addObject("empl", employee);
		return mav;
	}
	
	@RequestMapping("/input")	
	public ModelAndView f2() {
		ModelAndView mav=new ModelAndView("empInput");
		Employee employee=new Employee();
		mav.addObject("emp", employee);
		return mav;
	}
	
	@RequestMapping("/output")	
	public String f3(@ModelAttribute(name="emp") @Valid Employee employee, BindingResult result,Map<String,Object> modelmap) {
		
		if(result.hasErrors()) {
			return "empInput";
		}
		else {
			modelmap.put("empl", employee);
			return "empOutput";
		}
		
	}
	
	@RequestMapping("/allemployees")	
	public ModelAndView f4() {
		ModelAndView mav=new ModelAndView("emplist");
		Employee employee1=new Employee(101, "Rahul", "Male", "Chennai", 14000.00);
		Employee employee2=new Employee(102, "Seetha", "Female", "Pune", 29000.00);
		Employee employee3=new Employee(103, "Ram", "Male", "Delhi", 35000.00);
		Employee employee4=new Employee(104, "Suman", "Female", "Hyderabad",33300.00);
		Employee employee5=new Employee(105, "Surya", "Male", "Chennai", 50000.00);
		List<Employee> employees=new LinkedList<>();
		employees.add(employee1);
		employees.add(employee2);
		employees.add(employee3);
		employees.add(employee4);
		employees.add(employee5);
		
		mav.addObject("emps", employees);
		return mav;
	}
}
