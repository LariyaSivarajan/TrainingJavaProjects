package com.training.ui;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


import com.training.model.Student;

@Controller
public class StudentController {
		
	@RequestMapping("/stud")	
	public ModelAndView f1() {
		ModelAndView mav=new ModelAndView("studOutput");
		Student student=new Student(100, "Arun", "MALE", 77, 88);
		mav.addObject("studo", student);
		return mav;
	}
	
	@RequestMapping("/input")	
	public ModelAndView f2() {
		ModelAndView mav=new ModelAndView("studInput");
		Student student=new Student();
		mav.addObject("stud", student);
		return mav;
	}
	
	@RequestMapping("/output")	
	public ModelAndView f3(@ModelAttribute(name="stud") Student student ) {
		ModelAndView mav=new ModelAndView("studOutput1");
		mav.addObject("studo", student);
		return mav;
	}
}
