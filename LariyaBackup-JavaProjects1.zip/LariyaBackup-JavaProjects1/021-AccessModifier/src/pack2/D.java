package pack2;

import pack1.A;
public class D {
	
	public void test3() {
		A obj=new A();
		//System.out.println(obj.v1);
			//	System.out.println(obj.v2);
				//System.out.println(obj.v3);
				System.out.println(obj.v4);
		
	}

}
