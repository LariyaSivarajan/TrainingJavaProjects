package pack1;

public class C extends A {
	
	public void test6() { //C is friend of A
		//System.out.println(v1);
		System.out.println(v2);
		System.out.println(v3);
		System.out.println(v4);
	}
	
	public void test7() { //C is friend of A
		A obj=new A();
		//System.out.println(obj.v1);
		System.out.println(obj.v2);
		System.out.println(obj.v3);
		System.out.println(obj.v4);
	}

}
