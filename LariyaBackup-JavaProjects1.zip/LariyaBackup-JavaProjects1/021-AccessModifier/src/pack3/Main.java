package pack3;

import pack2.D;
import pack1.A;


public class Main {

	public static void main(String[] args) {
		A obj=new A();
		obj.display();

	}

}
