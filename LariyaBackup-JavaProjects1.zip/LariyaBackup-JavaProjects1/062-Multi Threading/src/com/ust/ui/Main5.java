package com.ust.ui;

import com.ust.task.FileLetterCountingTask;

public class Main5 {

	public static void main(String[] args) {
		Thread t=new Thread(new FileLetterCountingTask("hello.txt"),"CT");
		t.start();
		
		Thread t1=new Thread(new FileLetterCountingTask("welcome.txt"),"CT1");
		t1.start();
		
		
		//create a thread to find the length of the text greet.txt
		
		Thread t3=new Thread(new FileLetterCountingTask("greet.txt"),"LCT2");
		t3.start();
	}

}
