package com.ust.ui;

public class Main1 {

	public static void main(String[] args) {

		// single threded pgm

		System.out.println("Program Begins....");

		System.out.println("Welcome");

		Thread thread = Thread.currentThread();
		thread.setName("Number Printer");

		String threadName = thread.getName();

		for (int i = 1; i <= 10; i++) {
			System.out.println(threadName + ":" + i);
			try {
				Thread.sleep(2000); // 1 sec
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		System.out.println("Thank you");
		System.out.println("Program ends....");
	}

}
