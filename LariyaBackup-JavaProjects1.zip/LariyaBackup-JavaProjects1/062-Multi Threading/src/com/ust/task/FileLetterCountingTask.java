package com.ust.task;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class FileLetterCountingTask implements Runnable {

	
	String fileName;
	
	
	
	public FileLetterCountingTask(String fileName) {
		super();
		this.fileName = fileName;
	}



	@Override
	public void run() {
		int count=0;
		//InputStream is=null;
		String name=Thread.currentThread().getName();
		try {
			InputStream is=new FileInputStream("hello.txt");
			while(true) {
				int i=is.read();
				if(i==-1)
					break;
				else
				{
					count++;
					System.out.println(name+":"+fileName+"Counting..."+count);
					System.out.println("Length  :"+fileName.length());
					Thread.sleep(1000);
				}
			}
			System.out.println(name+"Counted count is "+count);
			is.close();
		
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
	}

}
