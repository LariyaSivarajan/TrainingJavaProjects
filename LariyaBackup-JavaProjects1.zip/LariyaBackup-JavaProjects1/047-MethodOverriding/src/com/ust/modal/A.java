package com.ust.modal;

import java.io.IOException;
import java.sql.SQLException;

public class A {
	
	public void test1()throws SQLException,IOException {
		System.out.println("Io Exception..........");
		
	}
	
	public void test2() throws SQLException{
		System.out.println("Sql Exception..........");
	}

}
