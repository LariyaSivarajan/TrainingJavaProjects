package com.ust.modal;

import java.io.IOException;
import java.sql.SQLException;

public class C {
	public void test1() throws IOException,InterruptedException{
		
	}
public void test2()throws SQLException {
		
	}
public void test3() throws NullPointerException{
	
}

public void test4() throws IOException {
	
}
public void test5() throws Exception{
	
}

}
