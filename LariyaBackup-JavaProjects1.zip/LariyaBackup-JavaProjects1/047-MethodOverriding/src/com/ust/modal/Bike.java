package com.ust.modal;

public class Bike extends Vehicle{

}
