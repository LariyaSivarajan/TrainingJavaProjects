package com.ust.modal;

public class Car extends Vehicle{

}
