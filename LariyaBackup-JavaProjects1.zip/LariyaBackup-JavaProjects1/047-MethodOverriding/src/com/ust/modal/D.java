package com.ust.modal;

import java.io.IOException;

public class D extends C{
	
	@Override
	public void test1()throws IOException {
		//1.overriding methods can have 0 or more exception
		//2.overrind methods can have less exception than  super class method
	}
	@Override
	public void test2() throws InterruptedException{
		//cannot throw new checked exception not listed in super class
	}
	@Override
	public void test3()  throws NullPointerException,ArithmeticException{
		//4.can throw unchecked exception listed  in super class
	}
	@Override
	public void test4() throws Exception  {
		//5.should not throw narrow exception
		 
	}
	@Override
	public void test5() throws ArithmeticException {
		//6.can throw broader exception
	}


}
