package com.ust.modal;

public class J extends I {
	public Car create() {
		return new Car();
	}

}
