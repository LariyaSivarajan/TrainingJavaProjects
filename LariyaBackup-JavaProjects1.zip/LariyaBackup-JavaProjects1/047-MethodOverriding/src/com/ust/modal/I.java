package com.ust.modal;

public class I {
	public Vehicle create() { 
		return new Vehicle();
	}

}
