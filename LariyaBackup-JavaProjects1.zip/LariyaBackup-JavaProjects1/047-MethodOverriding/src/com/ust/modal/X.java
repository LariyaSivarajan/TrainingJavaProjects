package com.ust.modal;

public interface X {
	
	 void print(int n)throws Throwable;
	 void test(double d)throws Throwable;
		
	}
	


