package com.ust.modal;

public class Y implements X{

	@Override
	public void print(int n) throws Throwable {
		
		if(n<0) {
			throw new Exception("xyz");
		}
		// TODO Auto-generated method stub
		
	}

	@Override
	public void test(double d) throws Throwable {
		// TODO Auto-generated method stub
		if(d<100) {
			throw new Exception("abcd");
		}
	}

}
