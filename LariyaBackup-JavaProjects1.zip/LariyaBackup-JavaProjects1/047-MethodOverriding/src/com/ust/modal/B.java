package com.ust.modal;

import java.sql.SQLException;

public class B extends A {
	@Override
	public void test1() throws NullPointerException  {
		System.out.println("NullPointer exception B");
	}
	@Override
     public void test2() throws SQLException{
		System.out.println("Sql exceptions B");
	}

}
