package com.ust.modal;

public class Vehicle {

}
