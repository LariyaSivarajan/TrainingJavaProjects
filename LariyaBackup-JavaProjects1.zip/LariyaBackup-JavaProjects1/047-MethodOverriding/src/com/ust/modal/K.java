package com.ust.modal;

public class K extends I {
	
	@Override
	public Bike create() {
		return new Bike();
	}

}
