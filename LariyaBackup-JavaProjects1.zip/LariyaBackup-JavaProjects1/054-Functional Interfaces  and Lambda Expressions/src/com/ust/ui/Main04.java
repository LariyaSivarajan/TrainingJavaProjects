package com.ust.ui;

import com.ust.model.Acceptor;
import com.ust.model.Account;
import com.ust.model.BillItem;
import com.ust.model.Circle;

public class Main04 {

	public static void main(String[] args) {
		Acceptor<Circle> acceptor1;
		acceptor1 = new Acceptor<Circle>() {

			@Override
			public void accept(Circle obj) {
				System.out.println(obj.getRadius() + "," + obj.getArea());

			}

		};
		acceptor1.accept(new Circle(10));
		// Acceptor of Account
		// initialize
		// call accept

		Acceptor<Account> acceptor2;
		acceptor2 = new Acceptor<Account>() {

			@Override
			public void accept(Account obj) {
				System.out.println(obj.getCustomerName() + "," + obj.getBalance());

			}

		};
		acceptor2.accept(new Account("Ramu", 9000.00));

		Acceptor<BillItem> acceptor3;
		acceptor3 = new Acceptor<BillItem>() {

			@Override
			public void accept(BillItem obj) {
				System.out.println(obj.getItemName() + "," + obj.getItemValue());

			}

		};
		acceptor3.accept(new BillItem("Redmi", 2, 9000.00));

	}

}
