package com.ust.ui;

import com.ust.model.Acceptor;
import com.ust.model.Account;
import com.ust.model.BillItem;
import com.ust.model.Circle;
import com.ust.model.Employee;

public class Main06 {

	public static void main(String[] args) {
		Acceptor<Circle> acceptor1;
		acceptor1 = c -> System.out.println(c.getRadius() + "," + c.getArea());
		acceptor1.accept(new Circle(90));

		// Acceptor for Account
		// implement using lambda expression,should print the uppercase of name
		// invoke it

		Acceptor<Account> acceptor2;
		acceptor2 = c -> System.out.println(c.getCustomerName().toUpperCase() + "," + c.getBalance());
		acceptor2.accept(new Account("Lariya", 10000.00));

		Acceptor<BillItem> acceptor3;
		acceptor3 = c -> System.out.println(c.getItemName() + "," + c.getItemValue());
		acceptor3.accept(new BillItem("Samsung", 2, 10000.00));

		// Acceptor for employeee
		// implement using lambda
		// it should print name,city capital
		// gender capital,netsalary

		Acceptor<Employee> acceptor4;
		acceptor4 = c -> System.out.println(c.getName().toUpperCase() + "," + c.getCityName().toUpperCase() + ","
				+ c.getGender().toUpperCase() + "," + c.getNetSalary());
		acceptor4.accept(new Employee(101, "Lariya", "Female", "Tvm", 52000.00));

	}

}
