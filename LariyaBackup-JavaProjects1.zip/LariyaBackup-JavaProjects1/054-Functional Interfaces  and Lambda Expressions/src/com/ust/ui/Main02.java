package com.ust.ui;

import com.ust.model.Acceptor;
import com.ust.model.Account;
import com.ust.model.AccountAcceptor;
import com.ust.model.BillItem;
import com.ust.model.BillItemAcceptor;
import com.ust.model.Circle;
import com.ust.model.CircleAcceptor;

public class Main02 {

	public static void main(String[] args) {
		Acceptor<Circle> acceptor1=new CircleAcceptor();
		acceptor1.accept(new Circle(10));
		
		Acceptor<Account> acceptor2=new AccountAcceptor();
		acceptor2.accept(new Account("Ram",1000.00));
		
		
		Acceptor<BillItem> acceptor3=new BillItemAcceptor();
		acceptor3.accept(new BillItem("Oppo",2,20000.00));

	}

}
