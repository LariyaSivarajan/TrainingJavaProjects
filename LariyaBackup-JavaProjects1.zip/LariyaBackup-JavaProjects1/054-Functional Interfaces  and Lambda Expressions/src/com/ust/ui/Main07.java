package com.ust.ui;

import com.ust.model.Tester;

public class Main07 {

	public static void main(String[] args) {
		Tester<String> tester1;
		tester1 = (String s) -> {
			return s.length() >= 10;
		};
		System.out.println(tester1.test("Welcome to Ust"));

		Tester<Integer> tester2;
		tester2 = i -> i % 2 == 0;
		System.out.println(tester2.test(33));

		// Tester for Double
		// implementation lambda exprn return true if the double value>=5000 else false

		Tester<Double> tester3;
		tester3 = i -> i >= 5000.0;
		System.out.println(tester3.test(4000.0));

	}

}
