package com.ust.ui;

import com.ust.model.Acceptor;
import com.ust.model.DoubleAcceptor;
import com.ust.model.IntegerAcceptor;
import com.ust.model.StringAcceptor;

public class Main01 {

	public static void main(String[] args) {
		Acceptor<String> acceptor = new StringAcceptor();
		acceptor.accept("Welcome!");

		Acceptor<Integer> acceptor1 = new IntegerAcceptor();
		acceptor1.accept(10);

		Acceptor<Double> acceptor2 = new DoubleAcceptor();
		acceptor2.accept(Double.valueOf(10));
	}

}
