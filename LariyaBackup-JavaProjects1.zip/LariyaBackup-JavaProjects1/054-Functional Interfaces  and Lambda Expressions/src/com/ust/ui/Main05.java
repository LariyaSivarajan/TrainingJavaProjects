package com.ust.ui;

import com.ust.model.Acceptor;

public class Main05 {

	public static void main(String[] args) {
		// Lambda Expression ;

		Acceptor<String> acceptor1;
		acceptor1 = (String s) -> {
			System.out.println(s.length());
			System.out.println(s.toUpperCase());
		};
		acceptor1.accept("Welcome");

		Acceptor<Integer> acceptor2;
		acceptor2 = (Integer obj) -> System.out.println(obj.doubleValue());
		acceptor2.accept(400);

		Acceptor<Double> acceptor3;
		acceptor3 = d -> System.out.println(d.intValue());
		acceptor3.accept(500.00);

		// Acceptor for StringBuffer
		// Implementation to print the reverse of StringBuffer
		// call accept method with a stringBuffer

		Acceptor<StringBuffer> acceptor4;
		acceptor4 = sb -> System.out.println(sb.reverse());
		acceptor4.accept(new StringBuffer("Lariya"));
	}

}
