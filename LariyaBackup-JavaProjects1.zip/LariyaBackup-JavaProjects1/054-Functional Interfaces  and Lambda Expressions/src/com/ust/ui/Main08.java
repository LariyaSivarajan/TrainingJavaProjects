package com.ust.ui;

import com.ust.model.Account;
import com.ust.model.Circle;
import com.ust.model.Employee;
import com.ust.model.Tester;

public class Main08 {

	public static void main(String[] args) {
		Tester<Circle> tester1;
		tester1 = c -> c.getArea() > 100;
		System.out.println(tester1.test(new Circle(1)));

		Tester<Account> tester2;
		tester2 = a -> a.getBalance() > 10000.00;
		System.out.println(tester2.test(new Account("Ram", 12000.00)));

		// tester for employee
		// implement check if the employee is from "mumbai"
		// invoke

		Tester<Employee> tester3;
		tester3 = a -> a.getCityName().equalsIgnoreCase("Mumbai");
		System.out.println(tester3.test(new Employee(101, "Lariya", "Female", "Mumbai", 52000.00)));

		// tester for employee
		// implement check if the employee is a female
		// invoke

		Tester<Employee> tester4;
		tester4 = a -> a.getGender().equalsIgnoreCase("Female") ;
		System.out.println(tester4.test(new Employee(101, "Lariya", "Female", "Tvm", 52000.00)));

		// tester for employee
		// implement check if the employee netsalary is above 500000.00"

		// invoke

		Tester<Employee> tester5;
		tester5 = a -> a.getNetSalary() >= 50000.00;
		System.out.println(tester4.test(new Employee(101, "Lariya", "Female", "Mumbai", 52000.00)));
	}

}
