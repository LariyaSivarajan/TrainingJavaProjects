package com.ust.model;

public class BillItemAcceptor implements Acceptor<BillItem> {

	@Override
	public void accept(BillItem obj) {
		System.out.println(obj.getItemName()+" ,"+obj.getItemValue());
		
	}
	//implements Acceptor<BillItem>
	
	
	
	
	
	
	
	
	//accept function should print itemName,itemValue

}
