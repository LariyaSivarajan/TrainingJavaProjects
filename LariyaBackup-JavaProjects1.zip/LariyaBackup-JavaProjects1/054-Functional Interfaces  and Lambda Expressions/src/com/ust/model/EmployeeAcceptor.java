package com.ust.model;

public class EmployeeAcceptor implements Acceptor<Employee>{

	@Override
	public void accept(Employee obj) {
		System.out.println(obj.getName()+","+obj.getCityName()+","+obj.getGender()+","+obj.getNetSalary());
		
	}

}
