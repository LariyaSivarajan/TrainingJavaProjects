package com.ust.model;
@FunctionalInterface
public interface Tester <T>{
	boolean test(T obj);

}
