package com.ust.model;

@FunctionalInterface
public interface Acceptor<T> {
	
	void accept(T  obj);

}
