package com.ust.ui;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

import com.ust.modal.Bill;
import com.ust.modal.CourseItem;
import com.ust.util.ConsoleIO;

public class Main1 {

	public static void main(String[] args) throws IOException {
		int billNumber;
		String customerName;
		System.out.println("Enter Bill Number");
		billNumber=ConsoleIO.inputInt();
		
		System.out.println("Enter Customer Name");
		customerName=ConsoleIO.inputString();
		
		char anymore;
		
		Bill bill=new Bill(billNumber,customerName);
		do {
			String itemName;
			int quantity;
			double price;
			System.out.println("Enter Item name :");
			itemName=ConsoleIO.inputString();
			
			System.out.println("Enter Quantity :");
			quantity=ConsoleIO.inputInt();
			System.out.println("Enter Price :");
			price=ConsoleIO.inputDouble();
			bill.addBillItem(itemName, quantity, price);
			
			System.out.println("Add more items? :");
			anymore=ConsoleIO.inputChar();
			
		}while(anymore=='Y'||anymore=='y');
			
		bill.printBill();
		
		//serialize the bill object to a file
		
		try {
			
			
			
			OutputStream os=new FileOutputStream("bill.dat");
			ObjectOutputStream oos=new ObjectOutputStream(os);
			
			oos.writeObject(bill);
			oos.flush();  //serialization
			oos.close();
			os.close();
			
			
		}catch(Throwable e) {
			System.err.println(e.getMessage());
			System.exit(0);
		}
		
	}

}
