package com.ust.ui;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;

import com.ust.modal.Bill;


public class Main2 {

	public static void main(String[] args) {
		 Bill bill=null;
		//deserialize bill object from the file
		//bill.printBill();
		
		
try {
			
			InputStream is=new FileInputStream("bill.dat");
			ObjectInputStream ois=new ObjectInputStream(is);
			
			bill=(Bill)ois.readObject(); //deserialization
			System.out.println(bill);
			bill.printBill();
			ois.close();
			is.close();
			
		}catch(Exception e) {
			System.err.println(e);
			System.exit(0);
			
		}

	}

}
