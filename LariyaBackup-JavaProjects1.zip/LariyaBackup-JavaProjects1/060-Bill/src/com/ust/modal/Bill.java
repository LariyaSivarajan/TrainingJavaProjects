package com.ust.modal;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class Bill implements Serializable {
	private int billNumber;
	private String customerName;
	private Set<BillItem> billItems;

	public Bill(int billNumber, String customerName) {
		super();
		this.billNumber = billNumber;
		this.customerName = customerName;
		billItems = new HashSet<>();

	}

	public int getBillNumber() {
		return billNumber;
	}

	public void setBillNumber(int billNumber) {
		this.billNumber = billNumber;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Set<BillItem> getBillItems() {
		return billItems;
	}

	public void setBillItems(Set<BillItem> billItems) {
		this.billItems = billItems;
	}

	public void addBillItem(String itemName, int quantity, double price) {
		BillItem bi = new BillItem(itemName, quantity, price);
		this.billItems.add(bi);
	}

	public void printBill() {
		System.out.println("-----------------------------------------------------------------");
		System.out.println("Bill Number          :" + this.billNumber);
		System.out.println("Customer Name        : " + this.customerName);
		System.out.println("-----------------------------------------------------------------");
		System.out.println("SlNo     Item Name        Quantity         Price            Value");
		System.out.println("-----------------------------------------------------------------");
		int slNo = 1;
		double totalBillAmount = 0.0;
		for (BillItem bi : this.billItems) {
			System.out.printf("\n%d\t %-20s %3d \t %10.2f \t %10.2f\n", slNo++, bi.getItemName(), bi.getQuantity(),
					+bi.getPrice(), bi.getItemValue());

			totalBillAmount = totalBillAmount + bi.getItemValue();
		}

		System.out.println("---------------------------------------------------------------------");
		System.out.println("Total Amount     :" + totalBillAmount);

	}

	public Bill() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
