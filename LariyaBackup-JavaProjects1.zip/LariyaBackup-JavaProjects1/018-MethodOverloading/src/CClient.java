
public class CClient {

	public static void main(String[] args) {
		C obj=new C();
		obj.display(100);
		
		int v1=900;
		obj.display(v1);
		
		short v2=800;
		obj.display(v2);
		obj.display(10,20,30,40);
		obj.display((byte)100);

	}

}
