
public class BClient {

	public static void main(String[] args) {
		B obj=new B();
		//obj.add(5);
		B.add(5);
		obj.add(true);
		obj.add(5,10);
		obj.add(15,10,20.0f);
		obj.add(15,10,20.0f,900.00);

	}

}
