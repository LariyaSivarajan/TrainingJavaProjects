import java.util.Arrays;

public class C {
	
	void display(int p) {
		System.out.println("Display with int"+p);
	}
	void display(short p) {
		System.out.println("Display with short"+p);
	}
	
	void display(int... a) {
		System.out.println("Display with int..."+Arrays.toString(a));
	}
	void display(byte a) {
		System.out.println("Display with byte"+a);
	}
}
