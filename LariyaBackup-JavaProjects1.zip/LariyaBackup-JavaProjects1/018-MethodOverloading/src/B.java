
public class B {
	
	//overload a method(5times)
	public static void add(int a)
	{
		int result=a+a;
		System.out.println(result);
	}
	void add(int a,int b) {
		int result1=a+b;
		System.out.println(result1);
	}
	void add(int a,int b,float c) {
		int result2=a+b+(int)c;
		System.out.println(result2);
	}
	void add(int a,int b,float c,double d) {
		int result3=a+b+(int)c+(int)d;
		System.out.println(result3);
		
	}
	
	int add(boolean isAdded) {
		System.out.println("add" + isAdded);
		return 0;
	}

}
