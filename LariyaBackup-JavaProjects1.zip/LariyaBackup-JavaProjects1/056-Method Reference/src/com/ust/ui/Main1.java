package com.ust.ui;

import com.ust.model.pack1.Addition;
import com.ust.model.pack1.Multiplication;
import com.ust.model.pack1.Subtraction;
import com.ust.model.pack1.Task;

public class Main1 {

	public static void main(String[] args) {
		Task task;
		//task=(x,y)->x+y;
		
		task=Addition::add;//method reference for static method
		System.out.println(task.execute(10,20));

		
		//task=(x,y)->x-y;
		task=Subtraction::subtract;
		System.out.println(task.execute(50,10));
		
		//task initialixze multiply
		//invoke execute
		
		task=Multiplication::multiply;
		System.out.println(task.execute(60,10));
	}

}
