package com.ust.ui;

import com.ust.model.pack3.Circle;
import com.ust.model.pack3.Employee;
import com.ust.model.pack3.Factory;

public class Main3 {

	public static void main(String[] args) {
		
		
		Factory<Circle> factory;
		//factory=(r)->new Circle(r);
		factory=Circle::new; //Method reference to a constructor
		Circle c=factory.create(10);
		System.out.println(c);
		
		Factory<Employee> factory1;
	    // factory1=(i)->new Employee(i);
		factory1=Employee::new;  //Method reference to a constructor
	     Employee e=factory1.create(1601);
	     System.out.println(e);

	}

}
