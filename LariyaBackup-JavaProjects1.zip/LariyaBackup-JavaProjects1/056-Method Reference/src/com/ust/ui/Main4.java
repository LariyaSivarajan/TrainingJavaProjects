package com.ust.ui;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;

public class Main4 {

	public static void main(String[] args) {
		List<String> names=new LinkedList<>();
		names.add("Prabhu");
		names.add("Shruthi Menon");
		names.add("Karthik");
		names.add("Arthi");
		
		Function<String, Integer>fn;
		fn=String::length;//Method reference
		//fn.apply(names.get(0));
		
		Integer r=fn.apply(names.get(1));
		System.out.println(r);
		
		
		Function<String, String>fn1;
		//fn1=(s)->s.toUpperCase();
		fn1=String::toUpperCase;
		String upperStr=fn1.apply(names.get(1));
		System.out.println(upperStr);

	}

}
