package com.ust.ui;

import com.ust.model.pack2.GoodBye;
import com.ust.model.pack2.Greet;
import com.ust.model.pack2.Hello;
import com.ust.model.pack2.Welcome;

public class Main2 {

	public static void main(String[] args) {
		Hello hello;
		
		//hello=()->System.out.println("Welcome");
		//hello.doIt();
		Welcome w=new Welcome(); //method reference for non static method
		hello=w::sayWelcome;
		hello.doIt();
		
		
		
		//hello=()->System.out.println("Good Bye");
		//hello.doIt();
		
		
		GoodBye gb=new GoodBye(); //method reference for non static method
		hello=gb::sayGoodBye;
		hello.doIt();
		
		
		Greet g=new Greet(); //method reference for non static method
		hello=g::greet;
		hello.doIt();

	}

}
