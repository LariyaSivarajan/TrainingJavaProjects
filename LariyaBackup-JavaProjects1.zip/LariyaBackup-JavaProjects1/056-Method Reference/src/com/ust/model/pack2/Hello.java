package com.ust.model.pack2;


@FunctionalInterface
public interface Hello {
	void doIt();

}
