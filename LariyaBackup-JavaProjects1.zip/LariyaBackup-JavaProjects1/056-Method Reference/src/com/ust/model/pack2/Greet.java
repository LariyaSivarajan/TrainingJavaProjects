package com.ust.model.pack2;

public class Greet {
	public void greet() {
		System.out.println("Hi how are you...");
	}

}
