package com.ust.model.pack3;

public class Circle {
	
	int radius;

	public Circle(int radius) {
		super();
		this.radius = radius;
	}

	@Override
	public String toString() {
		return "Circle [radius=" + radius + "]";
	}
	
	

}
