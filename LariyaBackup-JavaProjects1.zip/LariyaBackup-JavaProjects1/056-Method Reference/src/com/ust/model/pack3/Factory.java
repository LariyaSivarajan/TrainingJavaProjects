package com.ust.model.pack3;


@FunctionalInterface
public interface Factory<T> {
       T create(int data);
}
