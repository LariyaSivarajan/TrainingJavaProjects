package com.ust.ui;

import com.ust.modal.Department;

public class Main12 {

	public static void main(String[] args) {
		Department department=new Department("IT","Leela");
		department.addEmployee(101, "Deepa","Female","Mumbai", 10000.00);
		
		department.addEmployee(102, "Srimati","Female","Cochin", 20000.00);
		department.addEmployee(103, "Kiran","Male","Mumbai", 30000.00);
		department.addEmployee(104, "mamta","Female","Mumbai", 40000.00);
		department.printReport();
		department.updateEmployee(103, "Kavya","Female","Tvm", 50000.00);
		department.printReport();
		department.deleteEmployee(104);
		department.printReport();
	}

}
