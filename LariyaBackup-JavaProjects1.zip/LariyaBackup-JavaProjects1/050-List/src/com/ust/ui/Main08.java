package com.ust.ui;

import java.util.LinkedList;
import java.util.List;

import com.ust.modal.BillItem;

public class Main08 {

	public static void main(String[] args) {
		List<BillItem> billItems=new LinkedList<>();
		BillItem b1=new BillItem("redmi", 3,14000.00);
		billItems.add(b1);
		billItems.add(new BillItem("Samsung", 2, 15000.00));
		billItems.add(new BillItem("Oppo", 4, 20000.00));
		billItems.add(new BillItem("Iphone", 2, 24000.00));
		System.out.println("------------------------------------------------------------");
		System.out.println("SlNo   ItemName   Quantity     Price   Value");

		System.out.println("------------------------------------------------------------");
		
		double totalAmount=0.0;
		int slNo=1;
		for(BillItem item:billItems)
		{
			totalAmount+=item.getItemValue();
			System.out.println(slNo++ +"\t\t"+item.getItemName()+"\t\t"+item.getQuantity()+"\t\t"+item.getPrice()+"\t\t"+item.getItemValue());
		}

		System.out.println("------------------------------------------------------------");
		System.out.println("Total No Of Items  :"+billItems.size()+"\t\t"+"Bill Amount: (sum) "+totalAmount);

		System.out.println("------------------------------------------------------------");
	}

}
