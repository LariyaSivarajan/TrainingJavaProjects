package com.ust.ui;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

import com.ust.modal.Circle;

public class Main13 {

	public static void main(String[] args) {
		List<Circle> circles=new LinkedList<>();
		
		circles.add(new Circle(10));
		circles.add(new Circle(20));
		circles.add(new Circle(30));
		circles.add(new Circle(40));
		
		
		Iterator<Circle> it=circles.iterator();
		while(it.hasNext()) {
			Circle c=it.next();
			System.out.println(c);
		}
		System.out.println("--------------------------------------------------------");
		ListIterator<Circle> it1=circles.listIterator();
		while(it1.hasNext()) {
			System.out.println(it1.next());
		}
		System.out.println("--------------------------------------------------------");
		while(it1.hasPrevious()) {
			System.out.println(it1.previous());
		}

	}

}
