package com.ust.ui;

import java.util.LinkedList;
import java.util.List;

import com.ust.modal.Person;

public class Main09 {
	public static void main(String[] args) {
		List<Person> persons=new LinkedList<>();
		persons.add(new Person("Kiran",25));
		persons.add(new Person("Amit",20));
		persons.add(new Person("Nila",18));
		persons.add(new Person("Anandu",45));
		persons.add(new Person("Priya",35));
		System.out.println("-------------------------------------------------");
		System.out.println("Sl No       Name            Age");
		System.out.println("-------------------------------------------------");
		Person youngAgePerson=persons.get(0);
		Person elderAgePerson=persons.get(0);
		int slNo=1;
		for(Person person:persons) {
			System.out.println(slNo++ +"\t\t"+person.getName()+"\t\t"+person.getAge());
			if(person.compareTo(youngAgePerson)<0) {
				youngAgePerson=person;
			}
				
			if(person.compareTo(youngAgePerson)>0) {
				elderAgePerson=person;
			}
			
		}
		System.out.println("-------------------------------------------------");
		System.out.println("Younger Person Name:"+youngAgePerson.getName());
		System.out.println("Elder Person Name  :"+elderAgePerson.getName());
		System.out.println("-------------------------------------------------");
	}

}
