package com.ust.modal;

public class Manager extends Employee {

	int employeeCount;

	public Manager() {
		super();
	}

	public Manager(int id, String name, String gender, String cityName, double basic, int employeeCount) {
		super(id, name, gender, cityName, basic);
		this.employeeCount = employeeCount;
	}

	public int getEmployeeCount() {
		return employeeCount;
	}

	public void setEmployeeCount(int employeeCount) {
		this.employeeCount = employeeCount;
	}

	@Override
	public double getNetSalary() {
		double net = super.getNetSalary();
		net = net + (employeeCount * 1000);
		return net;

	}

	@Override
	public String toString() {
		return "\nManager [getNetSalary()=" + getNetSalary() + ", getId()=" + getId() + ", getName()=" + getName()
				+ ", getGender()=" + getGender() + ", getCityName()=" + getCityName() + ", getBasic()=" + getBasic()
				+ "]";
	}

}
