package com.ust.modal;

public class Person implements Comparable<Person> {

	String name;
	int age;

	public Person(int age) {
		super();
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Person(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}

	@Override
	public String toString() {
		return "\nPerson [name=" + name + ", age=" + age + "]";
	}

	@Override
	public int compareTo(Person o) {
		if (this.age < o.age)
			return -1;
		if (this.age > o.age)
			return -1;
		return 0;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + age;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Person))
			return false;
		Person other = (Person) obj;
		if (age != other.age)
			return false;
		return true;
	}

}
