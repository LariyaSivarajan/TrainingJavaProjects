
public class Main5 {

	public static void main(String[] args) {
		// print multiple of 10 btw 500 t0 1000
		//500,510....1000 for loop
		
		for(int i=500;i<=1000;i+=10)
		{
			System.out.println(i);
		}

	}

}
