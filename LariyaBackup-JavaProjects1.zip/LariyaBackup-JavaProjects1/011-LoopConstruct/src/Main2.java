
public class Main2 {
	public static void main(String[] args) {
		int count=1;
		while(count<=10)
		{
			int value=count*5;
			System.out.println(value);
			count++;
		}
	}
	
	

}
