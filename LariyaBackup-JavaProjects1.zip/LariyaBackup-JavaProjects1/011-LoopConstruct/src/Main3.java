import java.util.Scanner;

public class Main3 {

	public static void main(String[] args) {
		//to display a menu
        //menu options
		//add employee
		//search employee
		//display all employee
		//delete an employee 
		//exit
		//take input menuChoice from user
		//repeated if menuchoice==5
		
		int menuChoice;
		
		
		Scanner sc=new Scanner(System.in);
		do
		{
			System.out.println("1.Add employee");
			System.out.println("2.search employee");
			System.out.println("3.Display employee");
			System.out.println("4.delete employee");
			System.out.println("5.Exit");
			System.out.println("Enter the choice");
			menuChoice=sc.nextInt();
			System.out.println(menuChoice);
			
		}while(menuChoice!=5);
	    
			
				
		
	
	
	
}}

