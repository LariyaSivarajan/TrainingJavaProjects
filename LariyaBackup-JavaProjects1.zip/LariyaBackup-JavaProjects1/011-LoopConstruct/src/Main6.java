
public class Main6 {

	public static void main(String[] args) {
		for(int i=2000;i>=1000;i-=5)
		{
			System.out.println(i);
		}

	}

}
