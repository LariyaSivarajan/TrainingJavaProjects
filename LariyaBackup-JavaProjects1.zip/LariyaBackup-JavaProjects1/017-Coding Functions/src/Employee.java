
public class Employee {
	int id;
	String name;
	int age;
	
	void dispaly() {
		System.out.print("ID :"+id);
		System.out.println("---------");
		System.out.print("Name:"+name);
		System.out.println("---------");
		System.out.print("Age:"+age);
		System.out.println("---------");
	}

}
