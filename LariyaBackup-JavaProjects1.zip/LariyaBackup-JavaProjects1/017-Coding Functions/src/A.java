
public class A {

	int x;// instance variable
	static int y;// static variable

	void printX() { // instance method
		System.out.println(this.x);
	}

	void printWelcome() { // instance method
		System.out.println("Welcome");
	}

	static void printY() {
		System.out.println(y);
	}

	static void printGoodBye() {
		System.out.println("Good Bye");
	}
    A(){
    	this(10);//this only call in first line otherwise error will occur
    	System.out.println("A object created");
    	System.out.println(this.x);
    	printWelcome();
    	System.out.println(y);
    	printGoodBye();
    	
    }
    A(int x){
    	
    	System.out.println("A object created with "+x);
        this.x=x;
    }
}
