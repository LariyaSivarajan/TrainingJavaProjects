
public class Client3 {
	
	public static void test3(Employee e)
	{
		System.out.println("In test3 before before changes");
		e.dispaly();
		e.id=e.id+1;
		e.name="Krishna";
		e.age=18;
		System.out.println("In test3 after before changes");
		e.dispaly();
	}
	

	public static void main(String[] args) {
		Employee emp1=new Employee();
		emp1.id=10001;
		emp1.name="Ram";
		emp1.age=50;
		System.out.println("In main before function call");
		emp1.dispaly();
		test3(emp1);
	}

}
