package com.ust.model;

public class Employee {
	private double basicSalary;

	public double getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(double basicSalary)  {
		if(basicSalary<0) {
			Exception e=new  Exception("Incorrect basic Salary"+basicSalary);
			/*try {
				throw e;
				
			}catch(Exception ex) {
				ex.printStackTrace();
			}*/ //instead of this  add throws
		}
		this.basicSalary = basicSalary;
	}

	public double computeAllowance() {
		return this.basicSalary * 0.35;
	}

}
