package com.ust.model;

public class Student {
  private int mark;
  
  private String name;
  private char grade;

public char getGrade() {
	return grade;
}

public void setGrade(char grade) throws InvalidGradeException{
	//task5
	//if grade is not 'A','B',create a checked exception
	//throw the exception
	
	if(grade!='A'||grade!='B') {
		InvalidGradeException e1=new InvalidGradeException("Incorrect Grade"+grade);
	throw e1;
	}
	this.grade = grade;
	
}

public int getMark() {
	return mark;
}

public void setMark(int marks) throws InvalidMarkException {
	//create runtime exception
	//throw it
	
	if(mark<0 || mark>100)
		
	   {
		 InvalidMarkException e= InvalidMarkException("Invalid  Marks" +mark);
		
	    throw e;
	}
	this.mark = mark;
}


public String getName() {
	return name;
}

public void setName(String name) throws InvalidNameException {
	if(name==null || name.length()==0) {
		//task1
		//create a exception obj
		//throw the exception object
		//invalidname exception
		InvalidNameException e3=new InvalidNameException("Invalid Name "+name);
		throw e3;
}
	this.name=name;
} }
  

