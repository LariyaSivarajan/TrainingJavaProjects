package com.ust.ui;

public class Main01 {

	public static void main(String[] args) {
		System.out.println("Program Begins..........");
		try {
		int a=100,b=0;
		int c=a/b;
		System.out.println(c);
		}catch(ArithmeticException e) {
			System.out.println("You cannot devide an intiger by zero");
			System.out.println("Continuing......");
		}
		System.out.println("Program Ends..........");

	}

}
