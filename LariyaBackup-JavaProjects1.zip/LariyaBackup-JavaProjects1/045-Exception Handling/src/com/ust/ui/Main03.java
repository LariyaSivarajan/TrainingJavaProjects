package com.ust.ui;

public class Main03 {

	public static void main(String[] args) {
		
		
		System.out.println("Program Begins..........");
		try {
		String str="125abcd";
		int x=Integer.parseInt(str);
		System.out.println(++x);
		}catch(NumberFormatException e) {
			//System.out.println(e);
			e.printStackTrace();
		}
		
		System.out.println("Program Ends..........");


	}

}
