package com.ust.ui;

public class Main08 {

	public static void main(String[] args) {
		try {
			System.out.println(100/1);
			int[] arr= {1,2,3,4};
			System.out.println(arr[1]);
			System.out.println(Integer.parseInt("125"));
			String str=null;
			System.out.println(str.length());
		}catch(NumberFormatException|ArrayIndexOutOfBoundsException|ArithmeticException|NullPointerException e) {
			if(e instanceof NumberFormatException) {
				System.out.println("Number format is invalid");
			}
			if(e instanceof NullPointerException) {
				System.out.println("Null value encountered");
			}
			//add instance of check and print specific error message
			
			if(e instanceof ArrayIndexOutOfBoundsException) {
				System.out.println("Invalid index...");
			}
			if(e instanceof ArithmeticException) {
				System.out.println("Invalid Data...");
			}
		}}

	}

	


