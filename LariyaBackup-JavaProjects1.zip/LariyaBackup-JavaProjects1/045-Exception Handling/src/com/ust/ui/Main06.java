package com.ust.ui;

public class Main06 {

	public static void main(String[] args) {
		try {
			System.out.println(100/0);
			int[] arr= {1,2,3,4};
			System.out.println(arr[100]);
			System.out.println(Integer.parseInt("125abcd"));
			String str=null;
			System.out.println(str.length());
		}catch(NumberFormatException e) {
			e.printStackTrace();
		}catch(Throwable e) {
			e.printStackTrace();
			System.out.println("Continuing......");
		}finally {
			System.out.println("Good Bye");
		}

	}

}
