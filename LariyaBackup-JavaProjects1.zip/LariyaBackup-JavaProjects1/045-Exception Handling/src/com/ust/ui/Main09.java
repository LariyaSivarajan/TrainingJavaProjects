package com.ust.ui;

import com.ust.model.Employee;

public class Main09 {

	public static void main(String[] args) {
		//System.out.println(100/0);
		Employee employee=new Employee();
		//try {
			employee.setBasicSalary(-1000.00);
			
			//}catch(RuntimeException e) {
				//System.out.println(e.getMessage());
			//}
		System.out.println(employee.computeAllowance());
	}

}
