package com.ust.ui;

public class Main05 {

	public static void main(String[] args) {
		try {
		System.out.println(100/0);
		int[] arr= {1,2,3,4};
		System.out.println(arr[100]);
		System.out.println(Integer.parseInt("125abcd"));
		String str=null;
		System.out.println(str.length());
	}catch(ArithmeticException e) {
		System.out.println("Invalid division ");
		System.out.println("Continuing.............");
	}catch(ArrayIndexOutOfBoundsException e) {
		System.out.println("Invalid indexing");
		System.out.println("Continuing......");
	}catch(NumberFormatException e) {
		System.out.println("Invalid String Data");
		System.out.println("Continuing......");
	}catch(NullPointerException e) {
		System.out.println("NullValue encountered");
		System.out.println("Continuing......");
	}catch(RuntimeException e) {
		System.out.println("Some error occured");
		System.out.println("Continuing......");
	}
		System.out.println("Program Ends..........");

}}
