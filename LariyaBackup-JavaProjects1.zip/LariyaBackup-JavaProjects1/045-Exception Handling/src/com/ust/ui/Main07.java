package com.ust.ui;

public class Main07 {

	public static void main(String[] args) {
		try {
			System.out.println(100/1);
			int[] arr= {1,2,3,4};
			System.out.println(arr[1]);
			System.out.println(Integer.parseInt("125"));
			String str="welcome";
			System.out.println(str.length());
		
		}catch(Throwable e) {
			e.printStackTrace();
		}finally {
			System.out.println("Thank you");
		}
	}

}


