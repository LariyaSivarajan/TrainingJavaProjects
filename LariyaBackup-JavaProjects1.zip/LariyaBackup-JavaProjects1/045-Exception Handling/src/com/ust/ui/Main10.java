package com.ust.ui;


import com.ust.model.InvalidNameException;
import com.ust.model.Student;

public class Main10 {

	public static void main(String[] args) {
		//task2
		//create a student object 
		//set mark with value 150
		
		
		Student str=new Student();
		
		try {
		 str.setMark(150);
		
	}catch(RuntimeException ex) {
		System.out.println(ex);
		ex.printStackTrace();
	}
		System.out.println(str.getMark());
		
		
		//task4
		//call setname function with "" string
		try {
			 str.setName("");;
			
		}catch(Exception e) {
			
			e.printStackTrace();
		}
			System.out.println(str.getMark());
			
			
		
		//task5
		//call setGrade with 'E'
			try {
				 str.setGrade('E');;;
				
			}catch(Exception e) {
				
				e.printStackTrace();
			}
			System.out.println("Program ends.........");	
	}
	
}
