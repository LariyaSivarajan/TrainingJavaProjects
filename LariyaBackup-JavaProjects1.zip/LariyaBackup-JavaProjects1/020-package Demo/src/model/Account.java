package model;

public class Account {

}
