package model.deposits;

public class RecurringDeposit {

}
