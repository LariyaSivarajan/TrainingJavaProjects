package model;

public class SavingAccount {

}
