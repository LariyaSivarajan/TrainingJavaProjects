package com.ust.ui;

import java.util.function.Supplier;

import com.ust.modal.Bill;
import com.ust.modal.BillItem;
import com.ust.modal.Circle;
import com.ust.modal.Department;
import com.ust.modal.Employee;

public class Main4 {

	public static void main(String[] args) {
		Supplier<Circle> supplier1;
		supplier1 = () -> new Circle(10);
		System.out.println(supplier1.get());

		Supplier<BillItem> supplier2;
		supplier2 = () -> new BillItem("DELL", 2, 35000.00);
		System.out.println(supplier2.get());

		Supplier<Employee> supplier3;
		// initialize supplier3
		// get the object
		supplier3 = () -> new Employee(101, "Nivedya", "Female", "Delhi", 1000.00);
		System.out.println(supplier3.get());

		Supplier<Bill> supplier4;
		supplier4 = () -> {
			Bill bill = new Bill(554, "Abhi");
			bill.addBillItem("DELL", 2, 48000.00);
			return bill;

		};
		// System.out.println(supplier4.get());
		Bill latestBill = supplier4.get();
		latestBill.printBill();

		// task

		Supplier<Department> supplier5;
		// initialize supplier 5
		// return a department obj with few employees
		// get the obj and call printreport
		supplier5 = () -> {
			Department department = new Department("Accounts", "Narayan");
			department.addEmployee(101, "Nivina", "Female", "Delhi", 1000.00);
			return department;
		};
		Department dept = supplier5.get();
		dept.printReport();
	}
}