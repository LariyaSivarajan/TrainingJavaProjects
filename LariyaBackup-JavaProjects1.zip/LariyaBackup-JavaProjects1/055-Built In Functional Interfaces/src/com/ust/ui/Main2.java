package com.ust.ui;

import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import com.ust.modal.BillItem;
import com.ust.modal.Circle;
import com.ust.modal.Course;
import com.ust.modal.CourseItem;
import com.ust.modal.Department;
import com.ust.modal.Employee;

public class Main2 {
	static void process(Consumer<Circle> c) {
		
		Circle circle=new Circle(20);
		c.accept(circle);
		
	}
   static void process1(Consumer<Department> c) {
		
	Department department = new Department("IT", "Kiran");
	department.addEmployee(101, "Nivedya", "Female", "Delhi", 1000.00);
	department.addEmployee(101, "Shyam", "Male", "Mumbai", 2000.00);
	department.addEmployee(101, "Dinesh", "Male", "Delhi", 3000.00);
	department.addEmployee(101, "Sandhya", "Female", "Mumbai", 4000.00);
		c.accept(department);
	}
   static void process2(Consumer<Course> c) {
		
		Course course = new Course("Deploma in web dev");
		course.addCourseItem("HTML", 40, 4500.00);
		course.addCourseItem("CSS", 20, 2500.00);
		course.addCourseItem("JS", 35, 6000.00);
		course.addCourseItem("Angular", 15, 2000.00);
			c.accept(course);
		}
	
   
	public static void main(String[] args) {
		
		
		
		
		Consumer<BillItem> consumer1;
		consumer1 = (bi) -> System.out.println(bi.getItemName() + "," + bi.getItemValue());
		consumer1.accept(new BillItem("Iphone", 2, 60000.00));

		Consumer<Department> consumer2;
		consumer2 = (d) -> System.out.println(d.getName() + "," + d.getManagerName());
		consumer2.accept(new Department("Accounts", "Narayan"));
		Department department = new Department("IT", "Kiran");
		department.addEmployee(101, "Nivedya", "Female", "Delhi", 1000.00);
		department.addEmployee(101, "Shyam", "Male", "Mumbai", 2000.00);
		department.addEmployee(101, "Dinesh", "Male", "Delhi", 3000.00);
		department.addEmployee(101, "Sandhya", "Female", "Mumbai", 4000.00);

		Consumer<Department> consumer3;
		consumer3 = (d) -> {
			List<Employee> empList = d.getEmployees();
			double sum = 0.0;
			for (Employee e : empList) {
				sum = sum + e.getBasic();
			}
			System.out.println("Total salary " + sum);

		};
		consumer3.accept(department);
		Consumer<Department> consumer4;
		consumer4= (d) ->d.printReport();
		consumer4.accept(department);
		
		//create a consumer of course
		//initialize lambda,it should call printcoursedetails
		//invok
		
		
		Course course = new Course("Deploma in web development");
		course.addCourseItem("HTML", 40, 4500.00);
		course.addCourseItem("CSS", 20, 2500.00);
		course.addCourseItem("JS", 35, 6000.00);
		course.addCourseItem("Angular", 15, 2000.00);
				
		Consumer<Course> consumer5;
		consumer5= (c) -> c.printCourseDetails();
		consumer5.accept(course);
		

				
		Consumer<Circle> consumer6;
		consumer6=(c)->System.out.println(c.getRadius()+","+c.getArea());
		process(consumer6);
		process((c)-> System.out.println(c.getRadius()+","+c.getArea()));
		
		//function as argument
		process1((d)->d.printReport());//functional programming
		
		process2(crs->crs.printCourseDetails());
		
		process2(crs->{ 
			int total=0;
			Set<CourseItem> itemSet=crs.getCourseItems();
			for(CourseItem cit:itemSet) {
				total=total+cit.getDurationInHours();
			}
			System.out.println("Total Duration :"+total);
			
		});
		
	}

}
