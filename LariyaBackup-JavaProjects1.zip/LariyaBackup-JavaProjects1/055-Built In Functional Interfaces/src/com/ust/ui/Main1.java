package com.ust.ui;

import java.util.function.Consumer;

public class Main1 {

	public static void main(String[] args) {
		Consumer<String> consumer1;
		consumer1= s->System.out.println(s.length());
		consumer1.accept("Welcome");
		
		Consumer<Integer> consumer2=null;
		//initialize consumer2 with lambda
		//it should print doubleValue() of the parameter
		//consumer2.
			
		consumer2=obj->System.out.println(obj.doubleValue());
		consumer2.accept(Integer.valueOf(50));
		

	}

}
