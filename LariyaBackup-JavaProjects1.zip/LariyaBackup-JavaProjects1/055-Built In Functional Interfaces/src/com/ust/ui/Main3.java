package com.ust.ui;

import java.util.function.Predicate;

import com.ust.modal.Circle;
import com.ust.modal.Course;
import com.ust.modal.Department;
import com.ust.modal.Square;

public class Main3 {
	static void process1(Predicate<Circle> predicate) {
		Circle c = new Circle(20);
		System.out.println(predicate.test(c));
	}

	static void process2(Predicate<Square> predicate) {
		Square square = new Square(100);
		System.out.println(predicate.test(square));
	}

	static void process3(Predicate<Department> predicate) {

		Department department = new Department("IT", "Kiran");
		department.addEmployee(101, "Nivedya", "Female", "Delhi", 1000.00);
		department.addEmployee(101, "Shyam", "Male", "Mumbai", 2000.00);
		department.addEmployee(101, "Dinesh", "Male", "Delhi", 3000.00);
		department.addEmployee(101, "Sandhya", "Female", "Mumbai", 4000.00);
		System.out.println(predicate.test(department));
	}

	static void process4(Predicate<Course> predicate) {
		Course course = new Course("Deploma in web dev");
		course.addCourseItem("HTML", 40, 4500.00);
		course.addCourseItem("CSS", 20, 2500.00);
		course.addCourseItem("JS", 35, 6000.00);
		course.addCourseItem("Angular", 15, 2000.00);
		System.out.println(predicate.test(course));
	}

	public static void main(String[] args) {
		process1(Circle -> Circle.getRadius() >= 10

		);
		process2((s) -> s.getSize() >= 50);

		process3((d) -> d.getEmployees().size() >= 10

		);
		process4(

				(c) -> c.getCourseItems().size() >= 3

		);

	}

}
