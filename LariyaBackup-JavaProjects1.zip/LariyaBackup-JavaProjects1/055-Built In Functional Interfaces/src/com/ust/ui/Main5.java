package com.ust.ui;

import java.util.function.Function;

import com.ust.modal.Circle;
import com.ust.modal.Employee;
import com.ust.modal.Payment;
import com.ust.modal.Square;

public class Main5 {

	public static void main(String[] args) {
		Function<Integer, Circle> function1;
		function1 = (Integer i) -> {
			return new Circle(i.intValue());
		};
		Circle c = function1.apply(5);
		System.out.println(c);

		Function<Integer, Square> function2;
		function2 = i -> new Square(i.intValue());
		Square s = function2.apply(6);
		System.out.println(s);

		Function<Employee, String> function3;
		function3 = (e) -> e.getName();

		Employee e = new Employee(101, "Hari", "Male", "Delhi", 2000.00);
		String ename = function3.apply(e);
		System.out.println(ename);

		Function<Employee, String> function4;
		function4 = (emp) -> emp.getCityName();

		String ecity = function4.apply(e);
		System.out.println(ecity);

		Function<Employee, Double> function5;
		function5 = (emp) -> emp.getBasic();
		Double ebasic = function5.apply(e);
		System.out.println(ebasic);

		Function<Payment, Double> function6;
		function6 = (pay) -> pay.getPaymentAmount();
		Payment amount = new Payment("Dec", 8000.00);
		Double pamt = function6.apply(amount);
		System.out.println(pamt);
		
		Function<Payment, String> function7;
		function7 = (pay) -> pay.getMonth();
		Payment month = new Payment("Dec", 8000.00);
		String pamt1 = function7.apply(month);
		System.out.println(pamt1);
		
		
		
		
		
		

	}

}
