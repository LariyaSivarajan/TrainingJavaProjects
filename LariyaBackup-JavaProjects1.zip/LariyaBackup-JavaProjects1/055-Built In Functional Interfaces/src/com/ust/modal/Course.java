package com.ust.modal;

import java.util.HashSet;
import java.util.Set;

public class Course {

	private String courseName;
	// private int durationInMonths;
	// private double fees;
	private Set<CourseItem> courseItems;

	public Course() {
		super();
     this.courseItems=new HashSet<>();
	}

	
	

	public Course(String courseName) {
		super();
		this.courseName = courseName;
		this.courseItems=new HashSet<>();
	}

	public void addCourseItem(String subjectName, int duration, double fees) {
		CourseItem courseItem = new CourseItem(subjectName, duration, fees);
		this.courseItems.add(courseItem);

	}

	public void printCourseDetails() {
		System.out.println("-----------------------------------------------------------------");
		System.out.println("Course Name                        :" + this.courseName);
		System.out.println("-----------------------------------------------------------------");
		System.out.println("SlNo    SubjectName    Duration         Fees");
		System.out.println("-----------------------------------------------------------------");
		int slNo = 1;
		double totalFees = 0.0;
		for (CourseItem bi : this.courseItems) {
			System.out.println(slNo++ +"\t" +bi.getSubjectName()+"        \t"+bi.getDurationInHours()+"\t"+ bi.getFees());

			totalFees = totalFees + bi.getFees();
		}

		System.out.println("---------------------------------------------------------------------");
		System.out.println("Total Fees                          :" + totalFees);
		System.out.println("---------------------------------------------------------------------");

	}




	public String getCourseName() {
		return courseName;
	}




	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}




	public Set<CourseItem> getCourseItems() {
		return courseItems;
	}




	public void setCourseItems(Set<CourseItem> courseItems) {
		this.courseItems = courseItems;
	}
	

}
