package com.ust.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import com.ust.modal.Employee;

public class Main10 {

	public static void main(String[] args) throws IOException {
		// create a buffered reader for keyboard
		// int id;
		// String name;
		// String genedr;
		// String cityName
		// double basic

		// take input for above variable

		// craete one employee obj
		// set the data
		// call getnetsalary
		// call tostring();

		int id;
		String name;
		String gender;
		String cityName;
		double basic;

		InputStream is = System.in; // from keyboard
		Reader reader = new InputStreamReader(is);
		BufferedReader br = new BufferedReader(reader);

		System.out.println("Enter the  Id  :");

		String str = br.readLine();
		id = Integer.parseInt(str);

		System.out.println("Enter your Name  :");
		name = br.readLine();
		System.out.println(name);

		System.out.println("Enter your Gender  :");
		gender = br.readLine();

		System.out.println(gender);

		System.out.println("Enter The city Name  :");
		cityName = br.readLine();

		System.out.println(cityName);

		System.out.println("Enter The  Basic Salary  :");
		str = br.readLine();
		basic = Double.parseDouble(str);

		Employee e = new Employee(id, name, gender, cityName, basic);
		System.out.println("Employee Details");
		System.out.println("Net Salary     :" + e.getNetSalary());
		System.out.println(e.toString());

	}

}
