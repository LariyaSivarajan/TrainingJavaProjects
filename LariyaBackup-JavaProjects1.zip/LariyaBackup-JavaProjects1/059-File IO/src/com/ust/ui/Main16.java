package com.ust.ui;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;


import com.ust.modal.CourseItem;

public class Main16 {

	public static void main(String[] args) {
		CourseItem courseItem=null;
		//read the obj from the file
		//print it
		
         try {
			
			InputStream is=new FileInputStream("coursItem.dat");
			ObjectInputStream ois=new ObjectInputStream(is);
			
			CourseItem bi=(CourseItem)ois.readObject(); //deserialization
			System.out.println(bi);
			ois.close();
			is.close();
			
		}catch(Exception e) {
			System.err.println(e);
			System.exit(0);
			
		}
	}

}
