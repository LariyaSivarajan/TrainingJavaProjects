package com.ust.ui;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class Main04 {
	public static void main(String[] args) {
		OutputStream os = null;
		String str;
		str = "I am fine...\n Hope you are doing good\n Please visit us.";
		try {
			os = new FileOutputStream("Welcome.txt");

		} catch (FileNotFoundException e) {
			System.err.println("Welcome.txt not found ......");
			System.exit(0);// terminate the pgm
		}
		try {
			int i;

			for (i = 0; i < str.length(); i++) {
				char ch = str.charAt(i);

				os.write(ch);
			}
		} catch (IOException e) {
			System.err.println("Some Error while writing the file......");
			System.exit(0);

		}
		try {
			os.flush(); // for write we use flush. unsaved data to the file
			os.close();
		} catch (IOException e) {
			System.err.println("Some Error while closing the file......");
			System.exit(0);
		}
	}
}
