package com.ust.ui;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class Main02 {

	public static void main(String[] args) throws IOException {
		// output stream

		OutputStream os;
		os = new FileOutputStream("Welcome.txt");

		String str = "I am fine...\n Hope you are doing good\n Please visit us.";

		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);

			os.write(ch);
		}
		os.flush(); // for write we use flush. unsaved data to the file
		os.close();
	}

}
