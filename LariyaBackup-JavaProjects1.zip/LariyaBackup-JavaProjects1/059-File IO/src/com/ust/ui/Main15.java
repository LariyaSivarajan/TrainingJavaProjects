package com.ust.ui;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

import com.ust.modal.CourseItem;

public class Main15 {

	public static void main(String[] args) {
		try {
		CourseItem courseItem=new CourseItem("HTML", 30, 1800);
		//write the obj to afile
		
		
		OutputStream os=new FileOutputStream("coursItem.dat");
		ObjectOutputStream oos=new ObjectOutputStream(os);
		
		oos.writeObject(courseItem);
		oos.flush();  //serialization
		oos.close();
		os.close();
		
		
	}catch(Throwable e) {
		System.err.println(e.getMessage());
		System.exit(0);
	}
		

	}}


