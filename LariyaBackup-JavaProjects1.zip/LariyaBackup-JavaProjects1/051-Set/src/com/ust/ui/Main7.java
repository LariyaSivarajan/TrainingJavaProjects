package com.ust.ui;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class Main7 {

	public static void main(String[] args) {
		
		         // treeset of string objs
				//add objects(duplicate String)
				//Check if it contains a string
				//remove a string obj
				//iterator over the set elements(print the uppercavse and length)
				//clear the set
				//check is Empty
				//check size
		
		Set<String> set=new TreeSet<>();
		set.add("Apple");
		set.add("Mango");
		set.add("Graphes");
		set.add("Orange");
		set.add("Kiwi");
		set.add("Kiwi");
		System.out.println(set);
		System.out.println(set.contains(String.valueOf("Kiwi")));
		System.out.println(set);
		set.remove(String.valueOf("Orange"));
		System.out.println(set);
		
		Iterator<String> it=set.iterator();
		while(it.hasNext()) {
			String   s=it.next();
			System.out.println(s.toUpperCase()+  "   "+s.length());
			//System.out.println(s.length());
		}
		set.clear();
		System.out.println(set.isEmpty());
		System.out.println(set.size());

	}

}
