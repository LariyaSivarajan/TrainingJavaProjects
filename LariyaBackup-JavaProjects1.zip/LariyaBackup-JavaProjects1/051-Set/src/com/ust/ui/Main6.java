package com.ust.ui;


import java.util.Set;
import java.util.TreeSet;

public class Main6 {

	public static void main(String[] args) {
       Set<Integer> set=new TreeSet<>();
		
		set.add(Integer.valueOf(200));
		set.add(Integer.valueOf(10));
		set.add(Integer.valueOf(30));
		set.add(Integer.valueOf(400));
		set.add(Integer.valueOf(300));
		set.add(Integer.valueOf(300));
		
        System.out.println(set);
		
	    System.out.println(set.contains(Integer.valueOf(200)));
		set.remove(Integer.valueOf(30));
		System.out.println(set);
		System.out.println(set.size());
		set.clear();
		System.out.println(set.isEmpty());
		System.out.println(set.size());
	}

}
