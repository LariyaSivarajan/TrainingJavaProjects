package com.ust.ui;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import com.ust.modal.BillItem;

public class Main8 {

	public static void main(String[] args) {
		Set<BillItem> billItemSet=new TreeSet<>();
		billItemSet.add(new BillItem("Redmi", 10, 10000.00));
		billItemSet.add(new BillItem("Iphone", 12, 60000.00));
		billItemSet.add(new BillItem("Oppo", 8, 17000.00));
		billItemSet.add(new BillItem("Dell Laptop", 3, 58000.00));
		billItemSet.add(new BillItem("Redmi", 2, 8000.00));
		System.out.println(billItemSet);

		System.out.println(billItemSet.size());
		
		System.out.println(billItemSet);

	}

}
