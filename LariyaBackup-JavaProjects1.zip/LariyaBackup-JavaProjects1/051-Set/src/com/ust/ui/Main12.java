package com.ust.ui;

import com.ust.modal.Course;

public class Main12 {

	public static void main(String[] args) {
		Course course=new Course("Deploma in web development");
		course.addCourseItem("HTML",20,2500.00);
		course.addCourseItem("CSS",35,6000.00);
		course.addCourseItem("JS",15,2000.00);
		course.addCourseItem("Angular",50,7500.00);
		course.printCourseDetails();
		

	}

}
