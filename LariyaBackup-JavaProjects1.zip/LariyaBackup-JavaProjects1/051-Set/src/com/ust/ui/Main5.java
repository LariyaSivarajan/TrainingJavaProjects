package com.ust.ui;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.ust.modal.BillItem;
import com.ust.modal.comparator.BillItemPriceComparator;

public class Main5 {

	public static void main(String[] args) {
		Set<BillItem> billItemSet=new HashSet<>();
		billItemSet.add(new BillItem("Redmi", 10, 10000.00));
		billItemSet.add(new BillItem("Iphone", 12, 60000.00));
		billItemSet.add(new BillItem("Oppo", 8, 17000.00));
		billItemSet.add(new BillItem("Dell Laptop", 3, 58000.00));
		billItemSet.add(new BillItem("Redmi", 2, 8000.00));
		System.out.println(billItemSet.size());
		System.out.println(billItemSet);
		
		BillItem searchBillItem=new BillItem("Oppo", 1, 1000.00);
		System.out.println(billItemSet.contains(searchBillItem));
		billItemSet.remove(new BillItem("Redmi", 0, 0));
		System.out.println(billItemSet);
		
		//iterator over set  elements
		//calculate the total of item value print it 
		
		
		
		double total=0.0;
		Iterator<BillItem> it=billItemSet.iterator();
		while(it.hasNext()) {
			BillItem item=it.next();
			total=total+item.getItemValue();
		}
		System.out.println("Total Is   :"+total);
		BillItemPriceComparator comparator=new BillItemPriceComparator();
		BillItem lowestPriceBillItem=new BillItem(null, 0, 0);
		for(BillItem b:billItemSet) {
			int r=comparator.compare(b,lowestPriceBillItem);
			if(r<0)
				lowestPriceBillItem=b;
		}
		System.out.println(lowestPriceBillItem);
		//clear the set 
		//print isempty
		billItemSet.clear();
		System.out.println(billItemSet.isEmpty());
		System.out.println(billItemSet.size());
	}

}
