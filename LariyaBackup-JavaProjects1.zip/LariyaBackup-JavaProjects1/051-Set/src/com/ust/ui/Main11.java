package com.ust.ui;

import com.ust.modal.Bill;

public class Main11 {

	public static void main(String[] args) {
		Bill bill=new Bill(1066,"Mamta Kulkarni");
		bill.addBillItem("Dell", 3,50000.00);
		bill.addBillItem("HP", 2,55000.00);
		bill.addBillItem("Acer", 4,49000.00);
		bill.addBillItem("Dell", 1,55000.00);
		bill.printBill();

	}

}
