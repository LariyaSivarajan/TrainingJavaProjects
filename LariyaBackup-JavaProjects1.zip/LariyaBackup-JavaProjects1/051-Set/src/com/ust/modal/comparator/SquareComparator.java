package com.ust.modal.comparator;

import java.util.Comparator;

import com.ust.modal.Square;

public class SquareComparator implements Comparator<Square>{

	@Override
	public int compare(Square o1, Square o2) {
		int r= o2.getSize()-o1.getSize();
		return r;
	}

}
