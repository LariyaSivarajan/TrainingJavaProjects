package pack1;

public class Main2 {

	public static void main(String[] args) {
		String s=new String("Welcome to UST_Global, Cochin Center,India");
		System.out.println(s);
		System.out.println(s.length());
		System.out.println(s.charAt(2));
		System.out.println(s.charAt(s.length()-1));//last character
		
		for(int i=0;i<s.length();i++) {
			System.out.print(s.charAt(i));
		}
		System.out.println();
		
		System.out.println(s.contains("Cochin"));
		System.out.println(s.startsWith("Welcome"));
		System.out.println(s.indexOf("UST"));
		System.out.println(s.lastIndexOf('C'));
		
		
		String s1=s.substring(10);
		System.out.println(s1);
		String s2=s.replace('C', 'c');
		System.out.println(s2);
		String s4=s.toUpperCase();
		System.out.println(s4);
		
		String s5=s.toLowerCase();
		System.out.println(s5);
		String s6=String.format("%d,%f",10,20.0f);
		System.out.println(s6);
	}

}
