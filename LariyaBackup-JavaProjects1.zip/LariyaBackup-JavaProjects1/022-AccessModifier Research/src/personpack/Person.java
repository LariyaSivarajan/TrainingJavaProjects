package personpack;

public class Person {
	//private member variable
	
	private String name;
	private int age;
	
	
	//constructor to inintialize name and age
	
	public Person(String name, int age) {
		
		this.name = name;
		this.age = age;
	}


	public String getName() {
		return name;
	}


	public int getAge() {
		return age;
	}
	//static method to print a message
	
	public static void printMessage()
	{
		System.out.println("This is a staic method in the person class!");
	}
}
