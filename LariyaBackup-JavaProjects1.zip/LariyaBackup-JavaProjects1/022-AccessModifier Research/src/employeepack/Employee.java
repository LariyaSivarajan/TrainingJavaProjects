package employeepack;

import personpack.Person;
public class Employee {
	
	public void displayEmployeeDetails() {
		//Accessing public constructor from person class in personpack
		
		Person person=new Person("Riya", 30);
		//Accessing public method from person class
		System.out.println("Employee Name :"+person.getName());
		System.out.println("Employee Age :"+person.getAge());
		//calling the static method from person class
		person.printMessage();
	}

}
