package pack3;
import pack2.D;
import pack1.A;

public class Main {
	public static void main(String[] args) {
		A obj1=new A();
		obj1.displayItems();
	}
	
	

}
