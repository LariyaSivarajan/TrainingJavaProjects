package pack2;
import pack1.A;

public class E extends A{
	
	public void test4() {
		//System.out.println(num1);
				//System.out.println(num2);//non friendly subclass
				System.out.println(num3);
				System.out.println(num4);
	}
    public void test5() {
    	A obj=new A();
    	//System.out.println(obj.num1);
        // System.out.println(obj.num2);
    	//		System.out.println(obj.num3);
    			System.out.println(obj.num4);
    }

}
