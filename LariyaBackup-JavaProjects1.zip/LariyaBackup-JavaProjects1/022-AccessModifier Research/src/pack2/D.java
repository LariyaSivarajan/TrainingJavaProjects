package pack2;

import pack1.A;
public class D {
	
	public void test3() {
		A obj=new A();
		//System.out.println(obj.num1);
			//	System.out.println(obj.num2);
				//System.out.println(obj.num3);
				System.out.println(obj.num4);
		
	}

}
