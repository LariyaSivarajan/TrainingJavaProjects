package mainpack;

import employeepack.Employee;

public class Main {

	public static void main(String[] args) {
		// creating an object of employee class from employeepack
		Employee employee=new Employee();
		employee.displayEmployeeDetails();

	}

}
