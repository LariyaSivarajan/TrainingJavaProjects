package pack1;

public class A {
	
	private int num1;
	int num2;//default access level
	
	protected int num3;
	public int num4;
	
	public void test1() {
		System.out.println(num1);
		System.out.println(num2);
		System.out.println(num3);
		System.out.println(num4);
	}
	
	public void displayItems() {
		System.out.println("num1=10");
		System.out.println("num1=20");
		System.out.println("num1=30");
		System.out.println("num1=40");
	}
	

}
