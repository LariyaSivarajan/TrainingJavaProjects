package pack1;

public class C extends A{
	
	public void test6() { //C is friend of A
		//System.out.println(num1);
		System.out.println(num2);
		System.out.println(num3);
		System.out.println(num4);
	}
	
	public void test7() { //C is friend of A
		A obj=new A();
		//System.out.println(obj.num1);
		System.out.println(obj.num2);
		System.out.println(obj.num3);
		System.out.println(obj.num4);
	}

}
