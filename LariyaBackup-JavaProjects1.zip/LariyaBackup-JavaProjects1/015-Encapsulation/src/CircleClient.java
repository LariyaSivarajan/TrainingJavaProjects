
public class CircleClient {

	public static void main(String[] args) {
		Circle c=new Circle();
		c.setRadius(-10);
		System.out.println(c.getRadius());
		System.out.println(c.getArea());

	}

}
