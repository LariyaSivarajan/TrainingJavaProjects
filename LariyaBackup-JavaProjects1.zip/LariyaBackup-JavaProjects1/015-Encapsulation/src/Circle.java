
public class Circle {
	private int radius;
	
	
	void setRadius(int r) {
		
		if(r<0)
		{
			System.out.println("Invalid radius");
			return;
	}
		radius=r;
	}
	int getRadius() {
		return radius;
	}
	double getArea() {
		return 3.14*radius*radius;
	}

}
