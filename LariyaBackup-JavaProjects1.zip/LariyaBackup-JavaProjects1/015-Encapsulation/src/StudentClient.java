
public class StudentClient {

	public static void main(String[] args) {
		Student student=new Student();
		student.setRollNo(101);
		student.setName("LariyaSivarajan");
		student.setMark1(-70);
		student.setMark2(60);
		student.setGender("Female");
		
		System.out.println("Student Information");
		System.out.println("----------------------");
		System.out.println("Student Roll No Is :"+student.getRollNo());
		System.out.println("Student Name       :"+student.getName());
		System.out.println("Student Mark1      :"+student.getMark1());
		System.out.println("Student Mark2      :"+student.getMark2());
		System.out.println("Student Gender     :"+student.getGender());
		

	}

}
