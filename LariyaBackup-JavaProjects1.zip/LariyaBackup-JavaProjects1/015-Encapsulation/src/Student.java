
public class Student {
	
	private int rollNo;
	private String name;
	private int mark1,mark2;
	private String gender;
	
	//generate getters and setters
	
	
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		if(rollNo<0)
		{
			System.out.println("Invalid Rollno");
			return;
			
		}
		
		this.rollNo = rollNo;
	}
	public String getName() {
		
		return name;
	}
	public void setName(String name) {
		if(name==null)
		{
			System.out.println("Please enter a valid name");
			return;
			
		}
		this.name = name;
	}
	public int getMark1() {
		
		return mark1;
	}
	public void setMark1(int mark1) {
		if(mark1<0 ||mark1>100)
		{
			System.out.println("Invalid Mark");
			return;
			
		}
		this.mark1 = mark1;
	}
	public int getMark2() {
		return mark2;
	}
	public void setMark2(int mark2) {
		if(mark2<0||mark2>100)
		{
			System.out.println("Invalid Mark");
			return;
			
		}
		this.mark2 = mark2;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		
		if(gender==null)
		{
			System.out.println("Please enter a valid gender");
			return;
			
		}
		this.gender = gender;
	}
	
	
	

}
