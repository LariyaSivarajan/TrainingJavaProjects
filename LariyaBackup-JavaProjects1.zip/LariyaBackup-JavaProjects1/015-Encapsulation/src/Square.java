
public class Square {
    int size;
    
    void setSize(int size) {
    	if(size<0)
    	{
    		System.out.println("Invalid Data");
    		return;
    	}
    	
    	this.size=size;
    }
    int getSize() {
    	return this.size;
    }
}
