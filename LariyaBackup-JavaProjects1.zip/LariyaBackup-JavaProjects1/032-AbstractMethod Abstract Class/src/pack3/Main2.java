package pack3;

import pack2.Loan;
import pack2.CarLoan;
import pack2.HomeLoan;
import pack2.EducationLoan;
import pack2.PersonalLoan;
import pack2.BusinessLoan;
import pack2.RetailBusinessLoan;
import pack2.WholeSaleBusinessLoan;



public class Main2 {

	public static void main(String[] args) {
		Loan loan;
		//loan=new Loan(100000,12,"Ram");
		//System.out.println(loan.getInterestRate());
		loan=new CarLoan(100000,12,"Kiran","KL5 1344");
		System.out.println(loan.getInterestRate());
		
		loan=new HomeLoan(100000,12,"Kripa","Tvm");
		System.out.println(loan.getInterestRate());

		loan=new PersonalLoan(100000,12,"Kripa",40000);
		System.out.println(loan.getInterestRate());
		//new educational object
		//call getInterestlate
		
		loan=new EducationLoan(1000000, 12, "Maya",2 );
		System.out.println(loan.getInterestRate());
		
		
		BusinessLoan loan1;
		//RetailBusinessLoan loan1;
		
		//inintialize loan1 with RetailbusinessLoan
		//call getInterestRate
		loan1=new RetailBusinessLoan(100000,12, "Kashi", "LG");
		System.out.println(loan1.getInterestRate());
		//inintialize loan1 with WholeSaalebusinessLoan
				//call getInterestRate
		
		loan1=new WholeSaleBusinessLoan(100000,12, "Keshu", "LG");
		System.out.println(loan1.getInterestRate());
	}

}
