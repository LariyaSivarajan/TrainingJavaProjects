package pack1;

public abstract class D extends A{

	

}
