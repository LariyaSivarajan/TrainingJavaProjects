package pack1;

public class B extends A {
	
	//B is a concreate class
	
	
	
	public void test3() {
		System.out.println("B test3");
	}

}
