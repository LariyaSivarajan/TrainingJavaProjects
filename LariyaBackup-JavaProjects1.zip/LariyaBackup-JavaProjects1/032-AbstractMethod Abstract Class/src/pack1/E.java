package pack1;

public class E extends D{

	@Override
	public void test3() {
		System.out.println("test E");
		
	}

}
