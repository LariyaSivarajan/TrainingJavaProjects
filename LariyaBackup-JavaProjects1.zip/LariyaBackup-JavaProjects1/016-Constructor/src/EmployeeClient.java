
public class EmployeeClient {

	public static void main(String[] args) {
		// Create 1 employee obj using no-arg constructor
		//set the data 
		//print the dataa
		
		
		//create 1 more employee obj using parameterised constructor
		//print the data
		
		Employee emp=new Employee();
		emp.setId(102);
		emp.setName("Kripa");
		emp.setBasic(50000.00);
		emp.setCityName("Tvm");
		emp.setGrade('A');
		System.out.println("Employee id is     :"+emp.getId());
		System.out.println("Employee name is   :"+emp.getName());
		System.out.println("Employee basic is  :"+emp.getBasic());
		System.out.println("Employee city is   :"+emp.getCityName());
		System.out.println("Employee grade is  :"+emp.getGrade());
		
		System.out.println("__________________________");
		System.out.println("Parameterized");
		System.out.println("__________________________");
		Employee e1=new Employee(103, "Krishna", "tvm",60000.00, 'A');
		System.out.println("Employee id is     :"+e1.getId());
		System.out.println("Employee name is   :"+e1.getName());
		System.out.println("Employee basic is  :"+e1.getBasic());
		System.out.println("Employee city is   :"+e1.getCityName());
		System.out.println("Employee grade is  :"+e1.getGrade());
	}

}
