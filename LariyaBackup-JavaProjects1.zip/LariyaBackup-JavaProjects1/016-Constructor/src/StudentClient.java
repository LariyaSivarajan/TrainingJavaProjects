
public class StudentClient {

	public static void main(String[] args) {
		Student s=new Student();
		s.setRollNo(1001);
		s.setName("Lariya");
		s.setMark1(70);
		s.setMark2(80);
		s.setGender("Female");
		System.out.println("Student Roll No is :"+s.getRollNo());
		System.out.println("Student name is    :"+s.getName());
		System.out.println("Student Mark1 is   :"+s.getMark1());
		System.out.println("Student Mark2 is   :"+s.getMark2());
		System.out.println("Student Gender is  :"+s.getGender());
		
		System.out.println("__________________________");
		System.out.println("Parameterized Constructor");
		System.out.println("__________________________");
		Student s1=new Student(1002, "Krishna", 90,65, "Female");
		System.out.println("Student Roll No is :"+s1.getRollNo());
		System.out.println("Student name is    :"+s1.getName());
		System.out.println("Student Mark1 is   :"+s1.getMark1());
		System.out.println("Student Mark2 is   :"+s1.getMark2());
		System.out.println("Student Gender is  :"+s1.getGender());
	}

}
