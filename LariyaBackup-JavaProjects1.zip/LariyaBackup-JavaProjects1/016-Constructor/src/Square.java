
public class Square {
   private int size;
   
   Square(){
	   System.out.println("Square created");
   }
    
    Square(int size) {
	setSize(size);
	System.out.println("Square created with size"+size);
}
	void setSize(int size) {
    	if(size<0)
    	{
    		System.out.println("Invalid Data");
    		return;
    	}
    	
    	this.size=size;
    }
    int getSize() {
    	return this.size;
    }
}
