
public class AClient {

	public static void main(String[] args) {
		A obj=new A();
		obj.display1();
		//obj.welcome();
		A.welcome();
		

	}

}
