
public class Circle {
	
	int radius;
	//double PI=3.14;//instance variable
	static double PI=3.14;//global variable
	double getArea() {
		
		
		double area=PI*radius*radius;
		return area;
	}

}
