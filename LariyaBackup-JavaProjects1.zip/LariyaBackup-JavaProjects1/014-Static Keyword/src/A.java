
public class A {
	
	int x;
	static int y=90;
	
	void display1() {
		System.out.println(x);
	}

	/*void welcome() {
		System.out.println("WELCOME");
	}*/
	
	
	static void welcome() {
	System.out.println("WELCOME");
	System.out.println(y);
}
}
