
public class B {
	
	static String companyName="UST";
	String location;
	
	static void greet() {
		System.out.println("");
	}

}
