
public class CClient {

	public static void main(String[] args) {
		//C.count=5;
		System.out.println(C.count);
		
		C.printCount();
		
		
		C obj=new C();
		obj.name="Riya";
		C.count++;
        obj.printName();
        C.printCount();
        
        C obj1=new C();
       C.count++;
		obj1.name="Kashi";
		C.printCount();
        obj1.printName();
	}

}
