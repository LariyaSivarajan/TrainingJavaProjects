
public class Loan {
	
	double balance;
	
	void deposite(double amount) {
		balance=balance+amount;
		
	}
	void withdraw(double amount) {
		balance=balance-amount;
	}
	void printLoanAmount() {
		System.out.println("The Loan Amount is :"+balance);
	}
	double getBalance() {
		return balance;
	}


}
