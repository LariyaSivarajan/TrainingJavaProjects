
public class Vehicle {
	
	String brand;
	String model;
	int year;
	double price;
	
	void displayVehicleDetails()
	{
		System.out.println("Vehicle Information :");
		System.out.println("----------------------");
		System.out.println("Vehicle Brand       :" +brand);
		System.out.println("Vehicle Model       :" +model);
		System.out.println("Vehicle Year        :" +year);
		System.out.println("Vehicle price       :" +price);
	}

}
