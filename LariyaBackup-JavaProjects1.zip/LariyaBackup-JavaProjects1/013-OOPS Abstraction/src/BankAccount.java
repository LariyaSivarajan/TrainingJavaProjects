
public class BankAccount {
	double balance;
	
	
	
	void deposite(double amount) {
		balance=balance+amount;
		
	}
	void withdraw(double amount) {
		balance=balance-amount;
	}
	void printBalance() {
		System.out.println("The balance is :"+balance);
	}
	double getBalance() {
		return balance;
	}

}
