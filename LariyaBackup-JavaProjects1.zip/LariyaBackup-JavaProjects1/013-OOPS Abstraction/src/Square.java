
public  class Square {
    int size;
    
    int getArea() {
    	int result=size*size;
    	return result;
    }
}
