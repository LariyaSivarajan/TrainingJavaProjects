
public class Student {
	String name;
	int mark1,mark2;
	char grade;
	//define a method int computeTotal()
	//define a method int getAverage()
	
	
	//define a method char determineGrade()
	//if()average>=80,grade ='A'
	//if()average 60-79,grade ='B'
	//if()average 40-59,grade ='C'
	//if()average<40,grade ='D'
	
	int computeTotal() {
		int result=mark1+mark2;
		return result;
	}
	
	int getAverage() {
		int result1=computeTotal()/2;
		return result1;
	}
	
	char determineGrade() {
		char grade;
		int avg=getAverage();
		if(avg>=80)
			grade='A';
		else if (avg>=60)
			grade='B';
		else if (avg>=50)
			grade='C';
		else
			grade='D';
		return grade;
	}


}
