
public class VehicleClient {

	public static void main(String[] args) {
		Vehicle vehicle=new Vehicle();
		vehicle.brand="Toyota";
		vehicle.model="Fortuner";
		vehicle.year=2023;
		vehicle.price=2500000;
	    vehicle.displayVehicleDetails();

	}

}
