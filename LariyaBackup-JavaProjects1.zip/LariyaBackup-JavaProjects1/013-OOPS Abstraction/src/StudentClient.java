import java.util.Scanner;

public class StudentClient {

	public static void main(String[] args) {
		// create two student objects
		//set data(name,mark1,mark2)
		//print total and average and grade
		
	    Student s1=new Student();
	    s1.name="Lariya";
	    s1.mark1=60;
	    s1.mark2=50;
	    System.out.println("Student name is  :"+s1.name);
	    System.out.println("Student mark1 is :"+s1.mark1);
	    System.out.println("Student mark2 is :"+s1.mark2);
	    System.out.println("Total Mark is    :"+s1.computeTotal());
	    System.out.println("Average Mark is  :"+s1.getAverage());
	    System.out.println("Grade is :"+s1.determineGrade());
	
	    System.out.println("----------------------------------");
	    Student s2=new Student();
	    s2.name="Riya";
	    s2.mark1=80;
	    s2.mark2=50;
	    System.out.println("Student name is  :"+s2.name);
	    System.out.println("Student mark1 is :"+s2.mark1);
	    System.out.println("Student mark2 is :"+s2.mark2);
	    System.out.println("Total Mark is    :"+s2.computeTotal());
	    System.out.println("Average Mark is  :"+s2.getAverage());
	    System.out.println("Grade is :"+s2.determineGrade());
	}

}
