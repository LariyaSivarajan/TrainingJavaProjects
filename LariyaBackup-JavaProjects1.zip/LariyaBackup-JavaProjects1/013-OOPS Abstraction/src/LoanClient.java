
public class LoanClient {

	public static void main(String[] args) {
		Loan loan=new Loan();
		System.out.println(loan.balance);
		loan.deposite(50000.00);
		//loan.deposite(200.00);
		//account.deposite(400.00);
		
		loan.printLoanAmount();
		//account.withdraw(500.00);
		//account.printBalance();
	}

}
