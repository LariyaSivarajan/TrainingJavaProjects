
public class SquareClient {

	public static void main(String[] args) {
		// three variable of square type
		//initialize the variable
		//set size in each objs
		//print the area of each objects
		
		
		Square s1;
		s1=new Square();
		s1.size=10;
		System.out.println("Area of the square :"+s1.getArea());
		
		
		Square s2;
		s2=new Square();
		s2.size=20;
		System.out.println("Area of the square :"+s2.getArea());
		
		Square s3;
		s3=new Square();
		s3.size=30;
		System.out.println("Area of the square :"+s3.getArea());

	}

}
