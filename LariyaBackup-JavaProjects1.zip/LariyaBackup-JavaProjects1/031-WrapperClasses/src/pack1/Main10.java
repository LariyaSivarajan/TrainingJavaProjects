package pack1;

public class Main10 {

	public static void main(String[] args) {
		// Boolean class
		
		boolean auditor=true;
		Boolean obj=Boolean.valueOf(auditor);//boxing
		
		boolean b=obj.booleanValue();//unboxing
		
		

	}

}
