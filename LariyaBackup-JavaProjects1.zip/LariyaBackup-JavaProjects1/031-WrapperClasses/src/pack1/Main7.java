package pack1;

public class Main7 {

	public static void main(String[] args) {
		Integer obj=Integer.valueOf(200);//boxing immutable classes
		
		int x=500;
		//Integer obj2=Integer.valueOf(x)//boxing
		Integer obj2=x;//Auto boxing
		
		//int y=obj2.intValue(); // unboxing
		int y=obj2;
		System.out.println(obj2);
		obj2++; //obj2.intValue(),increment the extracted value,Integer.valueOf()incremented Data,obj2 will refer to new obj
		System.out.println(obj2);
		
		

	}

}
