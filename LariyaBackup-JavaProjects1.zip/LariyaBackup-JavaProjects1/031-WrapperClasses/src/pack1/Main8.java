package pack1;

public class Main8 {

	public static void main(String[] args) {
		//Auto boxing auto unboxing for a double type;
		
		Double obj=Double.valueOf(100.00);//boxing immutable classes
		
		
		double x=100.00;
		//Integer obj2=Integer.valueOf(x)//boxing
		Double obj2=x;//Auto boxing
		
		//int y=obj2.intValue(); // unboxing
		double y=obj2;
		System.out.println(obj2);
		obj2++; //obj2.intValue(),increment the extracted value,Integer.valueOf()incremented Data,obj2 will refer to new obj
		System.out.println(obj2);
		obj2++;
		System.out.println(obj2);
		obj2--;
		System.out.println(obj2);
		
		
	}

}
