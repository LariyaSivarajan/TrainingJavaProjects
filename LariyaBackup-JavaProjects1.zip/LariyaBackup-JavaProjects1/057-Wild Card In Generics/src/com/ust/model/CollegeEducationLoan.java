package com.ust.model;

public class CollegeEducationLoan extends EducationalLoan{

}
