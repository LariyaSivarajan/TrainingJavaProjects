package com.ust.model;

public class CarLoan extends Loan {

}
