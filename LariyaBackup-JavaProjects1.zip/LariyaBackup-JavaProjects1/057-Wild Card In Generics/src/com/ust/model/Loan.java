package com.ust.model;

public class Loan {

}
