package com.ust.model;

public class HomeLoan extends Loan {

}
