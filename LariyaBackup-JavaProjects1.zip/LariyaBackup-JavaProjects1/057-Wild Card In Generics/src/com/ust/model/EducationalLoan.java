package com.ust.model;

public class EducationalLoan extends Loan{

}
