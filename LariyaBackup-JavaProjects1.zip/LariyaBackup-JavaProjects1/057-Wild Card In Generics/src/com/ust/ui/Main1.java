package com.ust.ui;

import java.util.LinkedList;
import java.util.List;

import com.ust.model.CarLoan;
import com.ust.model.CollegeEducationLoan;
import com.ust.model.EducationalLoan;
import com.ust.model.HomeLoan;
import com.ust.model.Loan;

public class Main1 {

	static void print1(List<Loan> loans) {
		System.out.println(loans);
	}
	
	static void print2(List<? extends CarLoan> loans) {     //'?' is called wild card
		System.out.println(loans);
	}
	
	static void print3(List<? extends EducationalLoan> loans) {
		System.out.println(loans);
	}
	static void print4(List<? super EducationalLoan> loans) {
		System.out.println(loans);
	}
	
	static void print5(List<? > loans) {
		System.out.println(loans);
	}
	static void print6(List<? extends HomeLoan> loans) {
		System.out.println(loans);
	}
	
	
	public static void main(String[] args) {
		List<Loan> loans=new LinkedList<>();
		
		print1(loans);
		
		
		List<CarLoan> cloans=new LinkedList<>();
		print2(cloans);
		
		
		List<EducationalLoan> eloans=new LinkedList<>();
		print3(eloans);
		
		List<CollegeEducationLoan> celoans=new LinkedList<>();
		print3(celoans);
		
		print4(eloans);
		print5(loans);
		
		print4(loans);
		//print4(cloans);
		print4(eloans);
		//print4(celoans);
		
		
		print5(loans);
		print5(cloans);
		print5(eloans);
		print5(celoans);
		
		List<Integer> ilist=new LinkedList<>();
		print5(ilist);
		
		
		//Create a list of HomeLoanss
		//call print1................print5
		
		List<HomeLoan> hloans=new LinkedList<>();
		
		print5(hloans);
		print6(hloans);

		
		

	}

}
