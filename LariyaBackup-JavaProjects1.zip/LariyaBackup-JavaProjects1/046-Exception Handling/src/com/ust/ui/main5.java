package com.ust.ui;

import com.ust.modal.Loan;

public class main5 {

	public static void main(String[] args) {
		// crate loan objects and all functions
		Loan loan = new Loan();
		try {
			loan.setLoanId(-10);
			

		} catch (Exception e) {

			e.printStackTrace();
		}
		System.out.println(loan.getLoanId());

		try {
			loan.setCustomerName("");

		} catch (Exception e) {

			e.printStackTrace();
		}
		System.out.println(loan.getCustomerName());

		try {
			loan.setLoanAmount(-500);
			;

		} catch (Exception e) {

			e.printStackTrace();
		}
		System.out.println(loan.getLoanAmount());

		try {
			loan.setTenure(0);
			

		} catch (Exception e) {

			e.printStackTrace();
		}
		System.out.println(loan.getTenure());

	}

}
