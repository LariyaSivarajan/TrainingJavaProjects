package com.ust.ui;

public class Main2 {
	
	private static void printLength(String str) {
		try
		{
		System.out.println(str);
		}catch(NullPointerException e)
		{
			e.printStackTrace();
		}finally {
			System.out.println("Thank You");
		}
	}

	public static void main(String[] args) {
		// handle null pointer  exception
		
		String s1="Welcome";
		String s2=null;
		String s3="Ust";
		printLength(s1);
		printLength(s2);
		printLength(s3);

	}

}
