package com.ust.ui;

public class Main1 {

	public static void main(String[] args) {
		System.out.println("Program Begins..........");
		//handle exception
		//add a finally block
		try {
		System.out.println(Integer.parseInt("abcd"));
		}catch(NumberFormatException e) {
			e.printStackTrace();
			System.out.println("Continuing......");
		}finally {
			System.out.println("Good Bye");
		}
		System.out.println("Program Ends..........");

	}
	}


