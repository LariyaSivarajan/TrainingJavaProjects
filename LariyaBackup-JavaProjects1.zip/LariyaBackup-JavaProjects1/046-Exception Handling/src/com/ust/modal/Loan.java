package com.ust.modal;

public class Loan {
	private int loanId;
	private String customerName;
	private double loanAmount;
	private int tenure;

	public int getLoanId() {
		return loanId;
	}

	public void setLoanId(int loanId) throws InvalidLoanIdException {
		if (loanId <=0) {
			InvalidLoanIdException e1 = new InvalidLoanIdException("Incorrect LoanId" + loanId);
			throw e1;
		}
		this.loanId = loanId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) throws InvalidCustomerNameException {
		if (customerName == "") {
			InvalidCustomerNameException e1 = new InvalidCustomerNameException("Incorrect name" + customerName);
			throw e1;
		}

		this.customerName = customerName;
	}

	public double getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(double loanAmount) throws InvalidLoanAmountException {
		this.loanAmount = loanAmount;
		if (loanAmount <= 0) {
			InvalidLoanAmountException e1 = new InvalidLoanAmountException("Incorrect LoanAmount" + loanAmount);
			throw e1;
		}
	}

	public int getTenure() {
		return tenure;
	}

	public void setTenure(int tenure) throws InvalidtenuareException {
		if (tenure == 0) {
			InvalidtenuareException e1 = new InvalidtenuareException("Incorrect Tenuare" + tenure);
			throw e1;
		}

		this.tenure = tenure;
	}

	public Loan(int loanId, String customerName, double loanAmount, int tenure) {
		super();
		this.loanId = loanId;
		this.customerName = customerName;
		this.loanAmount = loanAmount;
		this.tenure = tenure;

	}

	public Loan() {

	}

	// create custom exception
	// create appropriate exception objects and throw i

}
