package pack1;

import java.util.Objects;

//Constructors with parameters
	//getters and setters
	//define compute total
	//define getAverage
	//define getGrade()
	//if average 80-100-grade=A
	//if average 60-79-grade=B
	//if average 40-59-grade=C
	//if average 0-39-grade=D

//define toString();
	


public class Student {
	private int rollNumber;
	private String name;
	private int mark1,mark2;

	
	public Student(int rollNumber, String name, int mark1, int mark2) {
		super();
		this.rollNumber = rollNumber;
		this.name = name;
		this.mark1 = mark1;
		this.mark2 = mark2;
	}
	
	public int computTotal() {
		return this.mark1+this.mark2;
	}
	public double getAverage() {
		return computTotal()/2;
	}
	char grade;
	public char getGrade() {
		
		if(getAverage()>80)
			grade='A';
		else if(getAverage()<80)
			grade='B';
		else if(getAverage()<60)
			grade='C';
		else
			grade='D';
		return grade;
		
	}

	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + rollNumber;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Student))
			return false;
		Student other = (Student) obj;
		if (rollNumber != other.rollNumber)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Student [rollNumber=" + rollNumber + ", name=" + name + ", mark1=" + mark1 + ", mark2=" + mark2
				+ ", grade=" + grade + ", computTotal()=" + computTotal() + ", getAverage()=" + getAverage()
				+ ", getGrade()=" + getGrade() + "]";
	}
	
//override equals() and hashcode based on rollnumber

}
