package pack2;
import pack1.Employee;

public class Main3 {

	public static void main(String[] args) {
		Employee employee=new Employee(101,"kiran",5000.00,"A");
		System.out.println(employee);
		
		
	}

}
