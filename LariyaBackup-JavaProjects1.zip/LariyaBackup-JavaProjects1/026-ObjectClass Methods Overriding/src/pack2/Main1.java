package pack2;
import pack1.Circle;
public class Main1 {

	public static void main(String[] args) {
		Circle c1=new Circle(5);
		Circle c2=new Circle(5);
		Circle c3=new Circle(6);
		System.out.println(c1);
		
		System.out.println(c1.equals(c3));
		System.out.println(c1.equals(c2));

	}

}
