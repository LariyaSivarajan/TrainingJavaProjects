package pack2;
import pack1.Square;
public class Main2 {

	public static void main(String[] args) {
		Square square1=new Square(50);
		Square square2=new Square(50);
		Square square3=new Square(60);
		
		
		System.out.println(square1);
		System.out.println(square1.toString());
		
		System.out.println(square1.equals(square3));
		System.out.println(square1.equals(square2));

	}
	
	//over ride toString

}
