package pack2;

import pack1.Square;

public class Main6 {

	public static void main(String[] args) {
		Square s1=new Square(100);
		Square s2=new Square(100);
		Square s3=new Square(200);
		System.out.println(s1.equals(s2));
		System.out.println(s1.equals(s3));
	}

}
