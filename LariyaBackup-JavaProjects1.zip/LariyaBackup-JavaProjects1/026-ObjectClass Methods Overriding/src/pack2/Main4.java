package pack2;
import pack1.Student;

public class Main4 {

	public static void main(String[] args) {
		Student stud=new Student(1001,"Lariya",80,90);
		System.out.println(stud);

	}

}
