package pack2;
import pack1.Student;
public class Main8 {

	public static void main(String[] args) {
		//create 3 student obj
		//test their equality
		
		Student s1=new Student(1001,"Riya",90,90);
		Student s2=new Student(1002,"Riya",90,90);
		Student s3=new Student(1001,"Krishna",90,50);
		
		
		System.out.println(s1.equals(s3));
		System.out.println(s1.equals(s2));
		System.out.println(s3.equals(s2));
		
	}

}
