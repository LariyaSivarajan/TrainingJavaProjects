package pack2;

import pack1.Accountant;
import pack1.Circle;
import pack1.Employee;
import pack1.Manager;
import pack1.SalesEmployee;
import pack1.Square;
import pack1.Student;
public class Main3 {
	
	
	public static void print1(Circle c) {
		System.out.println(c.getRadius());
	}
	
	public static void print2(Employee e) {
		System.out.println(e.getId());
		System.out.println(e.getName());
		System.out.println(e.getBasic());
		
		//Manager m=e;//error
		
		if(e instanceof Manager) {
		Manager m=(Manager)e; 
		System.out.println(m.getEmployeeCount()) ;//downcasting explicit
		}
		if(e instanceof SalesEmployee) {
		SalesEmployee s=(SalesEmployee)e;
	    System.out.println(s.getAreaName());
	}
		if(e instanceof Accountant) {
			Accountant temp=(Accountant)e;
		    System.out.println(temp.isAuditor());
		}
		
		
	}
	public static void print3(Object o) {
		if(o instanceof Circle) {
			Circle temp=(Circle)o;
		    System.out.println(temp.getRadius());
		}
		if(o instanceof Employee) {
			Employee temp=(Employee)o; 
			System.out.println(temp.getId()) ;//downcasting explicit
			System.out.println(temp.getName()) ;
			System.out.println(temp.getBasic()) ;
		}
		
		if(o instanceof Manager) {
			Manager temp=(Manager)o; 
			System.out.println(temp.getEmployeeCount()) ;//downcasting explicit
			}
		if(o instanceof SalesEmployee) {
			SalesEmployee temp=(SalesEmployee)o;
		    System.out.println(temp.getAreaName());
		}
		//task downcasting to student 
				//print all details
				
				if(o instanceof Student) {
					Student temp=(Student)o;
				    System.out.println(temp.getRollNumber());
				    System.out.println(temp.getName());
				    System.out.println(temp.getMark1());
				    System.out.println(temp.getMark2());
				    System.out.println(temp.getTotal());
				}
		//task
				//downcasting to square
				//print all details
				
				if(o instanceof Square) {
					Square temp=(Square)o;
				    System.out.println(temp.getSize());
				    System.out.println(temp.getArea());
				   
				}
	}
	public static void main(String[] args) {
		
		
		Student stu=new Student(555, "Dinesh", 90, 80);
		Circle c1=new Circle();
		c1.radius=90;
		print1(c1);
		
		Employee e=new Employee(101,"Ram",3000.00);
		print2(e);
		
		Manager m=new Manager(102,"Kiran",4000.00,10);
		print2(m);
		
		
		SalesEmployee s=new SalesEmployee();
		s.setId(103);
		s.setName("Raj");
		s.setBasic(5000.00);
		s.setAreaName("Tvm");
		print2(s);
		Accountant a=new Accountant();
		a.setId(107);
		a.setName("Kashi");
		a.setBasic(4500.00);
		a.isAuditor();
		print2(a);
		
		print3(stu);
		//task
				//craete one square object
				//call print3 
		Square sqr=new Square(5);
		print3(sqr);
	
		
	}

}
