package pack2;
import pack1.Manager;
import pack1.SalesEmployee;
import pack1.Circle;
import pack1.Employee;
public class Main2 {

	public static void main(String[] args) {
		
		byte b=90;
		int i=b;
		
		
		
		Employee e;
		e= new Manager();//reference casting,upcasting ,employee e superclass,implicit
		
	    e=new SalesEmployee();//reference casting,upcasting implicit
	    
	    
	    
	    Object obj;
	    obj= new Manager();//reference casting,upcasting ,employee e superclass implicit
		
	    obj=new SalesEmployee();//reference casting,upcasting implicit
	    obj=new Circle();
	    
         
	}

}
