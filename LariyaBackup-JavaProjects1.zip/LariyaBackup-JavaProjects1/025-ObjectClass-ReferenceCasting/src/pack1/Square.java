package pack1;

public class Square {
	int size;

	//task1 
		//generate two constructors
		//generate setters/getters
		//define getArea()
	
	public Square(int size) {
		super();
		this.size = size;
	}

	public Square() {
		super();
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}
	public int getArea() {
		return this.size*size;
	}
	
	
	
	
	

}
