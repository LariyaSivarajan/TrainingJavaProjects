package pack1;

public class Accountant extends Employee{
	
	public boolean auditor;
	
	public boolean isAuditor;
	
	public boolean isAuditor() {
		return isAuditor;
	}

}
