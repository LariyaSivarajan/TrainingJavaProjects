package pack1;

public class Manager extends Employee {
	
	int employeeCount;

	public Manager(int id, String name, double basic, int employeeCount) {
		super(id, name, basic);
		this.employeeCount = employeeCount;
	}

	public Manager() {
		super();
	}

	public int getEmployeeCount() {
		return employeeCount;
	}

	public void setEmployeeCount(int employeeCount) {
		this.employeeCount = employeeCount;
	}
	

	

}
