package pack1;

public class OverloadExample {
	
	public OverloadExample() {
		System.out.println("Default constructor");
	}
	public OverloadExample(int a) {
		System.out.println("parameterised  constructor with int:"+a);
	}
	
	public void display(int a) {
		System.out.println("Integer :"+a);
	}
	
	public void display(double a) {
		System.out.println("Double :"+a);
	}
	
	public void display(String a,int b) {
		System.out.println("String and Integer :"+a+","+b);
	}
	public static void display(String a) {
		System.out.println("Static method :"+a);
	}
	

}
