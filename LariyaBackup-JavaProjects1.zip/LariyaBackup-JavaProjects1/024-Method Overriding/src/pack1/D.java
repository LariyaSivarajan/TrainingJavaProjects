package pack1;

public class D extends C{
	
	public D() {
		System.out.println("D  class constructor");
	}
	@Override
	public void show() {
		System.out.println("D  class method()overriden");
	}
	
	public static void staticMethod() {
		   System.out.println("D  class Static method");
	   }
	//@Override //cannot override private access
	private void print() {
		   System.out.println("Printmessage");
	   }
	@Override  //cannot override a final method
	public static final void  f2() {
		   System.out.println("f2");
	   }

}
