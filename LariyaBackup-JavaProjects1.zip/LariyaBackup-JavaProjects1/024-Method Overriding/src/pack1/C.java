package pack1;

public class C {
	
	
	public C() {
		System.out.println("C  class constructor");
	}
   public void show() {
	   System.out.println("C  class Method");
   }
   
   public static void staticMethod() {
	   System.out.println("C  class Static method");
   }
   
   private void print() {
	   System.out.println("Printmessage");
   }
   public static final void  f2() {
	   System.out.println("f2");
   }
}
