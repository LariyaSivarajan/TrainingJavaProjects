package pack2;
import pack1.OverloadExample;
import pack1.C;
import pack1.D;

public class Main3 {

	public static void main(String[] args) {
		
		//constructor overloading
		OverloadExample obj1=new OverloadExample();
		OverloadExample obj2=new OverloadExample(42);
		
		
		//method overloading
		obj1.display(10);
		obj1.display(10.5);
		obj1.display("Hello", 5);
		
		//static overloadmethod
		OverloadExample.display("Static overloaded method call");
		
		//method overriding
		
		C obj3=new C();
		obj3.show();
		
		D obj4=new D();
		obj4.show();
		
		
		C.staticMethod();
		D.staticMethod();
		

	}

}
