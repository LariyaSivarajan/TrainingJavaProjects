 package pack1;

public class D {
	public D() {
		System.out.println("D constructor");
	}
	

}
