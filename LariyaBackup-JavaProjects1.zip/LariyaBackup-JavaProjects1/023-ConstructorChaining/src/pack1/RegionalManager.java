package pack1;

public class RegionalManager extends Manager{
	private String regionname;
	//task
	//generate constructors

	public RegionalManager(int id, String name, double basic, String gender, int employeeCount, String regionname) {
		super(id, name, basic, gender, employeeCount);
		this.regionname = regionname;
	}

	public RegionalManager(int id, int employeeCount, String regionname) {
		super(id, employeeCount);
		this.regionname = regionname;
	}

	public RegionalManager(int id, String name, double basic, String gender, String regionname) {
		super(id, name, basic, gender);
		this.regionname = regionname;
	}

	public RegionalManager(int id, String name, int employeeCount, String regionname) {
		super(id, name, employeeCount);
		this.regionname = regionname;
	}

	public RegionalManager(int id, String name, double basic, int employeeCount, String regionname) {
		super(id, name, basic, employeeCount);
		this.regionname = regionname;
	}
	public RegionalManager() {
		super();
	}
	

}
