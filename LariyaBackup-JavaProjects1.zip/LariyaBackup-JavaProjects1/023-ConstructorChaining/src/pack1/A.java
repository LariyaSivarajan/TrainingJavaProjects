package pack1;

public class A {
	int x,y,z;
	
	public A(){
		System.out.println("A object created without arguments");
	}
	
	public A(int x) {
		this();
		System.out.println("A object created with 1 argument"+x);
		this.x=x;
	}
	public A(int x,int y) {
		this(x);  //calling the above constructor or constructor chaining
		this.y=y;
		System.out.println("A object created with 2 argument"+x+","+y);
		//this.x=x;
		
	}
	public A(int x,int y,int z) {
		this(x,y); //calling the above constructor
		this.z=z;
		System.out.println("A object created with 3 argument"+x+","+y+","+z);
		//this.x=x;
		//this.y=y;
		
	}
	public void display() {
		System.out.println(this.x+","+this.y+","+this.z);
	}

}
