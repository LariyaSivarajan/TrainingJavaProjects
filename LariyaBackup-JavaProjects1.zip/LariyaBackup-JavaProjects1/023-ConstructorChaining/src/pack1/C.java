package pack1;

public class C  extends B{
	int z;
	public C(int x,int y,int z) {
		//this.x=x;
		//this.y=y;
		super(x,y);//constructor chaining
		this.z=z;
		System.out.println("C Constructor with 3 arguments"+x+","+y+","+z);
	}
		public C(int x,int y) {
			super(x,y);
			System.out.println("C Constructor with 2 arguments"+x+","+y);
			
		}
		
		public C(int x) {
			super(x);
			System.out.println("C Constructor with  arguments"+x);
			
		}
		public C() {
			super();
			System.out.println("C Constructor without arguments");
			
		}
	

}
