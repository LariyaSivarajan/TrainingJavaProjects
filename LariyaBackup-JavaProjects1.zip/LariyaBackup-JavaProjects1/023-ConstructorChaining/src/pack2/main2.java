package pack2;

import pack1.C;

public class main2 {

	public static void main(String[] args) {
		C obj=new C();

	}

}
