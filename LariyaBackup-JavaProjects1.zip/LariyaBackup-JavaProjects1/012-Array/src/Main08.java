
public class Main08 {

	public static void main(String[] args) {
		int [] array= {14,20,30,10};
		//find min and max value
		int min=array[0];
		int max=array[0];
		
		for(int i=1;i<array.length;i++)
		{
			if(array[i]<min)
			{
				min=array[i];
			}
			if(array[i]>max)
			{
				max=array[i];
			}
		}
		System.out.println("The min value is:"+min);
		System.out.println("The max value is:"+max);
	}

}
