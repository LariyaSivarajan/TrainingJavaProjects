
public class Main10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
	////int[] array4= {b1,s1,i1,ch1,100,200,300};	
	//string str="[";
	//for(int i=0;i<)

	}

}
