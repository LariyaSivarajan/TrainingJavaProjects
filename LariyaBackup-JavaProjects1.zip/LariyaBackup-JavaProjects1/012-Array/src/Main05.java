import java.util.Scanner;

public class Main05 {

	public static void main(String[] args) {
		int[] marks;
		int size;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size");
		size=sc.nextInt();
		marks=new int [size];
		for(int e:marks)
		{
			System.out.println(e);
		}

	}

}
