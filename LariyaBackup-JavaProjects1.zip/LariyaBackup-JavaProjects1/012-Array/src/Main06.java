import java.util.Scanner;

public class Main06 {

	public static void main(String[] args) {
		long[] profits;
		int arraySize;
		
		//take input for the size at run time
		//create an array initialize
		//take input for each element in the array
		//print the elmts
		
		
		
		System.out.println("Enter the size");
		Scanner sc=new Scanner(System.in);
		arraySize=sc.nextInt();
		profits=new long[arraySize];
		System.out.println("Enter the array elements");
		for(int i=0;i<profits.length;i++)
		{
			profits[i]=sc.nextLong();
		}
		for(long e1:profits)
		{
			System.out.println(e1);
		}
	

	}

}
