
public class Main03 {

	public static void main(String[] args) {
		float[] array;
		array=new float[] {5.0f,8.0f,7.0f};
       System.out.println(array.length);
      // for(int i=0;i<array.length;i++)
		//{
			//System.out.println(array[i]);
		//}
       
       for(float element:array)
       {
    	   System.out.println(element);
       }
	}

}
