
public class Main04 {

	public static void main(String[] args) {
		char array[]= {'A','B','C','D'};
		
		for(char elemnt:array)
		{
			System.out.println(elemnt);
		}
	}

}
