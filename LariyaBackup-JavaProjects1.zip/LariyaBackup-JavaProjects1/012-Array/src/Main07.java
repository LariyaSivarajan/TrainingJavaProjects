
public class Main07 {

	public static void main(String[] args) {
		int [] array= {14,20,30,10};
		//find sum and print
		//find average and print
		
		int sum=0;
	    float avg=0;
	    for(int i=0;i<array.length;i++)
	    {
	    	sum=sum+array[i];
	    }
	    System.out.println("Sum is :"+sum);
	    
	    avg=sum/array.length;
	    System.out.println("Average is "+avg);

	}

}
