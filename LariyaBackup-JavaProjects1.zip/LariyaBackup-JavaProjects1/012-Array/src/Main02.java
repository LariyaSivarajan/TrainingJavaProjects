
public class Main02 {

	public static void main(String[] args) {
		double[] discounts;
		discounts=new double[5];
		System.out.println(discounts.length);
		discounts[0]=0.15;
		discounts[1]=0.25;
		discounts[2]=0.35;
		discounts[3]=0.45;
		
		
		
		for(int i=0;i<discounts.length;i++)
		{
			System.out.println(discounts[i]);
		}
	}

}
