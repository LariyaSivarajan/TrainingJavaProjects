package com.ust.ui;

import java.util.LinkedList;
import java.util.List;

import com.ust.modal.Circle;

public class Main12 {

	public static void main(String[] args) {
		List<Circle> circles = new LinkedList<>();

		circles.add(new Circle(5));
		circles.add(new Circle(7));
		circles.add(new Circle(12));
		circles.add(new Circle(10));
		circles.add(new Circle(20));

		// anymatch radius>10
		// allmatch radius>2
		// nonmatch radius==0

		boolean result1 = circles.stream().anyMatch(i -> i.getRadius() > 10);
		System.out.println(result1);

		boolean result2 = circles.stream().allMatch(i -> i.getRadius() > 2);

		System.out.println(result2);

		boolean result3 = circles.stream().noneMatch(i -> i.getRadius() == 0);

		System.out.println(result3);

	}

}
