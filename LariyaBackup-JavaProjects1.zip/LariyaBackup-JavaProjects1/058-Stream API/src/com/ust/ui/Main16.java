package com.ust.ui;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.ust.modal.Employee;
import com.ust.modal.Payment;

public class Main16 {

	public static void main(String[] args) {
		List<Payment> allPayments = new LinkedList<>();

		allPayments.add(new Payment("Jan", 1000.00));
		allPayments.add(new Payment("Jan", 1500.00));
		allPayments.add(new Payment("Jan", 2000.00));

		allPayments.add(new Payment("Feb", 100.00));
		allPayments.add(new Payment("Feb", 200.00));
		allPayments.add(new Payment("Feb", 150.00));
		allPayments.add(new Payment("Feb", 300.00));

		allPayments.add(new Payment("Mar", 1000.00));
		allPayments.add(new Payment("Mar", 1500.00));

		/*
		 * Map<String,Long> Jan-3 Feb-4 mar-2
		 * 
		 * 
		 * 
		 * Map<String,Double> Jan-4500.00 feb-750.0 Mar-2500.00
		 * 
		 * 
		 * Map<String,List<Payment>> Jan-List<Payment> Feb-List<Payment>
		 * Mar-List<payment>
		 * 
		 * 
		 */

		Map<String, Long> map2;
		map2 = allPayments.stream().collect(Collectors.groupingBy(Payment::getMonth, Collectors.counting()));

		System.out.println(map2);
		System.out.println("------------------------------------------------------------------");
		Map<String, Double> map4;
		map4 = allPayments.stream()
				.collect(Collectors.groupingBy(Payment::getMonth, Collectors.summingDouble(Payment::getPaymentAmount)));

		System.out.println(map4);
		System.out.println("-------------------------------------------------------------------");
		Map<String, List<Payment>> map5 = allPayments.stream().collect(Collectors.groupingBy(Payment::getMonth));

		for (Map.Entry<String, List<Payment>> entry : map5.entrySet()) {
			System.out.println(entry.getKey());
			System.out.println("---------------------------------------------------------------");
			List<Payment> empsInCity = entry.getValue();
			for (Payment e : empsInCity) {
				System.out.println(e.toString());
			}

		}
		System.out.println(map5);

	}

}
