package com.ust.ui;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import com.ust.modal.Person;
import com.ust.modal.comparator.PersonNameComparator;

public class Main9 {

	public static void main(String[] args) {
		List<Person> allPersons = new LinkedList<>();
		allPersons.add(new Person("Ram", 24));

		allPersons.add(new Person("Dinesh", 44));
		allPersons.add(new Person("Reshmi", 28));
		allPersons.add(new Person("Mamta", 30));
		allPersons.add(new Person("Seetha", 36));

		Optional<Person> optionalResult = allPersons.stream().min(new PersonNameComparator());

		if (optionalResult.isPresent()) {
			System.out.println(optionalResult.get());
		} else {
			System.out.println("Collection is empty");
		}
		System.out.println("---------------------------------------------------------------------------");

		Optional<Person> optionalResult2 = allPersons.stream().min((p1, p2) -> p1.getAge() - p2.getAge());
		if (optionalResult2.isPresent()) {
			System.out.println(optionalResult2.get());
		} else {
			System.out.println("Collection is empty");
		}

		System.out.println("---------------------------------------------------------------------------");
		// find max obj in allPerson collection based on age
		Optional<Person> optionalResult3 = allPersons.stream().max((p1, p2) -> p1.getAge() - p2.getAge());
		if (optionalResult3.isPresent()) {
			System.out.println(optionalResult3.get());
		} else {
			System.out.println("Collection is empty");
		}

		System.out.println("---------------------------------------------------------------------------");
		// find max obj in allPerson collection based on name
		Optional<Person> optionalResult4 = allPersons.stream().max((p1, p2) -> p1.getName().compareTo(p2.getName()));
		if (optionalResult4.isPresent()) {
			System.out.println(optionalResult4.get());
		} else {
			System.out.println("Collection is empty");
		}
	}

}
