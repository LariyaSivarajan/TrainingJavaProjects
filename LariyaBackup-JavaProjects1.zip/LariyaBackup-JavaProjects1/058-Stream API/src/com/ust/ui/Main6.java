package com.ust.ui;

import java.util.Set;
import java.util.TreeSet;

import com.ust.modal.BillItem;
import com.ust.modal.comparator.BillItemPriceComparator;
import com.ust.modal.comparator.BillItemQuantityComparator;

public class Main6 {

	public static void main(String[] args) {

		Set<BillItem> billItemSet = new TreeSet<>();// asending order

		billItemSet.add(new BillItem("Redmi", 10, 10000.00));
		billItemSet.add(new BillItem("Iphone", 12, 60000.00));
		billItemSet.add(new BillItem("Oppo", 8, 17000.00));
		billItemSet.add(new BillItem("Dell Laptop", 3, 58000.00));
		billItemSet.add(new BillItem("IBN", 2, 8000.00));

		billItemSet.stream().mapToInt(bi -> bi.getQuantity()).forEach((q) -> System.out.println(q));

		System.out.println("--------------------------------------------------------------------------------------");

		billItemSet.stream().sorted(new BillItemPriceComparator()).forEach((q) -> System.out.println(q));

		System.out.println("--------------------------------------------------------------------------------------");

		// print in the ascending order of quantity

		billItemSet.stream().sorted(new BillItemQuantityComparator()).forEach((q) -> System.out.println(q));

	}

}
