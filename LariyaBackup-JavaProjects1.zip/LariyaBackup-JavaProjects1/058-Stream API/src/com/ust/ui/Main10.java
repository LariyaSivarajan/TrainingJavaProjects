package com.ust.ui;

import com.ust.modal.Course;

public class Main10 {

	public static void main(String[] args) {
		Course course = new Course("Diploma in Web");
		course.addCourseItem("Angular", 3, 4000.00);
		course.addCourseItem("HTML", 20, 5000.00);
		course.addCourseItem("CSS", 18, 2000.00);
		course.addCourseItem("JS", 50, 7400.00);
		course.addCourseItem("React", 30, 4000.00);

		System.out.println(course.getLongestDurationCourseItem());
		System.out.println(course.getShortesttDurationCourseItem());

		System.out.println("---------------------------------------------");
		System.out.println(course.getHighestPricedCourseItem());
		System.out.println(course.getLowesttPricedCourseItem());

	}

}
