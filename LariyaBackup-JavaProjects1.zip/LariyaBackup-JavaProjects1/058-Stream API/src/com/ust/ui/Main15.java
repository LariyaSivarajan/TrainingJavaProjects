package com.ust.ui;

import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.ust.modal.BillItem;

public class Main15 {

	public static void main(String[] args) {
		// List of Bill Items
		// total item value (reduce operation)
		//

		List<BillItem> billItemSet = new LinkedList<>();// asending order
		billItemSet.add(new BillItem("Redmi", 10, 10000.00));
		billItemSet.add(new BillItem("Iphone", 12, 60000.00));
		billItemSet.add(new BillItem("Oppo", 8, 17000.00));
		billItemSet.add(new BillItem("Dell Laptop", 3, 58000.00));
		billItemSet.add(new BillItem("Redmi", 2, 8000.00));

		double r = billItemSet.stream().map(e -> e.getItemValue()).reduce(0.0, (b1, b2) -> b1 + b2);
		System.out.println(r);

	}

}
