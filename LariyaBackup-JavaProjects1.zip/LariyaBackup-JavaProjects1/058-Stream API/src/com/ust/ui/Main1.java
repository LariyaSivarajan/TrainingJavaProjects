package com.ust.ui;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Consumer;

import com.ust.modal.Circle;

public class Main1 {

	public static void main(String[] args) {
		List<Integer> ilist = new LinkedList<>();

		ilist.add(Integer.valueOf(200));
		ilist.add(Integer.valueOf(10));
		ilist.add(Integer.valueOf(150));
		ilist.add(Integer.valueOf(180));
		ilist.add(Integer.valueOf(140));

		Consumer<Integer> printAction;
		// printAction=(i)->System.out.println(i);

		ilist.forEach((i) -> System.out.println(i));
		List<String> cities = new LinkedList<>();
		cities.add("Pune");
		cities.add("Patna");
		cities.add("Kolkata");
		cities.add("Cochin");

		Consumer<String> upperCaseAction;
		// upperCaseAction=(s)->System.out.println(s.toUpperCase());

		cities.forEach((s) -> System.out.println(s.toUpperCase()));
		// pass a consumer which print the each of city

		cities.forEach((s) -> System.out.println(s.length()));

		List<Circle> circles = new LinkedList<>();
		circles.add(new Circle(10));
		circles.add(new Circle(20));
		circles.add(new Circle(30));
		circles.forEach((c) -> System.out.println(c.toString()));
		circles.forEach((c) -> System.out.println(c.getRadius()));
		circles.forEach((c) -> System.out.println(c.getArea()));

	}

}
