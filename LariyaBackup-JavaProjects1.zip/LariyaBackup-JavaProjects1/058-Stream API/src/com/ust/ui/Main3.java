package com.ust.ui;

import java.util.LinkedList;
import java.util.List;

import com.ust.modal.Employee;

public class Main3 {

	public static void main(String[] args) {

		Employee e1 = new Employee(10, "Ram", "Male", "Banglore", 10000.00);
		Employee e2 = new Employee(11, "Saranya", "Female", "Chennai", 20000.00);
		Employee e3 = new Employee(12, "Lekshmi", "Female", "Banglore", 10000.00);
		Employee e4 = new Employee(13, "Vicky", "Male", "Cochin", 15000.00);
		Employee e5 = new Employee(14, "Reshmi", "Female", "Chennai", 22000.00);

		Employee e6 = new Employee(15, "Kiran", "Male", "Cochin", 10000.00);
		Employee e7 = new Employee(16, "Saradha", "Female", "Chennai", 14000.00);
		Employee e8 = new Employee(17, "Vinodh", "Male", "Banglore", 50000.00);
		Employee e9 = new Employee(18, "Sree Vidhya", "Female", "Cochin", 14000.00);
		Employee e10 = new Employee(19, "Suresh", "Male", "Chennai", 21000.00);
		List<Employee> allEmployees = new LinkedList<>();
		allEmployees.add(e1);
		allEmployees.add(e2);
		allEmployees.add(e3);
		allEmployees.add(e4);
		allEmployees.add(e5);
		allEmployees.add(e6);
		allEmployees.add(e7);
		allEmployees.add(e8);
		allEmployees.add(e9);
		allEmployees.add(e10);

		allEmployees.stream().sorted().filter((e) -> e.getCityName().equalsIgnoreCase("Chennai"))
				.forEach((e) -> System.out.println(e));

		// print only male employee
		// print only female employee
		// basic salary is above 20000

		// print only female employee
		allEmployees.stream().sorted().filter((e) -> e.getGender().equalsIgnoreCase("Female"))
				.forEach((e) -> System.out.println(e));

		// print only male employee
		allEmployees.stream().sorted().filter((e) -> e.getGender().equalsIgnoreCase("Male"))
				.forEach((e) -> System.out.println(e));

		// basic salary is above 20000

		allEmployees.stream().sorted().filter((e) -> e.getBasic() >= 20000).forEach((e) -> System.out.println(e));

	}

}
