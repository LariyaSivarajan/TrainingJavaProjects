package com.ust.ui;

import java.util.LinkedList;
import java.util.List;

import com.ust.modal.Circle;

public class main2 {

	public static void main(String[] args) {
     List<Integer> ilist=new LinkedList<>();
		
		
		ilist.add(Integer.valueOf(120));
		ilist.add(Integer.valueOf(10));
		ilist.add(Integer.valueOf(150));
		ilist.add(Integer.valueOf(75));
		ilist.add(Integer.valueOf(80));
		
		ilist
		    .stream()
		    .sorted()
		    .filter((i)->i>=100) 
		    .forEach((i)->System.out.println(i));
		
		
		List<String>  cities=new LinkedList<>();
		cities.add("Pune");
		cities.add("Patna");
		cities.add("Kolkata");
		cities.add("Cochin");
		
		//sort the cities and print the cities
		
		
		
		cities
		         .stream()
		         .sorted()
		         .filter((i)->i.length()>=6) 
		         .forEach((i)->System.out.println(i));
		
		
		
		//add five circles
		//sort
		//filter if radius>=100
		List<Circle> circles=new LinkedList<>();
		circles.add(new Circle(10));
		circles.add(new Circle(20));
		circles.add(new Circle(30));
		circles.add(new Circle(500));
		circles.add(new Circle(400));
		
		
		circles
        .stream()
        .sorted()
        .filter((cr)->cr.getRadius()>=100) 
        .forEach((cr)->System.out.println(cr));

	}

}
