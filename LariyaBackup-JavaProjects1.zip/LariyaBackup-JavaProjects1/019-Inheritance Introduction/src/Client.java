
public class Client {

	public static void main(String[] args) {
		Manager manager=new Manager();
		manager.setId(101);
		manager.setName("Riya");
		manager.setGender("Female");

		manager.setBasicSalary(1000.00);
		manager.setEmployeeCount(50);
		
		System.out.println("ID          :"+manager.getId());
		System.out.println("Name        :"+manager.getName());
		System.out.println("Gender      :"+manager.getGender());
		System.out.println("BasicSalary :"+manager.getBasicSalary());
		System.out.println("Emp Count   :"+manager.getEmployeeCount());
		System.out.println("Net salary  :"+manager.getNetSalary());
		//task
		
		//create salesEmployee obj
		//set data;
		SalesEmployee salesEmployee=new SalesEmployee();
		salesEmployee.setId(102);
		salesEmployee.setName("Remya");
		salesEmployee.setGender("Female");

		salesEmployee.setBasicSalary(5000.00);
		salesEmployee.setSalesAreaName("varkala");	
		System.out.println("ID         :"+salesEmployee.getId());
		System.out.println("Name        :"+salesEmployee.getName());
		System.out.println("Gender      :"+salesEmployee.getGender());
		System.out.println("BasicSalary :"+salesEmployee.getBasicSalary());
		System.out.println("SalesAreaName      :"+salesEmployee.getSalesAreaName());
		System.out.println("Net salary   :"+salesEmployee.getNetSalary());
		
	}

}
