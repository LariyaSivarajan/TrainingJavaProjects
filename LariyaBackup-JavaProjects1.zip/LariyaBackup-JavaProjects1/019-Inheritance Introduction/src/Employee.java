
public class Employee {
	private int Id;
	private String name;
	private String gender;
	protected double basicSalary;
	
	
	
	Employee(){
		
	}
	
	Employee(int id, String name, String gender, double basicSalary) {
		super();
		Id = id;
		this.name = name;
		this.gender = gender;
		this.basicSalary = basicSalary;
	}
	int getId() {
		return Id;
	}
	void setId(int id) {
		
		if(id<0) {
			System.out.println("Invalid");
			return;
		}
		Id = id;
	}
	
	
	
	String getName() {
		return name;
	}
	void setName(String name) {
		if(name==null) {
			System.out.println("Please enter a valid name");
			//return;
		}
		this.name = name;
	}
	String getGender() {
		return gender;
	}
	void setGender(String gender) {
		if(gender==null) {
			System.out.println("Please enter a valid gender");
			//return;
		}
		this.gender = gender;
	}
	double getBasicSalary() {
		return basicSalary;
	}
	void setBasicSalary(double basicSalary) {
		if(basicSalary<0) {
			System.out.println("Invalid");
			return;
		}
		this.basicSalary = basicSalary;
	}
	
	double getNetSalary() {
		double allowance=this.basicSalary*0.35;
		double tax=this.basicSalary*0.10;
		double net=this.basicSalary+allowance-tax;
		return net;
	}

}
