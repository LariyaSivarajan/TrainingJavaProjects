package com.ust.model;

public class C implements A,B,X{
//impemets X interface
	@Override
	public void f1() {
		System.out.println("f1 in C Class");
	}
	@Override
	public void f4() {
		System.out.println("f4 in C Class");
	}
	@Override
	public void f6() {
		System.out.println("f6 in C Class");
	}
	@Override
	public void f8() {
		System.out.println("f8 in C Class");
	}
}
