package com.ust.model;

public class D implements A,B,X
{
//implement X interface
	@Override
	public void f1() {
		System.out.println("f1 in D Class");
		
	}
	@Override
	public void f2() {
		System.out.println("f2 in D Class");
	}
	@Override
	public void f4() {
		System.out.println("f4 in D Class");
	}
	@Override
	public void f6() {
		System.out.println("f6 in D Class");
	}
	@Override
	public void f8() {
		System.out.println("f8 in D Class");
	}
}
