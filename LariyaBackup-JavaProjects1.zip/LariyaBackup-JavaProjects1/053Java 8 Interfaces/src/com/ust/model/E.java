package com.ust.model;

public class E implements A,B,X{
	//impemets X interface
	@Override
	public void f1() {
		System.out.println("f1 in E Class");
		
	}
	@Override
	public void f2() {
		System.out.println("f2 in E Class");
	}
	@Override
	public void f4() {
		System.out.println("f4 in E Class");
		
	}
	
	@Override
	public void f8() {
		System.out.println("f8 in E Class");
	}
}
