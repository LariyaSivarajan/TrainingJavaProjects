package com.ust.model;

public interface X {
	// define one default method
	// define one static method
	// define one abstract method(no default,no body)

	default void f6() {
		System.out.println("f6 in X Interface");
	}

	static void f7() {
		System.out.println(" Static f7 in X Interface");
	}

	void f8();
}
