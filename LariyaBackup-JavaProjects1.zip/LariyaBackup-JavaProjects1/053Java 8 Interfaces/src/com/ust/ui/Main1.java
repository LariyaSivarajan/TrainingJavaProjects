package com.ust.ui;

import com.ust.model.A;
import com.ust.model.C;
import com.ust.model.D;
import com.ust.model.E;
import com.ust.model.X;

public class Main1 {

	public static void main(String[] args) {
		A obj;
		obj=new E();
		obj.f1();
		obj.f2();
		obj.f3();
		A.f5();
		
		//call the static method defined in x
		X obj1;
		obj1=new C();
		obj1.f6();
		obj1.f8();
		X.f7();
	}

}
