package com.ust.ui;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

import com.ust.modal.Bill;
import com.ust.modal.Department;
import com.ust.util.ConsoleIO;

public class Main1 {

	public static void main(String[] args) throws IOException {
		// take input for deoartment

		// department should contain 3 employees
		// serialize

		String name;
		String managerName;
		System.out.println("Enter Department name");
		name = ConsoleIO.inputString();

		System.out.println("Enter Manager Name");
		managerName = ConsoleIO.inputString();

		char anymore;

		Department deparment = new Department(name, managerName);
		do {
			int id;
			String empName;
			String gender;
			String cityName;
			double basic;

			System.out.println("Enter ID :");
			id = ConsoleIO.inputInt();

			System.out.println("Enter Emp Name :");
			empName = ConsoleIO.inputString();
			System.out.println("Enter Gender :");
			gender = ConsoleIO.inputString();
			System.out.println("Enter CityName :");
			cityName = ConsoleIO.inputString();
			System.out.println("Enter Basic :");
			basic = ConsoleIO.inputDouble();

			deparment.addEmployee(id, empName, gender, cityName, basic);

			System.out.println("Add more items? :");
			anymore = ConsoleIO.inputChar();

		} while (anymore == 'Y' || anymore == 'y');

		deparment.printReport();

		// serialize the bill object to a file

		try {

			OutputStream os = new FileOutputStream("deptartment.dat");
			ObjectOutputStream oos = new ObjectOutputStream(os);
			oos.writeObject(deparment);

			oos.flush(); // serialization
			oos.close();
			os.close();

		} catch (Throwable e) {
			System.err.println(e.getMessage());
			System.exit(0);
		}

	}

}
