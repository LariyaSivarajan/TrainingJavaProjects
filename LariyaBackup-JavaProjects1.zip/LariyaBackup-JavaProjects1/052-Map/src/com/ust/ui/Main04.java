package com.ust.ui;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import com.ust.modal.Circle;

public class Main04 {

	public static void main(String[] args) {

		// create 3 circle obj
		// put the obj in the map
		// Circle(100)------"Largest"
		// Circle(50)------"Medium";
		// Circle(5)-----Smallest
		// iterate the map entries
		// print key and value

		Map<Circle, String> map = new HashMap<>();

		Circle c1 = new Circle(100);
		Circle c2 = new Circle(50);
		Circle c3 = new Circle(5);

		map.put(c1, "LARGEST");
		map.put(c2, "MEDIUM");
		map.put(c3, "SMALL");
		System.out.println(map);
		Set<Circle> allKeys = map.keySet();
		System.out.println(allKeys);

		Collection<String> allValues = map.values();
		System.out.println(allValues);

		// iterate on all keys set and print the key and its value
		// use entryset and iterate

		for (Circle key : allKeys) {
			System.out.println(key + "-" + map.get(key));
		}
		for (Map.Entry<Circle, String> entry : map.entrySet()) {
			System.out.println(entry.getKey() + "-" + entry.getValue());
		}

	}

}
