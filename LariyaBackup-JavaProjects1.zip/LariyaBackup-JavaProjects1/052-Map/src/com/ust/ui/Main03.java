package com.ust.ui;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import com.ust.modal.Circle;
import com.ust.modal.Employee;

public class Main03 {

	public static void main(String[] args) {
		Map<Integer, Employee> empMap = new TreeMap<>();
		Employee e1 = new Employee(10, "Ram", "Male", "Banglore", 10000.00);
		Employee e2 = new Employee(11, "Saranya", "Female", "Chennai", 20000.00);
		Employee e3 = new Employee(12, "Lekshmi", "Female", "Banglore", 10000.00);
		Employee e4 = new Employee(13, "Vicky", "Male", "Cochin", 15000.00);
		Employee e5 = new Employee(14, "Reshmi", "Female", "Chennai", 22000.00);

		empMap.put(2, e4);
		empMap.put(Integer.valueOf(3), e3);

		empMap.put(Integer.valueOf(1), e5);
		empMap.put(Integer.valueOf(4), e2);
		empMap.put(Integer.valueOf(5), e1);
		System.out.println(empMap);
		for (Map.Entry<Integer, Employee> entry : empMap.entrySet()) {
			System.out.println(entry.getKey());
			Employee emp = entry.getValue();
			System.out.println(emp.getName() + "-" + emp.getNetSalary());
		}

	}

}
